<?php

return [
    'name' => 'TriGo Dispatch',
    'env' => 'production',
    'debug' => false,
    'timezone' => 'Asia/Manila',
    'base_url' => '',
    'currency' => 'PHP',
];

<?php

return [
    'host' => 'sql201.infinityfree.com',
    'port' => 3306,
    'database' => 'if0_41333807_trigo_sys',
    'username' => 'if0_41333807',
    'password' => 'z9AVWvKvAmq',
    'charset' => 'utf8mb4',
];

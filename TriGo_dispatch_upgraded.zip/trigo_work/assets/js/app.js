document.addEventListener('DOMContentLoaded', function () {
    const root = document.documentElement;

    const applyTheme = function (theme) {
        root.setAttribute('data-theme', theme);
        try {
            localStorage.setItem('trigo-theme', theme);
        } catch (error) {
            console.warn('Theme storage unavailable.', error);
        }
    };

    const savedTheme = (function () {
        try {
            return localStorage.getItem('trigo-theme');
        } catch (error) {
            return null;
        }
    })();

    applyTheme(savedTheme || 'light');

    document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
        button.addEventListener('click', function () {
            applyTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
        });
    });

    const updateClock = function () {
        document.querySelectorAll('[data-live-clock]').forEach(function (node) {
            const now = new Date();
            node.textContent = now.toLocaleString([], {
                weekday: 'short',
                month: 'short',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit'
            });
        });
    };
    updateClock();
    window.setInterval(updateClock, 60000);

    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            const message = form.getAttribute('data-confirm') || 'Are you sure?';
            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    document.querySelectorAll('[data-copy-text]').forEach(function (button) {
        button.addEventListener('click', async function () {
            const value = button.getAttribute('data-copy-text') || '';
            if (!value) return;
            try {
                await navigator.clipboard.writeText(value);
                const original = button.innerHTML;
                button.innerHTML = 'Copied';
                setTimeout(function () {
                    button.innerHTML = original;
                }, 1500);
            } catch (error) {
                console.warn('Clipboard copy failed.', error);
            }
        });
    });

    document.querySelectorAll('[data-table-search]').forEach(function (input) {
        const selector = input.getAttribute('data-table-search');
        const table = selector ? document.querySelector(selector) : null;
        if (!table) return;
        const rows = Array.from(table.querySelectorAll('tbody tr'));
        input.addEventListener('input', function () {
            const query = input.value.trim().toLowerCase();
            rows.forEach(function (row) {
                const text = row.textContent.toLowerCase();
                row.style.display = !query || text.includes(query) ? '' : 'none';
            });
        });
    });

    document.querySelectorAll('[data-booking-form]').forEach(function (form) {
        const pickupInput = form.querySelector('[name="pickup_location"]');
        const dropoffInput = form.querySelector('[name="dropoff_location"]');
        const contactInput = form.querySelector('[name="contact_number"]');
        const notesInput = form.querySelector('[data-notes-input]');
        const fareOutput = document.querySelector('[data-fare-output]');
        const summaryPickup = document.querySelector('[data-summary-pickup]');
        const summaryDropoff = document.querySelector('[data-summary-dropoff]');
        const summaryContact = document.querySelector('[data-summary-contact]');
        const notesCount = document.querySelector('[data-notes-count]');
        const baseFare = Number(form.getAttribute('data-base-fare') || 0);
        const nightSurcharge = Number(form.getAttribute('data-night-surcharge') || 0);

        const formatPeso = function (value) {
            return 'PHP ' + Number(value || 0).toFixed(2);
        };

        const refreshSummary = function () {
            if (summaryPickup) summaryPickup.textContent = pickupInput && pickupInput.value.trim() ? pickupInput.value.trim() : 'Not set';
            if (summaryDropoff) summaryDropoff.textContent = dropoffInput && dropoffInput.value.trim() ? dropoffInput.value.trim() : 'Not set';
            if (summaryContact) summaryContact.textContent = contactInput && contactInput.value.trim() ? contactInput.value.trim() : 'Not set';
            if (notesCount) notesCount.textContent = notesInput ? notesInput.value.length : 0;

            const now = new Date();
            const hour = now.getHours();
            const isNight = hour >= 21 || hour < 5;
            const routeComplexity = ((pickupInput?.value.length || 0) + (dropoffInput?.value.length || 0)) > 50 ? 5 : 0;
            const estimate = baseFare + (isNight ? nightSurcharge : 0) + routeComplexity;
            if (fareOutput) {
                fareOutput.textContent = formatPeso(estimate);
            }
        };

        [pickupInput, dropoffInput, contactInput, notesInput].forEach(function (field) {
            if (!field) return;
            field.addEventListener('input', refreshSummary);
        });

        refreshSummary();
    });
});

<?php

define('BASE_PATH', __DIR__);
require BASE_PATH . '/bootstrap/autoload.php';

$service = new \App\Services\OperationsMaintenanceService();
$service->run();

echo "Queue and assignment maintenance completed." . PHP_EOL;

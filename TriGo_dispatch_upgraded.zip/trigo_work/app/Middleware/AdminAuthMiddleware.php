<?php

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;

class AdminAuthMiddleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if (!Auth::checkAdmin()) {
            Response::redirect('/admin/login');
        }

        return $next($request);
    }
}

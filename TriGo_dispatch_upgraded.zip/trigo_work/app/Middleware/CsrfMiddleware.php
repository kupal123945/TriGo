<?php

namespace App\Middleware;

use App\Core\Csrf;
use App\Core\Request;
use App\Core\View;

class CsrfMiddleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if ($request->method() !== 'POST') {
            return $next($request);
        }

        if (!Csrf::validate((string) $request->post('_token', ''))) {
            http_response_code(419);
            return View::render('errors.419', [
                'pageTitle' => 'Session Expired',
                'message' => 'The security token is invalid or expired. Please refresh the page and try again.',
            ], is_admin_logged_in() ? 'admin' : 'app');
        }

        return $next($request);
    }
}

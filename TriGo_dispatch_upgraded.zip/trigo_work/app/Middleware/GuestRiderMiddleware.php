<?php

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;

class GuestRiderMiddleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if (Auth::checkRider()) {
            Response::redirect('/rider/dashboard');
        }

        return $next($request);
    }
}

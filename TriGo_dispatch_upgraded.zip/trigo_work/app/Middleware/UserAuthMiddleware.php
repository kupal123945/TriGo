<?php

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;

class UserAuthMiddleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if (!Auth::checkUser()) {
            Response::redirect('/login');
        }

        return $next($request);
    }
}

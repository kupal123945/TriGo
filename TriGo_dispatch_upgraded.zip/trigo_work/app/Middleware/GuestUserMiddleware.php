<?php

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;

class GuestUserMiddleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if (Auth::checkUser()) {
            Response::redirect('/dashboard');
        }

        return $next($request);
    }
}

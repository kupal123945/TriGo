<?php

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;

class RiderAuthMiddleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if (!Auth::checkRider()) {
            Response::redirect('/rider/login');
        }

        return $next($request);
    }
}

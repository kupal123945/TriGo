<?php

namespace App\Middleware;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;

class GuestAdminMiddleware
{
    public function handle(Request $request, callable $next): mixed
    {
        if (Auth::checkAdmin()) {
            Response::redirect('/admin/dashboard');
        }

        return $next($request);
    }
}

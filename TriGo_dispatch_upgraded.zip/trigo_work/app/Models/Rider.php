<?php

namespace App\Models;

class Rider extends BaseModel
{
    protected string $table = 'riders';
}

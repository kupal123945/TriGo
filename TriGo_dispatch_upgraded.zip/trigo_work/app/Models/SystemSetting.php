<?php

namespace App\Models;

class SystemSetting extends BaseModel
{
    protected string $table = 'system_settings';
}

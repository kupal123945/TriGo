<?php

namespace App\Models;

class Booking extends BaseModel
{
    protected string $table = 'bookings';
}

<?php

namespace App\Models;

class TripHistory extends BaseModel
{
    protected string $table = 'trip_history';
}

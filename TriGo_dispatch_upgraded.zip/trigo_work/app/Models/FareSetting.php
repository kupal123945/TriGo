<?php

namespace App\Models;

class FareSetting extends BaseModel
{
    protected string $table = 'fare_settings';
}

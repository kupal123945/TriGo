<?php

namespace App\Models;

use App\Core\Database;
use PDO;

abstract class BaseModel
{
    protected string $table;

    protected function connection(): PDO
    {
        return Database::getConnection();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->connection()->prepare("SELECT * FROM {$this->table} WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function all(string $sql = '', array $params = []): array
    {
        if ($sql === '') {
            $sql = "SELECT * FROM {$this->table}";
        }
        $stmt = $this->connection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll() ?: [];
    }

    public function one(string $sql, array $params = []): ?array
    {
        $stmt = $this->connection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch() ?: null;
    }

    public function insert(array $data): int
    {
        $columns = array_keys($data);
        $placeholders = array_fill(0, count($columns), '?');
        $sql = sprintf(
            'INSERT INTO %s (%s) VALUES (%s)',
            $this->table,
            implode(', ', $columns),
            implode(', ', $placeholders)
        );
        $stmt = $this->connection()->prepare($sql);
        $stmt->execute(array_values($data));
        return (int) $this->connection()->lastInsertId();
    }

    public function updateById(int $id, array $data): bool
    {
        $assignments = array_map(fn (string $column): string => $column . ' = ?', array_keys($data));
        $sql = sprintf('UPDATE %s SET %s WHERE id = ?', $this->table, implode(', ', $assignments));
        $stmt = $this->connection()->prepare($sql);
        return $stmt->execute([...array_values($data), $id]);
    }

    public function deleteById(int $id): bool
    {
        $stmt = $this->connection()->prepare("DELETE FROM {$this->table} WHERE id = ?");
        return $stmt->execute([$id]);
    }
}

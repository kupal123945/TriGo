<?php

namespace App\Models;

class ActivityLog extends BaseModel
{
    protected string $table = 'activity_logs';
}

<?php

namespace App\Models;

class NotificationLog extends BaseModel
{
    protected string $table = 'notifications';
}

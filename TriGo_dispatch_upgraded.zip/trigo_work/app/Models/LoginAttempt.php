<?php

namespace App\Models;

class LoginAttempt extends BaseModel
{
    protected string $table = 'login_attempts';
}

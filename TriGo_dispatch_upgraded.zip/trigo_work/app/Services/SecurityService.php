<?php

namespace App\Services;

use App\Core\Database;

class SecurityService
{
    protected int $maxAttempts = 5;
    protected int $lockMinutes = 15;

    public function isLocked(string $scope, string $identifier, string $ipAddress = ''): bool
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT failed_attempts, locked_until FROM login_attempts WHERE scope = ? AND identifier = ? AND ip_address = ? LIMIT 1'
        );
        $stmt->execute([$scope, $identifier, $ipAddress]);
        $row = $stmt->fetch() ?: null;

        if (!$row) {
            return false;
        }

        if (!empty($row['locked_until']) && strtotime((string) $row['locked_until']) > time()) {
            return true;
        }

        return false;
    }

    public function remainingLockSeconds(string $scope, string $identifier, string $ipAddress = ''): int
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT locked_until FROM login_attempts WHERE scope = ? AND identifier = ? AND ip_address = ? LIMIT 1'
        );
        $stmt->execute([$scope, $identifier, $ipAddress]);
        $row = $stmt->fetch() ?: null;
        $lockedUntil = strtotime((string) ($row['locked_until'] ?? ''));
        if ($lockedUntil <= time()) {
            return 0;
        }

        return $lockedUntil - time();
    }

    public function recordFailure(string $scope, string $identifier, string $ipAddress = ''): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT id, failed_attempts FROM login_attempts WHERE scope = ? AND identifier = ? AND ip_address = ? LIMIT 1 FOR UPDATE'
        );
        $pdo->beginTransaction();

        try {
            $stmt->execute([$scope, $identifier, $ipAddress]);
            $row = $stmt->fetch() ?: null;
            $now = date('Y-m-d H:i:s');

            if ($row) {
                $attempts = (int) $row['failed_attempts'] + 1;
                $lockedUntil = $attempts >= $this->maxAttempts
                    ? date('Y-m-d H:i:s', time() + ($this->lockMinutes * 60))
                    : null;
                $pdo->prepare('UPDATE login_attempts SET failed_attempts = ?, last_failed_at = ?, locked_until = ?, updated_at = ? WHERE id = ?')
                    ->execute([$attempts, $now, $lockedUntil, $now, (int) $row['id']]);
            } else {
                $pdo->prepare(
                    'INSERT INTO login_attempts (scope, identifier, ip_address, failed_attempts, last_failed_at, locked_until, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
                )->execute([
                    $scope,
                    $identifier,
                    $ipAddress,
                    1,
                    $now,
                    null,
                    $now,
                    $now,
                ]);
            }

            $pdo->commit();
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public function clearFailures(string $scope, string $identifier, string $ipAddress = ''): void
    {
        $pdo = Database::getConnection();
        $pdo->prepare('DELETE FROM login_attempts WHERE scope = ? AND identifier = ? AND ip_address = ?')
            ->execute([$scope, $identifier, $ipAddress]);
    }
}

<?php

namespace App\Services;

use App\Core\Database;

class SettingService
{
    protected static ?array $cache = null;

    public function defaults(): array
    {
        return [
            'terminal_name' => 'Community Tricycle Terminal',
            'support_email' => '',
            'smtp_enabled' => '0',
            'smtp_host' => '',
            'smtp_port' => '587',
            'smtp_encryption' => 'tls',
            'smtp_username' => '',
            'smtp_password' => '',
            'smtp_from_email' => '',
            'smtp_from_name' => 'Terminal Dispatch',
            'sms_enabled' => '0',
            'sms_gateway_url' => '',
            'sms_http_method' => 'POST',
            'sms_token' => '',
            'sms_token_param' => 'token',
            'sms_recipient_param' => 'to',
            'sms_message_param' => 'message',
            'sms_auth_header' => '',
        ];
    }

    public function all(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $pdo = Database::getConnection();
        $rows = $pdo->query('SELECT setting_key, setting_value FROM system_settings ORDER BY setting_key ASC')->fetchAll() ?: [];

        $items = [];
        foreach ($rows as $row) {
            $items[$row['setting_key']] = $row['setting_value'];
        }

        self::$cache = array_merge($this->defaults(), $items);
        return self::$cache;
    }

    public function get(string $key, mixed $default = null): mixed
    {
        $items = $this->all();
        return $items[$key] ?? $default;
    }

    public function setMany(array $settings): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO system_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, ?, ?) '
            . 'ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)'
        );

        $now = date('Y-m-d H:i:s');

        foreach ($settings as $key => $value) {
            $normalized = is_bool($value) ? ($value ? '1' : '0') : (string) $value;
            $stmt->execute([(string) $key, $normalized, $now, $now]);
        }

        self::$cache = null;
    }
}

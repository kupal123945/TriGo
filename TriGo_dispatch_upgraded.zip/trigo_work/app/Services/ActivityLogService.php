<?php

namespace App\Services;

use App\Models\ActivityLog;

class ActivityLogService
{
    protected ActivityLog $activityLog;

    public function __construct()
    {
        $this->activityLog = new ActivityLog();
    }

    public function log(string $actorType, ?int $actorId, string $action, string $description, ?string $ipAddress = null): void
    {
        $this->activityLog->insert([
            'actor_type' => $actorType,
            'actor_id' => $actorId,
            'action' => $action,
            'description' => $description,
            'ip_address' => $ipAddress,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}

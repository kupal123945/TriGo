<?php

namespace App\Services;

use App\Core\Database;

class OperationsMaintenanceService
{
    protected QueueService $queueService;
    protected BookingService $bookingService;
    protected NotificationService $notificationService;

    public function __construct()
    {
        $this->queueService = new QueueService();
        $this->bookingService = new BookingService();
        $this->notificationService = new NotificationService();
    }

    public function run(): void
    {
        $this->expireAndRedispatchAssignedBookings();
        $this->flushNotificationQueue();
    }

    public function expireAndRedispatchAssignedBookings(int $assignmentTimeoutMinutes = 5): void
    {
        $pdo = Database::getConnection();
        $cutoff = date('Y-m-d H:i:s', time() - ($assignmentTimeoutMinutes * 60));
        $stmt = $pdo->prepare(
            "SELECT * FROM bookings WHERE status = 'Assigned' AND accepted_at IS NULL AND assigned_at IS NOT NULL AND assigned_at <= ? ORDER BY assigned_at ASC"
        );
        $stmt->execute([$cutoff]);
        $bookings = $stmt->fetchAll() ?: [];

        foreach ($bookings as $booking) {
            $this->redispatchExpiredBooking((int) $booking['id']);
        }
    }

    protected function redispatchExpiredBooking(int $bookingId): void
    {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? LIMIT 1 FOR UPDATE');
            $stmt->execute([$bookingId]);
            $booking = $stmt->fetch() ?: null;
            if (!$booking || (string) $booking['status'] !== 'Assigned' || !empty($booking['accepted_at'])) {
                $pdo->rollBack();
                return;
            }

            $oldRiderId = (int) ($booking['rider_id'] ?? 0);
            $riders = $this->queueService->lockOrderedActiveRiders($pdo);
            $selected = null;
            foreach ($riders as $rider) {
                if ((int) $rider['id'] === $oldRiderId) {
                    continue;
                }
                if (($rider['status'] ?? '') !== 'Available') {
                    continue;
                }
                $selected = $rider;
                break;
            }

            $now = date('Y-m-d H:i:s');
            if ($oldRiderId > 0) {
                $this->bookingService->releaseRiderIfIdle($pdo, $oldRiderId, $bookingId);
            }

            if ($selected === null) {
                $pdo->prepare('UPDATE bookings SET rider_id = NULL, status = ?, no_rider_reason = ?, assigned_at = NULL, updated_at = ? WHERE id = ?')
                    ->execute(['Failed / No Rider Available', 'Assigned rider did not confirm in time.', $now, $bookingId]);
                $this->bookingService->recordTripHistory($pdo, $bookingId, 'Assigned', 'Failed / No Rider Available', 'Assigned rider did not confirm in time.', 'system', null);
                $pdo->commit();
                return;
            }

            $pdo->prepare('UPDATE bookings SET rider_id = ?, status = ?, no_rider_reason = NULL, assigned_at = ?, updated_at = ? WHERE id = ?')
                ->execute([(int) $selected['id'], 'Assigned', $now, $now, $bookingId]);
            $pdo->prepare('UPDATE riders SET status = ?, last_assigned_at = ?, updated_at = ? WHERE id = ?')
                ->execute(['Busy', $now, $now, (int) $selected['id']]);
            $reordered = $this->queueService->reorderAfterAssignment($riders, (int) $selected['id']);
            $this->queueService->persistQueue($pdo, $reordered);
            $this->bookingService->recordTripHistory($pdo, $bookingId, 'Assigned', 'Assigned', 'System re-dispatched after rider timeout.', 'system', null);
            $pdo->commit();

            $details = $this->bookingService->getBookingDetailsById($bookingId) ?: [];
            $this->notificationService->queueAssignedRiderNotification($details);
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public function flushNotificationQueue(int $limit = 20): void
    {
        $this->notificationService->processPendingQueue($limit);
    }
}

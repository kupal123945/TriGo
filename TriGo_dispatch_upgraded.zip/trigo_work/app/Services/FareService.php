<?php

namespace App\Services;

use App\Models\FareSetting;

class FareService
{
    protected FareSetting $fareSetting;

    public function __construct()
    {
        $this->fareSetting = new FareSetting();
    }

    public function defaults(): array
    {
        return [
            'base_fare' => 25.00,
            'booking_fee' => 0.00,
            'night_surcharge' => 0.00,
            'notes' => 'Default flat fare estimate for manual pickup and drop-off booking.',
            'cancellation_window_minutes' => 5,
        ];
    }

    public function getSettings(): array
    {
        $row = $this->fareSetting->one('SELECT * FROM fare_settings ORDER BY id ASC LIMIT 1') ?: null;
        if ($row) {
            return array_merge($this->defaults(), $row);
        }

        $defaults = $this->defaults();
        $id = $this->fareSetting->insert([
            'base_fare' => $defaults['base_fare'],
            'booking_fee' => $defaults['booking_fee'],
            'night_surcharge' => $defaults['night_surcharge'],
            'notes' => $defaults['notes'],
            'cancellation_window_minutes' => $defaults['cancellation_window_minutes'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        return $this->fareSetting->find($id) ?: $defaults;
    }

    public function estimateFare(array $payload = []): float
    {
        $settings = $this->getSettings();
        return (float) $settings['base_fare'] + (float) $settings['booking_fee'];
    }

    public function update(array $data): void
    {
        $row = $this->getSettings();
        $payload = [
            'base_fare' => (float) $data['base_fare'],
            'booking_fee' => (float) $data['booking_fee'],
            'night_surcharge' => (float) $data['night_surcharge'],
            'notes' => trim((string) ($data['notes'] ?? '')),
            'cancellation_window_minutes' => (int) $data['cancellation_window_minutes'],
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        $this->fareSetting->updateById((int) $row['id'], $payload);
    }
}

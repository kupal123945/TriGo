<?php

namespace App\Services;

use App\Core\Database;
use App\Models\User;
use RuntimeException;
use Throwable;

class DispatchService
{
    protected QueueService $queueService;
    protected FareService $fareService;
    protected BookingService $bookingService;
    protected NotificationService $notificationService;
    protected ActivityLogService $activityLog;
    protected User $userModel;

    public function __construct()
    {
        $this->queueService = new QueueService();
        $this->fareService = new FareService();
        $this->bookingService = new BookingService();
        $this->notificationService = new NotificationService();
        $this->activityLog = new ActivityLogService();
        $this->userModel = new User();
    }

    public function createBookingAndDispatch(int $userId, array $data, string $ipAddress = ''): array
    {
        $fareEstimate = $this->fareService->estimateFare($data);
        $reference = $this->generateReference();
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $now = date('Y-m-d H:i:s');
            $insert = $pdo->prepare(
                'INSERT INTO bookings (booking_reference, user_id, rider_id, pickup_location, dropoff_location, contact_number, notes, fare_estimate, status, no_rider_reason, created_at, updated_at) '
                . 'VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, NULL, ?, ?)'
            );
            $insert->execute([
                $reference,
                $userId,
                trim((string) $data['pickup_location']),
                trim((string) $data['dropoff_location']),
                normalize_phone((string) $data['contact_number']),
                trim((string) ($data['notes'] ?? '')),
                $fareEstimate,
                'Pending',
                $now,
                $now,
            ]);

            $bookingId = (int) $pdo->lastInsertId();
            $this->assignBookingWithinTransaction($pdo, $bookingId);
            $pdo->commit();

            $booking = $this->bookingService->getBookingDetailsById($bookingId) ?: [];
            if (($booking['status'] ?? '') !== 'Failed / No Rider Available') {
                $this->notificationService->queueAssignedRiderNotification($booking);
                $riderName = (string) ($booking['rider_name'] ?? 'assigned rider');
                $this->activityLog->log('user', $userId, 'booking.created', 'User created booking ' . $reference . ' and rider ' . $riderName . ' was auto-assigned.', $ipAddress);
            } else {
                $this->activityLog->log('user', $userId, 'booking.failed_no_rider', 'Booking ' . $reference . ' failed because no rider was available.', $ipAddress);
            }

            return $booking;
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }

    public function reassignPendingBooking(int $bookingId): array
    {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            $this->assignBookingWithinTransaction($pdo, $bookingId);
            $pdo->commit();
            $details = $this->bookingService->getBookingDetailsById($bookingId) ?: [];
            if (($details['status'] ?? '') === 'Assigned') {
                $this->notificationService->queueAssignedRiderNotification($details);
            }
            return $details;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    public function reassignBooking(int $bookingId, int $newRiderId, int $adminId, string $ipAddress = ''): array
    {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? LIMIT 1 FOR UPDATE');
            $stmt->execute([$bookingId]);
            $booking = $stmt->fetch() ?: null;
            if (!$booking) {
                throw new RuntimeException('Booking not found.');
            }
            if (in_array((string) $booking['status'], ['Completed', 'Cancelled'], true)) {
                throw new RuntimeException('Completed or cancelled bookings cannot be reassigned.');
            }

            $riders = $this->queueService->lockOrderedActiveRiders($pdo);
            $selectedRider = null;
            foreach ($riders as $rider) {
                if ((int) $rider['id'] === $newRiderId) {
                    $selectedRider = $rider;
                    break;
                }
            }
            if ($selectedRider === null) {
                throw new RuntimeException('Selected rider is not active or does not exist.');
            }
            if ((int) ($booking['rider_id'] ?? 0) === $newRiderId) {
                throw new RuntimeException('This rider is already assigned to the booking.');
            }
            if (($selectedRider['status'] ?? '') !== 'Available') {
                throw new RuntimeException('Selected rider is not currently available.');
            }

            $now = date('Y-m-d H:i:s');
            $pdo->prepare('UPDATE bookings SET rider_id = ?, status = ?, assigned_at = ?, accepted_at = NULL, no_rider_reason = NULL, updated_at = ? WHERE id = ?')
                ->execute([$newRiderId, 'Assigned', $now, $now, $bookingId]);
            if (!empty($booking['rider_id'])) {
                $this->bookingService->releaseRiderIfIdle($pdo, (int) $booking['rider_id'], $bookingId);
            }
            $pdo->prepare('UPDATE riders SET status = ?, last_assigned_at = ?, updated_at = ? WHERE id = ?')
                ->execute(['Busy', $now, $now, $newRiderId]);
            $reordered = $this->queueService->reorderAfterAssignment($riders, $newRiderId);
            $this->queueService->persistQueue($pdo, $reordered);
            $this->bookingService->recordTripHistory(
                $pdo,
                $bookingId,
                (string) $booking['status'],
                'Assigned',
                'Admin manually reassigned rider ' . $selectedRider['full_name'] . '.',
                'admin',
                $adminId
            );
            $pdo->commit();

            $details = $this->bookingService->getBookingDetailsById($bookingId) ?: [];
            $this->notificationService->queueAssignedRiderNotification($details);
            $this->activityLog->log('admin', $adminId, 'booking.reassigned', 'Admin reassigned booking ' . ($details['booking_reference'] ?? ('#' . $bookingId)) . ' to rider ' . $selectedRider['full_name'] . '.', $ipAddress);
            return $details;
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }

    protected function assignBookingWithinTransaction(\PDO $pdo, int $bookingId): void
    {
        $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? LIMIT 1 FOR UPDATE');
        $stmt->execute([$bookingId]);
        $booking = $stmt->fetch() ?: null;
        if (!$booking) {
            throw new RuntimeException('Booking not found.');
        }

        $now = date('Y-m-d H:i:s');
        $riders = $this->queueService->lockOrderedActiveRiders($pdo);
        $assignedRider = $this->queueService->findNextAvailable($riders);

        if ($assignedRider === null) {
            $pdo->prepare('UPDATE bookings SET status = ?, no_rider_reason = ?, updated_at = ?, rider_id = NULL WHERE id = ?')
                ->execute(['Failed / No Rider Available', 'No available tricycle rider at the moment.', $now, $bookingId]);
            $this->bookingService->recordTripHistory($pdo, $bookingId, (string) $booking['status'], 'Failed / No Rider Available', 'No available tricycle rider at the moment.', 'system', null);
            return;
        }

        $pdo->prepare('UPDATE bookings SET rider_id = ?, status = ?, assigned_at = ?, accepted_at = NULL, no_rider_reason = NULL, updated_at = ? WHERE id = ?')
            ->execute([(int) $assignedRider['id'], 'Assigned', $now, $now, $bookingId]);
        $pdo->prepare('UPDATE riders SET status = ?, last_assigned_at = ?, updated_at = ? WHERE id = ?')
            ->execute(['Busy', $now, $now, (int) $assignedRider['id']]);
        $reordered = $this->queueService->reorderAfterAssignment($riders, (int) $assignedRider['id']);
        $this->queueService->persistQueue($pdo, $reordered);
        $this->bookingService->recordTripHistory($pdo, $bookingId, (string) $booking['status'], 'Assigned', 'System automatically assigned rider ' . $assignedRider['full_name'] . '.', 'system', null);
    }

    protected function generateReference(): string
    {
        return 'TRI-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(3)));
    }
}

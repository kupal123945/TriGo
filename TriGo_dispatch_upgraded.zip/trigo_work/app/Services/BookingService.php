<?php

namespace App\Services;

use App\Core\Database;
use App\Models\TripHistory;
use DateTimeImmutable;
use PDO;
use RuntimeException;
use Throwable;

class BookingService
{
    protected TripHistory $tripHistory;
    protected FareService $fareService;
    protected ActivityLogService $activityLog;

    public function __construct()
    {
        $this->tripHistory = new TripHistory();
        $this->fareService = new FareService();
        $this->activityLog = new ActivityLogService();
    }

    public function activeStatuses(): array
    {
        return ['Pending', 'Assigned', 'Accepted', 'Ongoing'];
    }

    public function userHasActiveBooking(int $userId): bool
    {
        $pdo = Database::getConnection();
        $placeholders = implode(', ', array_fill(0, count($this->activeStatuses()), '?'));
        $stmt = $pdo->prepare('SELECT COUNT(*) AS total FROM bookings WHERE user_id = ? AND status IN (' . $placeholders . ')');
        $stmt->execute([$userId, ...$this->activeStatuses()]);
        return (int) ($stmt->fetch()['total'] ?? 0) > 0;
    }

    public function hasRecentDuplicateBooking(int $userId, string $pickup, string $dropoff, int $seconds = 120): bool
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) AS total FROM bookings WHERE user_id = ? AND pickup_location = ? AND dropoff_location = ? AND created_at >= ?'
        );
        $stmt->execute([$userId, trim($pickup), trim($dropoff), date('Y-m-d H:i:s', time() - $seconds)]);
        return (int) ($stmt->fetch()['total'] ?? 0) > 0;
    }

    public function getActiveBookingForUser(int $userId): ?array
    {
        $pdo = Database::getConnection();
        $placeholders = implode(', ', array_fill(0, count($this->activeStatuses()), '?'));
        $stmt = $pdo->prepare(
            'SELECT b.*, r.full_name AS rider_name, r.phone AS rider_phone, r.tricycle_number, r.status AS rider_status '
            . 'FROM bookings b '
            . 'LEFT JOIN riders r ON r.id = b.rider_id '
            . 'WHERE b.user_id = ? AND b.status IN (' . $placeholders . ') '
            . 'ORDER BY b.created_at DESC LIMIT 1'
        );
        $stmt->execute([$userId, ...$this->activeStatuses()]);
        return $stmt->fetch() ?: null;
    }

    public function listBookingsForUser(int $userId, int $limit = 50): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT b.*, r.full_name AS rider_name, r.phone AS rider_phone, r.tricycle_number, r.status AS rider_status '
            . 'FROM bookings b '
            . 'LEFT JOIN riders r ON r.id = b.rider_id '
            . 'WHERE b.user_id = ? '
            . 'ORDER BY b.created_at DESC LIMIT ' . (int) $limit
        );
        $stmt->execute([$userId]);
        return $stmt->fetchAll() ?: [];
    }

    public function getBookingByReferenceForUser(int $userId, string $reference): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT b.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone, '
            . 'r.full_name AS rider_name, r.phone AS rider_phone, r.tricycle_number, r.status AS rider_status, r.email AS rider_email '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'LEFT JOIN riders r ON r.id = b.rider_id '
            . 'WHERE b.user_id = ? AND b.booking_reference = ? LIMIT 1'
        );
        $stmt->execute([$userId, $reference]);
        return $stmt->fetch() ?: null;
    }

    public function getBookingDetailsById(int $bookingId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT b.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone, '
            . 'r.full_name AS rider_name, r.phone AS rider_phone, r.tricycle_number, r.status AS rider_status, r.email AS rider_email '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'LEFT JOIN riders r ON r.id = b.rider_id '
            . 'WHERE b.id = ? LIMIT 1'
        );
        $stmt->execute([$bookingId]);
        return $stmt->fetch() ?: null;
    }

    public function getActiveBookingsForRider(int $riderId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT b.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'WHERE b.rider_id = ? AND b.status IN (?, ?, ?) '
            . 'ORDER BY b.created_at ASC'
        );
        $stmt->execute([$riderId, 'Assigned', 'Accepted', 'Ongoing']);
        return $stmt->fetchAll() ?: [];
    }

    public function getBookingDetailsForRider(int $bookingId, int $riderId): ?array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT b.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone, '
            . 'r.full_name AS rider_name, r.phone AS rider_phone, r.tricycle_number, r.status AS rider_status, r.email AS rider_email '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'JOIN riders r ON r.id = b.rider_id '
            . 'WHERE b.id = ? AND b.rider_id = ? LIMIT 1'
        );
        $stmt->execute([$bookingId, $riderId]);
        return $stmt->fetch() ?: null;
    }

    public function recordTripHistory(PDO $pdo, int $bookingId, ?string $fromStatus, string $toStatus, string $remarks, string $changedByType, ?int $changedById): void
    {
        $stmt = $pdo->prepare(
            'INSERT INTO trip_history (booking_id, from_status, to_status, remarks, changed_by_type, changed_by_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$bookingId, $fromStatus, $toStatus, $remarks, $changedByType, $changedById, date('Y-m-d H:i:s')]);
    }

    public function releaseRiderIfIdle(PDO $pdo, int $riderId, ?int $ignoreBookingId = null): void
    {
        $activeStatuses = $this->activeStatuses();
        $sql = 'SELECT COUNT(*) AS total FROM bookings WHERE rider_id = ? AND status IN (' . implode(', ', array_fill(0, count($activeStatuses), '?')) . ')';
        $params = [$riderId, ...$activeStatuses];
        if ($ignoreBookingId !== null) {
            $sql .= ' AND id != ?';
            $params[] = $ignoreBookingId;
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $count = (int) ($stmt->fetch()['total'] ?? 0);

        if ($count === 0) {
            $riderStmt = $pdo->prepare('SELECT status FROM riders WHERE id = ? LIMIT 1');
            $riderStmt->execute([$riderId]);
            $rider = $riderStmt->fetch() ?: [];
            $nextStatus = (string) ($rider['status'] ?? '') === 'Paused' ? 'Paused' : 'Available';
            $pdo->prepare('UPDATE riders SET status = ?, updated_at = ? WHERE id = ?')
                ->execute([$nextStatus, date('Y-m-d H:i:s'), $riderId]);
        }
    }

    public function canUserCancel(array $booking): bool
    {
        if (!in_array((string) ($booking['status'] ?? ''), ['Pending', 'Assigned', 'Accepted'], true)) {
            return false;
        }

        $settings = $this->fareService->getSettings();
        $window = (int) ($settings['cancellation_window_minutes'] ?? 0);
        if ($window <= 0) {
            return false;
        }

        try {
            $createdAt = new DateTimeImmutable((string) $booking['created_at']);
            $now = new DateTimeImmutable('now');
            return ($now->getTimestamp() - $createdAt->getTimestamp()) <= ($window * 60);
        } catch (Throwable) {
            return false;
        }
    }

    public function cancelByUser(int $bookingId, int $userId, string $ipAddress = ''): void
    {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ? LIMIT 1 FOR UPDATE');
            $stmt->execute([$bookingId, $userId]);
            $booking = $stmt->fetch() ?: null;
            if (!$booking) {
                throw new RuntimeException('Booking not found.');
            }
            if (!$this->canUserCancel($booking)) {
                throw new RuntimeException('This booking can no longer be cancelled by the user.');
            }

            $now = date('Y-m-d H:i:s');
            $pdo->prepare('UPDATE bookings SET status = ?, cancelled_at = ?, updated_at = ? WHERE id = ?')
                ->execute(['Cancelled', $now, $now, $bookingId]);

            if (!empty($booking['rider_id'])) {
                $this->releaseRiderIfIdle($pdo, (int) $booking['rider_id'], $bookingId);
            }

            $this->recordTripHistory($pdo, $bookingId, (string) $booking['status'], 'Cancelled', 'User cancelled booking.', 'user', $userId);
            $pdo->commit();

            $details = $this->getBookingDetailsById($bookingId);
            $reference = $details['booking_reference'] ?? ('#' . $bookingId);
            $this->activityLog->log('user', $userId, 'booking.cancelled', 'User cancelled booking ' . $reference . '.', $ipAddress);
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }

    public function updateStatusByAdmin(int $bookingId, string $newStatus, int $adminId, string $ipAddress = ''): void
    {
        if (!in_array($newStatus, ['Assigned', 'Accepted', 'Ongoing', 'Completed', 'Cancelled'], true)) {
            throw new RuntimeException('Invalid booking status selected.');
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? LIMIT 1 FOR UPDATE');
            $stmt->execute([$bookingId]);
            $booking = $stmt->fetch() ?: null;
            if (!$booking) {
                throw new RuntimeException('Booking not found.');
            }
            if (empty($booking['rider_id']) && in_array($newStatus, ['Assigned', 'Accepted', 'Ongoing', 'Completed'], true)) {
                throw new RuntimeException('This booking has no assigned rider. Use manual reassign first.');
            }

            $this->applyStatusUpdate($pdo, $booking, $newStatus, 'admin', $adminId, 'Admin updated booking status.');
            $pdo->commit();

            $details = $this->getBookingDetailsById($bookingId);
            $reference = $details['booking_reference'] ?? ('#' . $bookingId);
            $this->activityLog->log('admin', $adminId, 'booking.status_update', 'Admin changed booking ' . $reference . ' to ' . $newStatus . '.', $ipAddress);
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }

    public function updateStatusByRider(int $bookingId, int $riderId, string $newStatus, string $ipAddress = '', string $declineReason = ''): void
    {
        if (!in_array($newStatus, ['Accepted', 'Ongoing', 'Completed', 'Cancelled'], true)) {
            throw new RuntimeException('Rider can only accept, start, complete, or decline a trip.');
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM bookings WHERE id = ? AND rider_id = ? LIMIT 1 FOR UPDATE');
            $stmt->execute([$bookingId, $riderId]);
            $booking = $stmt->fetch() ?: null;
            if (!$booking) {
                throw new RuntimeException('Booking not found for this rider.');
            }

            $currentStatus = (string) ($booking['status'] ?? '');
            if ($newStatus === 'Accepted' && $currentStatus !== 'Assigned') {
                throw new RuntimeException('Only assigned bookings can be accepted.');
            }
            if ($newStatus === 'Ongoing' && !in_array($currentStatus, ['Assigned', 'Accepted'], true)) {
                throw new RuntimeException('Only assigned or accepted bookings can be started by the rider.');
            }
            if ($newStatus === 'Completed' && !in_array($currentStatus, ['Assigned', 'Accepted', 'Ongoing'], true)) {
                throw new RuntimeException('Only active bookings can be completed by the rider.');
            }
            if ($newStatus === 'Cancelled' && $currentStatus !== 'Assigned') {
                throw new RuntimeException('Only assigned bookings can be declined by the rider.');
            }

            if ($newStatus === 'Cancelled') {
                $reason = trim($declineReason) !== '' ? trim($declineReason) : 'Rider declined assignment.';
                $pdo->prepare('UPDATE bookings SET status = ?, decline_reason = ?, declined_at = ?, updated_at = ? WHERE id = ?')
                    ->execute(['Pending', $reason, date('Y-m-d H:i:s'), date('Y-m-d H:i:s'), $bookingId]);
                $this->releaseRiderIfIdle($pdo, $riderId, $bookingId);
                $this->recordTripHistory($pdo, $bookingId, $currentStatus, 'Pending', $reason, 'rider', $riderId);
                $pdo->commit();
                (new DispatchService())->reassignPendingBooking($bookingId);
            } else {
                $remarks = match ($newStatus) {
                    'Accepted' => 'Rider accepted the trip.',
                    'Ongoing' => 'Rider started the trip.',
                    'Completed' => 'Rider completed the trip.',
                    default => 'Rider updated the trip.',
                };
                $this->applyStatusUpdate($pdo, $booking, $newStatus, 'rider', $riderId, $remarks);
                $pdo->commit();
            }

            $details = $this->getBookingDetailsById($bookingId);
            $reference = $details['booking_reference'] ?? ('#' . $bookingId);
            $this->activityLog->log('rider', $riderId, 'booking.status_update', 'Rider changed booking ' . $reference . ' to ' . $newStatus . '.', $ipAddress);
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $exception;
        }
    }

    protected function applyStatusUpdate(PDO $pdo, array $booking, string $newStatus, string $changedByType, ?int $changedById, string $remarks): void
    {
        $bookingId = (int) $booking['id'];
        $now = date('Y-m-d H:i:s');
        $updateData = ['status' => $newStatus, 'updated_at' => $now];
        if ($newStatus === 'Assigned' && empty($booking['assigned_at'])) {
            $updateData['assigned_at'] = $now;
        }
        if ($newStatus === 'Accepted' && empty($booking['accepted_at'])) {
            $updateData['accepted_at'] = $now;
        }
        if ($newStatus === 'Ongoing' && empty($booking['started_at'])) {
            $updateData['started_at'] = $now;
        }
        if ($newStatus === 'Completed') {
            $updateData['completed_at'] = $now;
        }
        if ($newStatus === 'Cancelled') {
            $updateData['cancelled_at'] = $now;
        }

        $assignments = [];
        $params = [];
        foreach ($updateData as $column => $value) {
            $assignments[] = $column . ' = ?';
            $params[] = $value;
        }
        $params[] = $bookingId;
        $pdo->prepare('UPDATE bookings SET ' . implode(', ', $assignments) . ' WHERE id = ?')->execute($params);

        if (!empty($booking['rider_id'])) {
            if (in_array($newStatus, ['Assigned', 'Accepted', 'Ongoing'], true)) {
                $pdo->prepare('UPDATE riders SET status = ?, last_seen_at = ?, updated_at = ? WHERE id = ?')
                    ->execute(['Busy', $now, $now, (int) $booking['rider_id']]);
            }
            if (in_array($newStatus, ['Completed', 'Cancelled'], true)) {
                $this->releaseRiderIfIdle($pdo, (int) $booking['rider_id'], $bookingId);
            }
        }

        $this->recordTripHistory($pdo, $bookingId, (string) $booking['status'], $newStatus, $remarks, $changedByType, $changedById);
    }
}

<?php

namespace App\Services;

use App\Core\Database;
use App\Models\NotificationLog;

class NotificationService
{
    protected NotificationLog $notificationLog;
    protected EmailNotificationChannel $emailChannel;
    protected LocalSmsGatewayChannel $smsChannel;
    protected SettingService $settings;

    public function __construct()
    {
        $this->notificationLog = new NotificationLog();
        $this->emailChannel = new EmailNotificationChannel();
        $this->smsChannel = new LocalSmsGatewayChannel();
        $this->settings = new SettingService();
    }

    public function notifyAssignedRider(array $booking, array $rider, array $user): void
    {
        $this->queueAssignedRiderNotification($booking, $rider, $user);
    }

    public function queueAssignedRiderNotification(array $booking, array $rider = [], array $user = []): void
    {
        if (!$booking) {
            return;
        }

        $terminalName = (string) ($this->settings->get('terminal_name', app_name()) ?: app_name());
        $rider = $rider ?: [
            'id' => $booking['rider_id'] ?? 0,
            'full_name' => $booking['rider_name'] ?? 'Rider',
            'phone' => $booking['rider_phone'] ?? '',
            'email' => $booking['rider_email'] ?? '',
            'tricycle_number' => $booking['tricycle_number'] ?? '',
        ];
        $user = $user ?: [
            'full_name' => $booking['user_name'] ?? 'Passenger',
            'phone' => $booking['user_phone'] ?? '',
        ];

        $subject = '[' . $terminalName . '] New ride assignment - ' . $booking['booking_reference'];
        $message = $this->buildPlainMessage($booking, $rider, $user, $terminalName);

        if ((string) ($rider['email'] ?? '') !== '') {
            $this->queue((int) $booking['id'], (int) ($rider['id'] ?? 0), 'email', (string) $rider['email'], $subject, $message);
        }

        if ((string) $this->settings->get('sms_enabled', '0') === '1' && (string) ($rider['phone'] ?? '') !== '') {
            $this->queue((int) $booking['id'], (int) ($rider['id'] ?? 0), 'sms', (string) $rider['phone'], $subject, $message);
        }
    }

    public function processPendingQueue(int $limit = 20): void
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            "SELECT * FROM notifications WHERE status = 'queued' AND (available_at IS NULL OR available_at <= ?) ORDER BY id ASC LIMIT " . (int) $limit
        );
        $now = date('Y-m-d H:i:s');
        $stmt->execute([$now]);
        $jobs = $stmt->fetchAll() ?: [];

        foreach ($jobs as $job) {
            $this->processJob($job);
        }
    }

    protected function processJob(array $job): void
    {
        $message = (string) ($job['message'] ?? '');
        $subject = (string) ($job['subject'] ?? 'Ride assignment');
        $channel = (string) ($job['channel'] ?? 'email');
        $recipient = (string) ($job['recipient'] ?? '');

        if ($channel === 'sms') {
            $result = $this->smsChannel->send($recipient, $message);
        } else {
            $result = $this->emailChannel->send($recipient, 'Rider', $subject, nl2br(e($message)), $message);
        }

        $status = (string) ($result['status'] ?? 'failed');
        $attempts = ((int) ($job['attempts'] ?? 0)) + 1;
        $data = [
            'status' => $status === 'sent' ? 'sent' : ($attempts >= 3 ? 'failed' : 'queued'),
            'attempts' => $attempts,
            'available_at' => $status === 'sent' ? null : date('Y-m-d H:i:s', time() + 300),
            'sent_at' => $status === 'sent' ? date('Y-m-d H:i:s') : null,
            'error_message' => $result['error'] ?? null,
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        $this->notificationLog->updateById((int) $job['id'], $data);
    }

    protected function queue(int $bookingId, int $riderId, string $channel, string $recipient, string $subject, string $message): void
    {
        $this->notificationLog->insert([
            'booking_id' => $bookingId,
            'rider_id' => $riderId,
            'channel' => $channel,
            'recipient' => $recipient,
            'subject' => $subject,
            'message' => $message,
            'status' => 'queued',
            'attempts' => 0,
            'available_at' => date('Y-m-d H:i:s'),
            'sent_at' => null,
            'error_message' => null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
    }

    protected function buildPlainMessage(array $booking, array $rider, array $user, string $terminalName): string
    {
        return implode("\n", [
            $terminalName . ' ride assignment',
            'Booking Reference: ' . $booking['booking_reference'],
            'Passenger: ' . ($user['full_name'] ?? 'Passenger'),
            'Passenger Contact: ' . ($booking['contact_number'] ?? $user['phone'] ?? 'N/A'),
            'Pickup: ' . ($booking['pickup_location'] ?? 'N/A'),
            'Drop-off: ' . ($booking['dropoff_location'] ?? 'N/A'),
            'Tricycle Number: ' . ($rider['tricycle_number'] ?? 'N/A'),
            'Booking Status: ' . ($booking['status'] ?? 'Assigned'),
            'Booked At: ' . format_datetime($booking['created_at'] ?? date('Y-m-d H:i:s')),
        ]);
    }
}

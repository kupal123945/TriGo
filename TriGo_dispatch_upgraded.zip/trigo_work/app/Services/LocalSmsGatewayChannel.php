<?php

namespace App\Services;

class LocalSmsGatewayChannel
{
    protected SettingService $settings;

    public function __construct()
    {
        $this->settings = new SettingService();
    }

    public function send(string $recipient, string $message): array
    {
        $settings = $this->settings->all();

        if (($settings['sms_enabled'] ?? '0') !== '1') {
            return ['status' => 'pending', 'error' => 'SMS gateway is disabled.'];
        }

        if (trim($recipient) === '') {
            return ['status' => 'failed', 'error' => 'Rider phone number is missing.'];
        }

        $url = trim((string) ($settings['sms_gateway_url'] ?? ''));
        if ($url === '') {
            return ['status' => 'failed', 'error' => 'SMS gateway URL is missing.'];
        }

        $method = strtoupper((string) ($settings['sms_http_method'] ?? 'POST'));
        $payload = [
            (string) ($settings['sms_recipient_param'] ?: 'to') => $recipient,
            (string) ($settings['sms_message_param'] ?: 'message') => $message,
        ];

        if (trim((string) ($settings['sms_token'] ?? '')) !== '') {
            $payload[(string) ($settings['sms_token_param'] ?: 'token')] = (string) $settings['sms_token'];
        }

        $headers = ['Accept: application/json'];
        if (trim((string) ($settings['sms_auth_header'] ?? '')) !== '') {
            $headers[] = trim((string) $settings['sms_auth_header']);
        }

        if (function_exists('curl_init')) {
            $ch = curl_init();
            if ($method === 'GET') {
                $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($payload);
            }

            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => $headers,
            ]);

            if ($method !== 'GET') {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
            }

            $response = curl_exec($ch);
            $error = curl_error($ch);
            $statusCode = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            curl_close($ch);

            if ($response !== false && $statusCode >= 200 && $statusCode < 300) {
                return ['status' => 'sent'];
            }

            return ['status' => 'failed', 'error' => $error !== '' ? $error : 'Gateway returned HTTP ' . $statusCode];
        }

        $contextOptions = [
            'http' => [
                'method' => $method,
                'timeout' => 20,
                'header' => implode("\r\n", array_merge($headers, ['Content-Type: application/x-www-form-urlencoded'])),
            ],
        ];

        if ($method === 'GET') {
            $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($payload);
        } else {
            $contextOptions['http']['content'] = http_build_query($payload);
        }

        $result = @file_get_contents($url, false, stream_context_create($contextOptions));
        return $result !== false
            ? ['status' => 'sent']
            : ['status' => 'failed', 'error' => 'Could not reach local SMS gateway.'];
    }
}

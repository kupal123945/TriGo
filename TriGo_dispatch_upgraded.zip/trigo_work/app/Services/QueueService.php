<?php

namespace App\Services;

use PDO;

class QueueService
{
    public function lockOrderedActiveRiders(PDO $pdo): array
    {
        $stmt = $pdo->query("SELECT * FROM riders WHERE active = 1 ORDER BY queue_position ASC, id ASC FOR UPDATE");
        $riders = $stmt->fetchAll() ?: [];

        if (!$riders) {
            return [];
        }

        return $riders;
    }

    public function findNextAvailable(array $riders): ?array
    {
        foreach ($riders as $rider) {
            if (($rider['status'] ?? '') === 'Available') {
                return $rider;
            }
        }

        return null;
    }

    public function reorderAfterAssignment(array $riders, int $assignedRiderId): array
    {
        $ordered = [];
        $assigned = null;

        foreach ($riders as $rider) {
            if ((int) $rider['id'] === $assignedRiderId) {
                $assigned = $rider;
                continue;
            }
            $ordered[] = $rider;
        }

        if ($assigned !== null) {
            $ordered[] = $assigned;
        }

        foreach ($ordered as $index => &$rider) {
            $rider['queue_position'] = $index + 1;
        }
        unset($rider);

        return $ordered;
    }

    public function persistQueue(PDO $pdo, array $orderedRiders): void
    {
        $stmt = $pdo->query('SELECT * FROM riders ORDER BY queue_position ASC, id ASC FOR UPDATE');
        $allRiders = $stmt->fetchAll() ?: [];

        if (!$allRiders) {
            $pdo->exec('DELETE FROM rider_queue');
            return;
        }

        $orderedMap = [];
        $finalQueue = [];

        foreach ($orderedRiders as $rider) {
            $orderedMap[(int) $rider['id']] = true;
            $finalQueue[] = $rider;
        }

        foreach ($allRiders as $rider) {
            if (!isset($orderedMap[(int) $rider['id']])) {
                $finalQueue[] = $rider;
            }
        }

        foreach ($finalQueue as $index => &$rider) {
            $rider['queue_position'] = $index + 1;
        }
        unset($rider);

        $updateRider = $pdo->prepare('UPDATE riders SET queue_position = ?, updated_at = ? WHERE id = ?');
        $insertQueue = $pdo->prepare(
            'INSERT INTO rider_queue (rider_id, queue_position, created_at, updated_at) VALUES (?, ?, ?, ?)'
        );
        $now = date('Y-m-d H:i:s');

        foreach ($finalQueue as $rider) {
            $updateRider->execute([(int) $rider['queue_position'], $now, (int) $rider['id']]);
        }

        $pdo->exec('DELETE FROM rider_queue');

        foreach ($finalQueue as $rider) {
            $insertQueue->execute([(int) $rider['id'], (int) $rider['queue_position'], $now, $now]);
        }
    }

    public function normalizeQueue(PDO $pdo): void
    {
        $stmt = $pdo->query('SELECT * FROM riders ORDER BY queue_position ASC, id ASC FOR UPDATE');
        $riders = $stmt->fetchAll() ?: [];

        foreach ($riders as $index => &$rider) {
            $rider['queue_position'] = $index + 1;
        }
        unset($rider);

        $this->persistQueue($pdo, $riders);
    }

    public function createQueueEntry(PDO $pdo, int $riderId): int
    {
        $max = (int) ($pdo->query('SELECT COALESCE(MAX(queue_position), 0) AS max_position FROM riders')->fetch()['max_position'] ?? 0);
        $position = $max + 1;
        $now = date('Y-m-d H:i:s');

        $pdo->prepare('UPDATE riders SET queue_position = ?, updated_at = ? WHERE id = ?')->execute([$position, $now, $riderId]);
        $pdo->prepare(
            'INSERT INTO rider_queue (rider_id, queue_position, created_at, updated_at) VALUES (?, ?, ?, ?) '
            . 'ON DUPLICATE KEY UPDATE queue_position = VALUES(queue_position), updated_at = VALUES(updated_at)'
        )->execute([$riderId, $position, $now, $now]);

        return $position;
    }

    public function deleteQueueEntry(PDO $pdo, int $riderId): void
    {
        $pdo->prepare('DELETE FROM rider_queue WHERE rider_id = ?')->execute([$riderId]);
    }

    public function updateFromPositions(PDO $pdo, array $positions): void
    {
        $stmt = $pdo->query('SELECT * FROM riders ORDER BY queue_position ASC, id ASC FOR UPDATE');
        $riders = $stmt->fetchAll() ?: [];

        usort($riders, function (array $a, array $b) use ($positions): int {
            $left = (int) ($positions[$a['id']] ?? $a['queue_position']);
            $right = (int) ($positions[$b['id']] ?? $b['queue_position']);
            if ($left === $right) {
                return (int) $a['id'] <=> (int) $b['id'];
            }
            return $left <=> $right;
        });

        foreach ($riders as $index => &$rider) {
            $rider['queue_position'] = $index + 1;
        }
        unset($rider);

        $this->persistQueue($pdo, $riders);
    }
}

<?php

namespace App\Services;

use PHPMailer\PHPMailer\PHPMailer;
use Throwable;

class EmailNotificationChannel
{
    protected SettingService $settings;

    public function __construct()
    {
        $this->settings = new SettingService();
    }

    public function send(string $toEmail, string $toName, string $subject, string $htmlBody, string $textBody): array
    {
        $settings = $this->settings->all();

        if (($settings['smtp_enabled'] ?? '0') !== '1') {
            return ['status' => 'failed', 'error' => 'SMTP email notifications are disabled in system settings.'];
        }

        if (trim($toEmail) === '') {
            return ['status' => 'failed', 'error' => 'Rider email address is missing.'];
        }

        foreach (['smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 'smtp_from_email'] as $requiredKey) {
            if (trim((string) ($settings[$requiredKey] ?? '')) === '') {
                return ['status' => 'failed', 'error' => 'Missing SMTP setting: ' . $requiredKey];
            }
        }

        try {
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = (string) $settings['smtp_host'];
            $mail->Port = (int) $settings['smtp_port'];
            $mail->SMTPAuth = true;
            $mail->Username = (string) $settings['smtp_username'];
            $mail->Password = (string) $settings['smtp_password'];
            $mail->CharSet = 'UTF-8';
            $mail->Timeout = 20;

            $encryption = strtolower((string) ($settings['smtp_encryption'] ?? 'tls'));
            if ($encryption === 'tls' || $encryption === 'starttls') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } elseif ($encryption === 'ssl') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mail->SMTPSecure = '';
                $mail->SMTPAutoTLS = false;
            }

            $mail->setFrom((string) $settings['smtp_from_email'], (string) ($settings['smtp_from_name'] ?: app_name()));
            $mail->addAddress($toEmail, $toName);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $htmlBody;
            $mail->AltBody = $textBody;
            $mail->send();

            return ['status' => 'sent'];
        } catch (Throwable $exception) {
            return ['status' => 'failed', 'error' => $exception->getMessage()];
        }
    }
}

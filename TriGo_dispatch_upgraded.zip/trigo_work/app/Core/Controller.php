<?php

namespace App\Core;

abstract class Controller
{
    protected function render(string $view, array $data = [], string $layout = 'app'): string
    {
        return View::render($view, $data, $layout);
    }

    protected function flashValidationErrors(array $data, array $errors): void
    {
        Session::flash('errors', $errors);
        Session::flash('old', $data);
    }
}

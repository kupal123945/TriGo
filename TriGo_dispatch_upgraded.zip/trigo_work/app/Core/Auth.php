<?php

namespace App\Core;

use PDO;

class Auth
{
    protected static ?array $user = null;
    protected static ?array $admin = null;
    protected static ?array $rider = null;

    public static function user(): ?array
    {
        if (self::$user !== null) {
            return self::$user;
        }

        $id = (int) Session::get('user_id', 0);
        if ($id <= 0) {
            return null;
        }

        $stmt = Database::getConnection()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        if (!$user || (int) ($user['active'] ?? 0) !== 1) {
            self::logoutUser();
            return null;
        }

        self::$user = $user;
        return self::$user;
    }

    public static function admin(): ?array
    {
        if (self::$admin !== null) {
            return self::$admin;
        }

        $id = (int) Session::get('admin_id', 0);
        if ($id <= 0) {
            return null;
        }

        $stmt = Database::getConnection()->prepare('SELECT * FROM admins WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        if (!$admin || (int) ($admin['active'] ?? 0) !== 1) {
            self::logoutAdmin();
            return null;
        }

        self::$admin = $admin;
        return self::$admin;
    }

    public static function rider(): ?array
    {
        if (self::$rider !== null) {
            return self::$rider;
        }

        $id = (int) Session::get('rider_id', 0);
        if ($id <= 0) {
            return null;
        }

        $stmt = Database::getConnection()->prepare('SELECT * FROM riders WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $rider = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        if (!$rider || (int) ($rider['active'] ?? 0) !== 1) {
            self::logoutRider();
            return null;
        }

        self::$rider = $rider;
        return self::$rider;
    }

    public static function loginUser(array $user): void
    {
        Session::set('user_id', (int) $user['id']);
        Session::set('auth_role', 'user');
        self::$user = $user;
    }

    public static function logoutUser(): void
    {
        Session::remove('user_id');
        Session::remove('auth_role');
        self::$user = null;
    }

    public static function loginAdmin(array $admin): void
    {
        Session::set('admin_id', (int) $admin['id']);
        Session::set('auth_role', 'admin');
        self::$admin = $admin;
    }

    public static function logoutAdmin(): void
    {
        Session::remove('admin_id');
        Session::remove('auth_role');
        self::$admin = null;
    }

    public static function loginRider(array $rider): void
    {
        Session::set('rider_id', (int) $rider['id']);
        Session::set('auth_role', 'rider');
        self::$rider = $rider;
    }

    public static function logoutRider(): void
    {
        Session::remove('rider_id');
        Session::remove('auth_role');
        self::$rider = null;
    }

    public static function checkUser(): bool
    {
        return self::user() !== null;
    }

    public static function checkAdmin(): bool
    {
        return self::admin() !== null;
    }

    public static function checkRider(): bool
    {
        return self::rider() !== null;
    }
}

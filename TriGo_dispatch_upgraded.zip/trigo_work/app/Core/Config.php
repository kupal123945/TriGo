<?php

namespace App\Core;

class Config
{
    protected static array $items = [];

    public static function load(): void
    {
        self::$items['app'] = require BASE_PATH . '/config/app.php';
        self::$items['database'] = require BASE_PATH . '/config/database.php';
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $segments = explode('.', $key);
        $value = self::$items;

        foreach ($segments as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }

        return $value;
    }
}

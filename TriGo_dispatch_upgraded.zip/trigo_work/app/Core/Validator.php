<?php

namespace App\Core;

class Validator
{
    public static function validate(array $data, array $rules): array
    {
        $errors = [];

        foreach ($rules as $field => $ruleSet) {
            $value = $data[$field] ?? null;
            $rulesForField = is_array($ruleSet) ? $ruleSet : explode('|', (string) $ruleSet);
            $nullable = in_array('nullable', $rulesForField, true);

            if ($nullable && ($value === null || $value === '')) {
                continue;
            }

            foreach ($rulesForField as $rule) {
                [$name, $parameter] = array_pad(explode(':', (string) $rule, 2), 2, null);
                if ($name === 'nullable') {
                    continue;
                }

                if ($name === 'required' && ($value === null || trim((string) $value) === '')) {
                    $errors[$field] = 'This field is required.';
                    break;
                }

                if ($value === null || $value === '') {
                    continue;
                }

                if ($name === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$field] = 'Please enter a valid email address.';
                    break;
                }

                if ($name === 'min' && mb_strlen((string) $value) < (int) $parameter) {
                    $errors[$field] = 'This field must be at least ' . (int) $parameter . ' characters.';
                    break;
                }

                if ($name === 'max' && mb_strlen((string) $value) > (int) $parameter) {
                    $errors[$field] = 'This field must not exceed ' . (int) $parameter . ' characters.';
                    break;
                }

                if ($name === 'numeric' && !is_numeric($value)) {
                    $errors[$field] = 'This field must be numeric.';
                    break;
                }

                if ($name === 'phone') {
                    $normalized = preg_replace('/[^0-9+]/', '', (string) $value);
                    if ($normalized === null || !preg_match('/^(\+63|0)?[0-9]{10,12}$/', $normalized)) {
                        $errors[$field] = 'Please enter a valid contact number.';
                        break;
                    }
                }

                if ($name === 'in') {
                    $allowed = array_map('trim', explode(',', (string) $parameter));
                    if (!in_array((string) $value, $allowed, true)) {
                        $errors[$field] = 'The selected value is invalid.';
                        break;
                    }
                }

                if ($name === 'confirmed') {
                    if ((string) $value !== (string) ($data[$field . '_confirmation'] ?? null)) {
                        $errors[$field] = 'The confirmation does not match.';
                        break;
                    }
                }

                if ($name === 'unique' && $parameter !== null) {
                    [$table, $column, $exceptId] = array_pad(array_map('trim', explode(',', $parameter)), 3, null);
                    $column = $column ?: $field;
                    $sql = "SELECT id FROM {$table} WHERE {$column} = ?";
                    $params = [$value];

                    if ($exceptId !== null && $exceptId !== '') {
                        $sql .= ' AND id != ?';
                        $params[] = $exceptId;
                    }

                    $sql .= ' LIMIT 1';
                    $stmt = Database::getConnection()->prepare($sql);
                    $stmt->execute($params);

                    if ($stmt->fetch()) {
                        $errors[$field] = 'This value is already in use.';
                        break;
                    }
                }
            }
        }

        return $errors;
    }
}

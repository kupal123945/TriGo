<?php

namespace App\Core;

class Request
{
    protected string $method;
    protected string $path;
    protected array $routeParams = [];

    public function __construct()
    {
        $this->method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $this->path = $this->resolvePath();
    }

    protected function resolvePath(): string
    {
        $uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        $scriptDir = $scriptDir === '/' ? '' : rtrim($scriptDir, '/');

        if ($scriptDir && str_starts_with($uriPath, $scriptDir)) {
            $path = substr($uriPath, strlen($scriptDir));
        } else {
            $path = $uriPath;
        }

        $path = '/' . ltrim((string) $path, '/');
        $path = rtrim($path, '/');
        return $path === '' ? '/' : $path;
    }

    public function method(): string
    {
        return $this->method;
    }

    public function path(): string
    {
        return $this->path;
    }

    public function query(string $key, mixed $default = null): mixed
    {
        return $_GET[$key] ?? $default;
    }

    public function post(string $key, mixed $default = null): mixed
    {
        return $_POST[$key] ?? $default;
    }

    public function input(string $key, mixed $default = null): mixed
    {
        return $_POST[$key] ?? $_GET[$key] ?? $this->routeParams[$key] ?? $default;
    }

    public function all(): array
    {
        return array_merge($_GET, $_POST, $this->routeParams);
    }

    public function setRouteParams(array $params): void
    {
        $this->routeParams = $params;
    }

    public function route(string $key, mixed $default = null): mixed
    {
        return $this->routeParams[$key] ?? $default;
    }

    public function routeParams(): array
    {
        return $this->routeParams;
    }

    public function ip(): string
    {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}

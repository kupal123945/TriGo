<?php

namespace App\Core;

class Response
{
    public static function redirect(string $path, int $status = 302): never
    {
        $destination = preg_match('#^https?://#i', $path) ? $path : url($path);
        header('Location: ' . $destination, true, $status);
        exit;
    }
}

<?php

namespace App\Core;

use ErrorException;
use Throwable;

class App
{
    public static function run(): void
    {
        Config::load();
        date_default_timezone_set((string) Config::get('app.timezone', 'Asia/Manila'));
        Session::start();

        set_error_handler(function (int $severity, string $message, string $file = '', int $line = 0): void {
            if (!(error_reporting() & $severity)) {
                return;
            }

            throw new ErrorException($message, 0, $severity, $file, $line);
        });

        set_exception_handler(function (Throwable $throwable): void {
            self::renderException($throwable);
        });

        $request = new Request();
        $router = new Router();
        $router->middleware(\App\Middleware\CsrfMiddleware::class);

        require BASE_PATH . '/routes/web.php';

        $router->dispatch($request);
    }

    protected static function renderException(Throwable $throwable): void
    {
        error_log($throwable->__toString());
        http_response_code(500);

        $message = (bool) Config::get('app.debug', false)
            ? $throwable->getMessage()
            : 'An unexpected error occurred. Please check your configuration and try again.';

        echo View::render('errors.500', [
            'pageTitle' => 'Server Error',
            'message' => $message,
        ], is_admin_logged_in() ? 'admin' : 'app');
    }
}

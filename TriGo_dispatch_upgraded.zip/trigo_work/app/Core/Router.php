<?php

namespace App\Core;

class Router
{
    protected array $routes = [];
    protected array $globalMiddlewares = [];

    public function middleware(string $middleware): void
    {
        $this->globalMiddlewares[] = $middleware;
    }

    public function get(string $path, mixed $action, array $middlewares = []): void
    {
        $this->addRoute('GET', $path, $action, $middlewares);
    }

    public function post(string $path, mixed $action, array $middlewares = []): void
    {
        $this->addRoute('POST', $path, $action, $middlewares);
    }

    protected function addRoute(string $method, string $path, mixed $action, array $middlewares = []): void
    {
        $normalized = '/' . ltrim($path, '/');
        $normalized = rtrim($normalized, '/');
        $normalized = $normalized === '' ? '/' : $normalized;

        $this->routes[] = [
            'method' => $method,
            'path' => $normalized,
            'action' => $action,
            'middlewares' => $middlewares,
        ];
    }

    public function dispatch(Request $request): void
    {
        foreach ($this->routes as $route) {
            if ($route['method'] !== $request->method()) {
                continue;
            }

            $params = $this->match($route['path'], $request->path());
            if ($params === null) {
                continue;
            }

            $request->setRouteParams($params);
            $middlewares = array_merge($this->globalMiddlewares, $route['middlewares']);

            $runner = array_reduce(
                array_reverse($middlewares),
                function (callable $next, string $middleware): callable {
                    return function (Request $request) use ($middleware, $next): mixed {
                        $instance = new $middleware();
                        return $instance->handle($request, $next);
                    };
                },
                fn (Request $request): mixed => $this->invokeAction($route['action'], $request)
            );

            $response = $runner($request);

            if (is_string($response)) {
                echo $response;
            }

            return;
        }

        http_response_code(404);
        echo View::render('errors.404', [
            'pageTitle' => 'Page Not Found',
            'message' => 'The page you requested could not be found.',
        ], is_admin_logged_in() ? 'admin' : 'app');
    }

    protected function invokeAction(mixed $action, Request $request): mixed
    {
        if (is_callable($action)) {
            return $action($request);
        }

        if (is_array($action) && count($action) === 2) {
            [$class, $method] = $action;
            $controller = new $class();
            return $controller->{$method}($request);
        }

        throw new \RuntimeException('Invalid route action.');
    }

    protected function match(string $routePath, string $requestPath): ?array
    {
        if ($routePath === '/' && $requestPath === '/') {
            return [];
        }

        $routeSegments = explode('/', trim($routePath, '/'));
        $requestSegments = explode('/', trim($requestPath, '/'));

        if (count($routeSegments) !== count($requestSegments)) {
            return null;
        }

        $params = [];

        foreach ($routeSegments as $index => $routeSegment) {
            $requestSegment = $requestSegments[$index] ?? '';

            if (preg_match('/^\{([a-zA-Z_][a-zA-Z0-9_]*)\}$/', $routeSegment, $matches)) {
                $params[$matches[1]] = urldecode($requestSegment);
                continue;
            }

            if ($routeSegment !== $requestSegment) {
                return null;
            }
        }

        return $params;
    }
}

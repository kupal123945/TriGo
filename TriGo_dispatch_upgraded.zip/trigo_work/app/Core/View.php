<?php

namespace App\Core;

use RuntimeException;

class View
{
    public static function render(string $view, array $data = [], string $layout = 'app'): string
    {
        $viewFile = BASE_PATH . '/resources/views/' . str_replace('.', '/', $view) . '.blade.php';
        if (!file_exists($viewFile)) {
            throw new RuntimeException('View not found: ' . $view);
        }

        extract($data, EXTR_SKIP);

        ob_start();
        include $viewFile;
        $content = (string) ob_get_clean();

        if ($layout === 'none') {
            return $content;
        }

        $layoutFile = BASE_PATH . '/resources/views/layouts/' . $layout . '.blade.php';
        if (!file_exists($layoutFile)) {
            return $content;
        }

        ob_start();
        include $layoutFile;
        return (string) ob_get_clean();
    }

    public static function partial(string $view, array $data = []): void
    {
        $viewFile = BASE_PATH . '/resources/views/' . str_replace('.', '/', $view) . '.blade.php';
        if (!file_exists($viewFile)) {
            throw new RuntimeException('Partial not found: ' . $view);
        }

        extract($data, EXTR_SKIP);
        include $viewFile;
    }
}

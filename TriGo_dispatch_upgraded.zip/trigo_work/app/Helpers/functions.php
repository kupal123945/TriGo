<?php

use App\Core\Auth;
use App\Core\Config;
use App\Core\Csrf;
use App\Core\Session;
use App\Core\View;

if (!function_exists('e')) {
    function e(mixed $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('app_name')) {
    function app_name(): string
    {
        return (string) Config::get('app.name', 'Terminal Tricycle Dispatch');
    }
}

if (!function_exists('base_url')) {
    function base_url(): string
    {
        $configured = trim((string) Config::get('app.base_url', ''));
        if ($configured !== '') {
            return rtrim($configured, '/');
        }

        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        $scriptDir = $scriptDir === '/' ? '' : rtrim($scriptDir, '/');
        return $scheme . '://' . $host . $scriptDir;
    }
}

if (!function_exists('url')) {
    function url(string $path = ''): string
    {
        $path = '/' . ltrim($path, '/');
        if ($path === '/') {
            $path = '';
        }
        return base_url() . $path;
    }
}

if (!function_exists('asset')) {
    function asset(string $path): string
    {
        return url('/assets/' . ltrim($path, '/'));
    }
}

if (!function_exists('current_path')) {
    function current_path(): string
    {
        $uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        $scriptDir = $scriptDir === '/' ? '' : rtrim($scriptDir, '/');

        if ($scriptDir && str_starts_with($uriPath, $scriptDir)) {
            $path = substr($uriPath, strlen($scriptDir));
        } else {
            $path = $uriPath;
        }

        $path = '/' . ltrim((string) $path, '/');
        $path = rtrim($path, '/');

        return $path === '' ? '/' : $path;
    }
}

if (!function_exists('route_is')) {
    function route_is(string $pattern): bool
    {
        $path = current_path();
        $pattern = '/' . ltrim($pattern, '/');
        $pattern = rtrim($pattern, '/');
        $pattern = $pattern === '' ? '/' : $pattern;
        $regex = '#^' . str_replace('\\*', '.*', preg_quote($pattern, '#')) . '$#';
        return (bool) preg_match($regex, $path);
    }
}

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        return Csrf::token();
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field(): string
    {
        return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
    }
}

if (!function_exists('old')) {
    function old(string $key, mixed $default = ''): mixed
    {
        $old = Session::getFlash('old', []);
        return $old[$key] ?? $default;
    }
}

if (!function_exists('form_error')) {
    function form_error(string $key): ?string
    {
        $errors = Session::getFlash('errors', []);
        return $errors[$key] ?? null;
    }
}

if (!function_exists('flash_success')) {
    function flash_success(): ?string
    {
        $value = Session::getFlash('success');
        return is_string($value) ? $value : null;
    }
}

if (!function_exists('flash_error')) {
    function flash_error(): ?string
    {
        $value = Session::getFlash('error');
        return is_string($value) ? $value : null;
    }
}

if (!function_exists('current_user')) {
    function current_user(): ?array
    {
        return Auth::user();
    }
}

if (!function_exists('current_admin')) {
    function current_admin(): ?array
    {
        return Auth::admin();
    }
}

if (!function_exists('current_rider')) {
    function current_rider(): ?array
    {
        return Auth::rider();
    }
}

if (!function_exists('is_user_logged_in')) {
    function is_user_logged_in(): bool
    {
        return Auth::checkUser();
    }
}

if (!function_exists('is_admin_logged_in')) {
    function is_admin_logged_in(): bool
    {
        return Auth::checkAdmin();
    }
}

if (!function_exists('is_rider_logged_in')) {
    function is_rider_logged_in(): bool
    {
        return Auth::checkRider();
    }
}

if (!function_exists('selected')) {
    function selected(mixed $actual, mixed $expected): string
    {
        return (string) $actual === (string) $expected ? 'selected' : '';
    }
}

if (!function_exists('checked')) {
    function checked(mixed $actual, mixed $expected): string
    {
        return (string) $actual === (string) $expected ? 'checked' : '';
    }
}

if (!function_exists('format_datetime')) {
    function format_datetime(?string $value): string
    {
        if (!$value) {
            return '—';
        }

        try {
            return (new DateTimeImmutable($value))->format('M d, Y h:i A');
        } catch (Throwable) {
            return $value;
        }
    }
}

if (!function_exists('format_currency')) {
    function format_currency(float|int|string|null $value): string
    {
        $number = $value === null ? 0.0 : (float) $value;
        return 'PHP ' . number_format($number, 2);
    }
}

if (!function_exists('normalize_phone')) {
    function normalize_phone(?string $value): string
    {
        $digits = preg_replace('/[^0-9+]/', '', (string) $value) ?? '';
        if (str_starts_with($digits, '+63')) {
            return $digits;
        }
        if (str_starts_with($digits, '63')) {
            return '+' . $digits;
        }
        if (str_starts_with($digits, '0')) {
            return '+63' . substr($digits, 1);
        }
        return $digits;
    }
}

if (!function_exists('status_badge_class')) {
    function status_badge_class(string $status): string
    {
        return match ($status) {
            'Assigned' => 'bg-primary-subtle text-primary',
            'Accepted' => 'bg-info-subtle text-info',
            'Ongoing' => 'bg-info-subtle text-info',
            'Completed' => 'bg-success-subtle text-success',
            'Cancelled' => 'bg-warning-subtle text-warning',
            'Failed / No Rider Available' => 'bg-danger-subtle text-danger',
            default => 'bg-secondary-subtle text-secondary',
        };
    }
}

if (!function_exists('rider_status_badge_class')) {
    function rider_status_badge_class(string $status): string
    {
        return match ($status) {
            'Available' => 'bg-success-subtle text-success',
            'Busy' => 'bg-warning-subtle text-warning',
            'Paused' => 'bg-info-subtle text-info',
            'Offline' => 'bg-secondary-subtle text-secondary',
            default => 'bg-secondary-subtle text-secondary',
        };
    }
}

if (!function_exists('view_partial')) {
    function view_partial(string $view, array $data = []): void
    {
        View::partial($view, $data);
    }
}

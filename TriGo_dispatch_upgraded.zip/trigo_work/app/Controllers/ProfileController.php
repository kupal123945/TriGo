<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Models\User;
use App\Services\ActivityLogService;

class ProfileController extends Controller
{
    protected User $userModel;
    protected ActivityLogService $activityLog;

    public function __construct()
    {
        $this->userModel = new User();
        $this->activityLog = new ActivityLogService();
    }

    public function edit(Request $request): string
    {
        return $this->render('user.profile', [
            'pageTitle' => 'Profile',
            'user' => Auth::user(),
        ]);
    }

    public function update(Request $request): never
    {
        $currentUser = Auth::user();
        $userId = (int) ($currentUser['id'] ?? 0);

        $data = [
            'full_name' => trim((string) $request->post('full_name')),
            'email' => trim((string) $request->post('email')),
            'phone' => trim((string) $request->post('phone')),
            'address' => trim((string) $request->post('address')),
            'password' => (string) $request->post('password'),
            'password_confirmation' => (string) $request->post('password_confirmation'),
        ];

        $errors = Validator::validate($data, [
            'full_name' => 'required|min:3|max:150',
            'email' => 'required|email|unique:users,email,' . $userId,
            'phone' => 'required|min:7|max:30',
            'address' => 'nullable|max:255',
            'password' => 'nullable|min:8|confirmed',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/profile');
        }

        $payload = [
            'full_name' => $data['full_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'address' => $data['address'],
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        if ($data['password'] !== '') {
            $payload['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }

        $this->userModel->updateById($userId, $payload);
        $updatedUser = $this->userModel->find($userId);
        if ($updatedUser) {
            Auth::loginUser($updatedUser);
        }

        $this->activityLog->log('user', $userId, 'profile.update', 'User updated profile information.', $request->ip());
        Session::flash('success', 'Profile updated successfully.');
        Response::redirect('/profile');
    }
}

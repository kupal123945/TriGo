<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;

class AdminActivityLogController extends Controller
{
    public function index(Request $request): string
    {
        $actorType = trim((string) $request->query('actor_type', ''));
        $q = trim((string) $request->query('q', ''));

        $sql = 'SELECT * FROM activity_logs WHERE 1 = 1';
        $params = [];

        if ($actorType !== '') {
            $sql .= ' AND actor_type = ?';
            $params[] = $actorType;
        }

        if ($q !== '') {
            $sql .= ' AND (action LIKE ? OR description LIKE ? OR ip_address LIKE ?)';
            $like = '%' . $q . '%';
            $params = array_merge($params, [$like, $like, $like]);
        }

        $sql .= ' ORDER BY created_at DESC LIMIT 200';

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        return $this->render('admin.activity_logs.index', [
            'pageTitle' => 'Activity Logs',
            'logs' => $stmt->fetchAll() ?: [],
            'filters' => [
                'actor_type' => $actorType,
                'q' => $q,
            ],
        ], 'admin');
    }
}

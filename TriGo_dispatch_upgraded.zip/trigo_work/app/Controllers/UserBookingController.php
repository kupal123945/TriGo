<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Services\BookingService;
use App\Services\DispatchService;
use App\Services\FareService;
use App\Services\OperationsMaintenanceService;
use Throwable;

class UserBookingController extends Controller
{
    protected BookingService $bookingService;
    protected DispatchService $dispatchService;
    protected FareService $fareService;

    public function __construct()
    {
        $this->bookingService = new BookingService();
        $this->dispatchService = new DispatchService();
        $this->fareService = new FareService();
        (new OperationsMaintenanceService())->run();
    }

    public function create(Request $request): string
    {
        $user = Auth::user();
        $userId = (int) ($user['id'] ?? 0);

        if ($this->bookingService->userHasActiveBooking($userId)) {
            Session::flash('error', 'You already have an active booking.');
            Response::redirect('/bookings/current');
        }

        return $this->render('user.bookings.create', [
            'pageTitle' => 'Book a Tricycle',
            'fareEstimate' => $this->fareService->estimateFare(),
            'user' => $user,
        ]);
    }

    public function store(Request $request): never
    {
        $user = Auth::user();
        $userId = (int) ($user['id'] ?? 0);

        if ($this->bookingService->userHasActiveBooking($userId)) {
            Session::flash('error', 'Only one active booking is allowed per user.');
            Response::redirect('/bookings/current');
        }

        $data = [
            'pickup_location' => trim((string) $request->post('pickup_location')),
            'dropoff_location' => trim((string) $request->post('dropoff_location')),
            'contact_number' => trim((string) $request->post('contact_number')),
            'notes' => trim((string) $request->post('notes')),
        ];

        $errors = Validator::validate($data, [
            'pickup_location' => 'required|min:3|max:255',
            'dropoff_location' => 'required|min:3|max:255',
            'contact_number' => 'required|phone|max:30',
            'notes' => 'nullable|max:500',
        ]);

        if ($this->bookingService->hasRecentDuplicateBooking($userId, $data['pickup_location'], $data['dropoff_location'])) {
            $errors['pickup_location'] = 'A similar booking was submitted recently. Please wait before trying again.';
        }

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/bookings/create');
        }

        $data['contact_number'] = normalize_phone($data['contact_number']);
        unset($_POST['rider_id']);

        try {
            $booking = $this->dispatchService->createBookingAndDispatch($userId, $data, $request->ip());
        } catch (Throwable $exception) {
            Session::flash('error', 'Could not create booking: ' . $exception->getMessage());
            Session::flash('old', $data);
            Response::redirect('/bookings/create');
        }

        if (($booking['status'] ?? '') === 'Failed / No Rider Available') {
            Session::flash('error', 'Booking saved, but no rider is available at the moment.');
        } else {
            Session::flash('success', 'Booking submitted successfully. Your rider has been assigned immediately.');
        }

        Response::redirect('/bookings/' . $booking['booking_reference']);
    }

    public function current(Request $request): string
    {
        $user = Auth::user();
        $booking = $this->bookingService->getActiveBookingForUser((int) ($user['id'] ?? 0));

        return $this->render('user.bookings.current', [
            'pageTitle' => 'Current Booking',
            'booking' => $booking,
            'canCancel' => $booking ? $this->bookingService->canUserCancel($booking) : false,
        ]);
    }

    public function history(Request $request): string
    {
        $user = Auth::user();
        return $this->render('user.bookings.history', [
            'pageTitle' => 'Booking History',
            'bookings' => $this->bookingService->listBookingsForUser((int) ($user['id'] ?? 0)),
        ]);
    }

    public function show(Request $request): string
    {
        $user = Auth::user();
        $booking = $this->bookingService->getBookingByReferenceForUser((int) ($user['id'] ?? 0), (string) $request->route('reference'));

        if (!$booking) {
            http_response_code(404);
            return $this->render('errors.404', [
                'pageTitle' => 'Booking Not Found',
                'message' => 'The booking you requested does not exist or does not belong to your account.',
            ]);
        }

        return $this->render('user.bookings.show', [
            'pageTitle' => 'Booking Details',
            'booking' => $booking,
            'canCancel' => $this->bookingService->canUserCancel($booking),
        ]);
    }

    public function cancel(Request $request): never
    {
        $user = Auth::user();
        $booking = $this->bookingService->getBookingDetailsById((int) $request->route('id'));

        if (!$booking || (int) $booking['user_id'] !== (int) ($user['id'] ?? 0)) {
            Session::flash('error', 'Booking not found.');
            Response::redirect('/bookings/history');
        }

        try {
            $this->bookingService->cancelByUser((int) $booking['id'], (int) $user['id'], $request->ip());
            Session::flash('success', 'Booking cancelled successfully.');
        } catch (Throwable $exception) {
            Session::flash('error', $exception->getMessage());
        }

        Response::redirect('/bookings/' . $booking['booking_reference']);
    }
}

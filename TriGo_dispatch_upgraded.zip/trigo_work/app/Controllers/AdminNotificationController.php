<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;

class AdminNotificationController extends Controller
{
    public function index(Request $request): string
    {
        $channel = trim((string) $request->query('channel', ''));
        $status = trim((string) $request->query('status', ''));
        $q = trim((string) $request->query('q', ''));

        $sql = 'SELECT n.*, b.booking_reference, r.full_name AS rider_name '
            . 'FROM notifications n '
            . 'LEFT JOIN bookings b ON b.id = n.booking_id '
            . 'LEFT JOIN riders r ON r.id = n.rider_id WHERE 1 = 1';
        $params = [];

        if ($channel !== '') {
            $sql .= ' AND n.channel = ?';
            $params[] = $channel;
        }

        if ($status !== '') {
            $sql .= ' AND n.status = ?';
            $params[] = $status;
        }

        if ($q !== '') {
            $sql .= ' AND (n.recipient LIKE ? OR b.booking_reference LIKE ? OR r.full_name LIKE ?)';
            $like = '%' . $q . '%';
            $params = array_merge($params, [$like, $like, $like]);
        }

        $sql .= ' ORDER BY n.created_at DESC';

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        return $this->render('admin.notifications.index', [
            'pageTitle' => 'Notification Logs',
            'notifications' => $stmt->fetchAll() ?: [],
            'filters' => [
                'channel' => $channel,
                'status' => $status,
                'q' => $q,
            ],
        ], 'admin');
    }
}

<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Services\BookingService;

class UserDashboardController extends Controller
{
    protected BookingService $bookingService;

    public function __construct()
    {
        $this->bookingService = new BookingService();
    }

    public function index(Request $request): string
    {
        $user = Auth::user();
        $userId = (int) ($user['id'] ?? 0);

        return $this->render('user.dashboard', [
            'pageTitle' => 'Dashboard',
            'activeBooking' => $this->bookingService->getActiveBookingForUser($userId),
            'bookings' => $this->bookingService->listBookingsForUser($userId, 10),
        ]);
    }
}

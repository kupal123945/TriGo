<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Admin;
use App\Models\Rider;
use App\Models\User;
use App\Services\ActivityLogService;
use App\Services\SecurityService;
use RuntimeException;
use Throwable;

class AuthController extends Controller
{
    protected User $userModel;
    protected Admin $adminModel;
    protected Rider $riderModel;
    protected ActivityLogService $activityLog;
    protected SecurityService $security;

    public function __construct()
    {
        $this->userModel = new User();
        $this->adminModel = new Admin();
        $this->riderModel = new Rider();
        $this->activityLog = new ActivityLogService();
        $this->security = new SecurityService();
    }

    public function showLogin(Request $request): string
    {
        return $this->render('auth.login', ['pageTitle' => 'User Login']);
    }

    public function showRegister(Request $request): string
    {
        return $this->render('auth.register', ['pageTitle' => 'Register']);
    }

    public function login(Request $request): never
    {
        $data = [
            'email' => trim((string) $request->post('email')),
            'password' => (string) $request->post('password'),
        ];

        $errors = Validator::validate($data, [
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/login');
        }

        if ($this->security->isLocked('user', strtolower($data['email']), $request->ip())) {
            Session::flash('error', 'Too many login attempts. Please try again later.');
            Session::flash('old', ['email' => $data['email']]);
            Response::redirect('/login');
        }

        $user = $this->userModel->one('SELECT * FROM users WHERE email = ? LIMIT 1', [$data['email']]);

        if (!$user || !password_verify($data['password'], (string) $user['password']) || (int) ($user['active'] ?? 0) !== 1) {
            $this->security->recordFailure('user', strtolower($data['email']), $request->ip());
            Session::flash('error', 'Invalid credentials or inactive account.');
            Session::flash('old', ['email' => $data['email']]);
            Response::redirect('/login');
        }

        $this->security->clearFailures('user', strtolower($data['email']), $request->ip());
        session_regenerate_id(true);
        Auth::loginUser($user);
        $this->activityLog->log('user', (int) $user['id'], 'auth.login', 'User logged in.', $request->ip());
        Session::flash('success', 'Welcome back, ' . $user['full_name'] . '!');
        Response::redirect('/dashboard');
    }

    public function register(Request $request): never
    {
        $data = [
            'full_name' => trim((string) $request->post('full_name')),
            'email' => trim((string) $request->post('email')),
            'phone' => trim((string) $request->post('phone')),
            'address' => trim((string) $request->post('address')),
            'password' => (string) $request->post('password'),
            'password_confirmation' => (string) $request->post('password_confirmation'),
        ];

        $errors = Validator::validate($data, [
            'full_name' => 'required|min:3|max:150',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|phone|max:30',
            'address' => 'nullable|max:255',
            'password' => 'required|min:8|confirmed',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/register');
        }

        $data['phone'] = normalize_phone($data['phone']);

        try {
            $userId = $this->userModel->insert([
                'full_name' => $data['full_name'],
                'email' => $data['email'],
                'password' => password_hash($data['password'], PASSWORD_DEFAULT),
                'phone' => $data['phone'],
                'address' => $data['address'],
                'active' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (Throwable) {
            Session::flash('error', 'Could not create user account. Please verify your database configuration.');
            Session::flash('old', $data);
            Response::redirect('/register');
        }

        $user = $this->userModel->find($userId);
        if (!$user) {
            throw new RuntimeException('User registration failed.');
        }

        session_regenerate_id(true);
        Auth::loginUser($user);
        $this->activityLog->log('user', $userId, 'auth.register', 'User registered a new account.', $request->ip());
        Session::flash('success', 'Account created successfully. You can now book a ride.');
        Response::redirect('/dashboard');
    }

    public function logout(Request $request): never
    {
        if (Auth::checkUser()) {
            $user = Auth::user();
            $this->activityLog->log('user', (int) ($user['id'] ?? 0), 'auth.logout', 'User logged out.', $request->ip());
        }

        Auth::logoutUser();
        Session::flash('success', 'You have been logged out.');
        Response::redirect('/login');
    }

    public function showAdminLogin(Request $request): string
    {
        return $this->render('admin.auth.login', ['pageTitle' => 'Admin Login']);
    }

    public function adminLogin(Request $request): never
    {
        $data = [
            'email' => trim((string) $request->post('email')),
            'password' => (string) $request->post('password'),
        ];

        $errors = Validator::validate($data, [
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/admin/login');
        }

        if ($this->security->isLocked('admin', strtolower($data['email']), $request->ip())) {
            Session::flash('error', 'Too many login attempts. Please try again later.');
            Session::flash('old', ['email' => $data['email']]);
            Response::redirect('/admin/login');
        }

        $admin = $this->adminModel->one('SELECT * FROM admins WHERE email = ? LIMIT 1', [$data['email']]);

        if (!$admin || !password_verify($data['password'], (string) $admin['password']) || (int) ($admin['active'] ?? 0) !== 1) {
            $this->security->recordFailure('admin', strtolower($data['email']), $request->ip());
            Session::flash('error', 'Invalid admin credentials or inactive account.');
            Session::flash('old', ['email' => $data['email']]);
            Response::redirect('/admin/login');
        }

        $this->security->clearFailures('admin', strtolower($data['email']), $request->ip());
        session_regenerate_id(true);
        Auth::loginAdmin($admin);
        $this->activityLog->log('admin', (int) $admin['id'], 'auth.login', 'Admin logged in.', $request->ip());
        Session::flash('success', 'Welcome back, ' . $admin['full_name'] . '!');
        Response::redirect('/admin/dashboard');
    }

    public function adminLogout(Request $request): never
    {
        if (Auth::checkAdmin()) {
            $admin = Auth::admin();
            $this->activityLog->log('admin', (int) ($admin['id'] ?? 0), 'auth.logout', 'Admin logged out.', $request->ip());
        }

        Auth::logoutAdmin();
        Session::flash('success', 'Admin session ended.');
        Response::redirect('/admin/login');
    }

    public function showRiderLogin(Request $request): string
    {
        return $this->render('rider.auth.login', ['pageTitle' => 'Rider Login']);
    }

    public function riderLogin(Request $request): never
    {
        $data = [
            'email' => trim((string) $request->post('email')),
            'password' => (string) $request->post('password'),
        ];

        $errors = Validator::validate($data, [
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/rider/login');
        }

        if ($this->security->isLocked('rider', strtolower($data['email']), $request->ip())) {
            Session::flash('error', 'Too many login attempts. Please try again later.');
            Session::flash('old', ['email' => $data['email']]);
            Response::redirect('/rider/login');
        }

        $rider = $this->riderModel->one('SELECT * FROM riders WHERE email = ? LIMIT 1', [$data['email']]);

        if (!$rider || empty($rider['password']) || !password_verify($data['password'], (string) $rider['password']) || (int) ($rider['active'] ?? 0) !== 1) {
            $this->security->recordFailure('rider', strtolower($data['email']), $request->ip());
            Session::flash('error', 'Invalid rider credentials or inactive account.');
            Session::flash('old', ['email' => $data['email']]);
            Response::redirect('/rider/login');
        }

        $this->security->clearFailures('rider', strtolower($data['email']), $request->ip());
        session_regenerate_id(true);
        Auth::loginRider($rider);
        $this->riderModel->updateById((int) $rider['id'], [
            'last_seen_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $this->activityLog->log('rider', (int) $rider['id'], 'auth.login', 'Rider logged in.', $request->ip());
        Session::flash('success', 'Welcome, ' . $rider['full_name'] . '.');
        Response::redirect('/rider/dashboard');
    }

    public function riderLogout(Request $request): never
    {
        if (Auth::checkRider()) {
            $rider = Auth::rider();
            $this->activityLog->log('rider', (int) ($rider['id'] ?? 0), 'auth.logout', 'Rider logged out.', $request->ip());
        }

        Auth::logoutRider();
        Session::flash('success', 'Rider session ended.');
        Response::redirect('/rider/login');
    }
}

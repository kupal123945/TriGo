<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Services\ActivityLogService;
use App\Services\QueueService;
use Throwable;

class AdminQueueController extends Controller
{
    protected QueueService $queueService;
    protected ActivityLogService $activityLog;

    public function __construct()
    {
        $this->queueService = new QueueService();
        $this->activityLog = new ActivityLogService();
    }

    public function index(Request $request): string
    {
        $pdo = Database::getConnection();
        $queue = $pdo->query(
            'SELECT r.id AS rider_id, r.full_name, r.tricycle_number, r.status, r.active, r.queue_position '
            . 'FROM riders r ORDER BY r.queue_position ASC, r.id ASC'
        )->fetchAll() ?: [];

        return $this->render('admin.queue.index', [
            'pageTitle' => 'Rider Queue',
            'queue' => $queue,
        ], 'admin');
    }

    public function update(Request $request): never
    {
        $positions = $request->post('positions', []);
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $this->queueService->updateFromPositions($pdo, is_array($positions) ? $positions : []);
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            Session::flash('error', 'Could not update queue: ' . $exception->getMessage());
            Response::redirect('/admin/queue');
        }

        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.queue.update', 'Admin updated rider queue order.', $request->ip());
        Session::flash('success', 'Queue order updated successfully.');
        Response::redirect('/admin/queue');
    }

    public function reset(Request $request): never
    {
        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $this->queueService->normalizeQueue($pdo);
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            Session::flash('error', 'Could not reset queue: ' . $exception->getMessage());
            Response::redirect('/admin/queue');
        }

        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.queue.reset', 'Admin reset rider queue positions.', $request->ip());
        Session::flash('success', 'Queue reset successfully.');
        Response::redirect('/admin/queue');
    }
}

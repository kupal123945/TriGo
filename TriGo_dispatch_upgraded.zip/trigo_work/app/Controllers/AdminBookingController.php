<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Services\BookingService;
use App\Services\DispatchService;
use Throwable;

class AdminBookingController extends Controller
{
    protected BookingService $bookingService;
    protected DispatchService $dispatchService;

    public function __construct()
    {
        $this->bookingService = new BookingService();
        $this->dispatchService = new DispatchService();
    }

    public function index(Request $request): string
    {
        $q = trim((string) $request->query('q', ''));
        $status = trim((string) $request->query('status', ''));
        $dateFrom = trim((string) $request->query('date_from', ''));
        $dateTo = trim((string) $request->query('date_to', ''));

        $sql = 'SELECT b.*, u.full_name AS user_name, r.full_name AS rider_name, r.tricycle_number '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'LEFT JOIN riders r ON r.id = b.rider_id WHERE 1 = 1';
        $params = [];

        if ($q !== '') {
            $sql .= ' AND (b.booking_reference LIKE ? OR u.full_name LIKE ? OR r.full_name LIKE ? OR b.pickup_location LIKE ? OR b.dropoff_location LIKE ?)';
            $like = '%' . $q . '%';
            $params = array_merge($params, [$like, $like, $like, $like, $like]);
        }

        if ($status !== '') {
            $sql .= ' AND b.status = ?';
            $params[] = $status;
        }

        if ($dateFrom !== '') {
            $sql .= ' AND DATE(b.created_at) >= ?';
            $params[] = $dateFrom;
        }

        if ($dateTo !== '') {
            $sql .= ' AND DATE(b.created_at) <= ?';
            $params[] = $dateTo;
        }

        $sql .= ' ORDER BY b.created_at DESC';

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $bookings = $stmt->fetchAll() ?: [];

        return $this->render('admin.bookings.index', [
            'pageTitle' => 'Booking Management',
            'bookings' => $bookings,
            'filters' => [
                'q' => $q,
                'status' => $status,
                'date_from' => $dateFrom,
                'date_to' => $dateTo,
            ],
        ], 'admin');
    }

    public function show(Request $request): string
    {
        $booking = $this->bookingService->getBookingDetailsById((int) $request->route('id'));
        if (!$booking) {
            http_response_code(404);
            return $this->render('errors.404', [
                'pageTitle' => 'Booking Not Found',
                'message' => 'The selected booking record does not exist.',
            ], 'admin');
        }

        $pdo = Database::getConnection();
        $historyStmt = $pdo->prepare('SELECT * FROM trip_history WHERE booking_id = ? ORDER BY created_at DESC');
        $historyStmt->execute([(int) $booking['id']]);
        $history = $historyStmt->fetchAll() ?: [];

        $availableStmt = $pdo->query(
            "SELECT * FROM riders WHERE active = 1 AND status = 'Available' ORDER BY queue_position ASC, id ASC"
        );
        $availableRiders = $availableStmt->fetchAll() ?: [];

        return $this->render('admin.bookings.show', [
            'pageTitle' => 'Booking Details',
            'booking' => $booking,
            'history' => $history,
            'availableRiders' => $availableRiders,
        ], 'admin');
    }

    public function updateStatus(Request $request): never
    {
        $bookingId = (int) $request->route('id');
        $status = trim((string) $request->post('status'));

        try {
            $this->bookingService->updateStatusByAdmin($bookingId, $status, (int) (current_admin()['id'] ?? 0), $request->ip());
            Session::flash('success', 'Booking status updated successfully.');
        } catch (Throwable $exception) {
            Session::flash('error', $exception->getMessage());
        }

        Response::redirect('/admin/bookings/' . $bookingId);
    }

    public function reassign(Request $request): never
    {
        $bookingId = (int) $request->route('id');
        $riderId = (int) $request->post('rider_id');

        if ($riderId <= 0) {
            Session::flash('error', 'Please select an available rider.');
            Response::redirect('/admin/bookings/' . $bookingId);
        }

        try {
            $this->dispatchService->reassignBooking($bookingId, $riderId, (int) (current_admin()['id'] ?? 0), $request->ip());
            Session::flash('success', 'Booking reassigned successfully.');
        } catch (Throwable $exception) {
            Session::flash('error', $exception->getMessage());
        }

        Response::redirect('/admin/bookings/' . $bookingId);
    }
}

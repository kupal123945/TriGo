<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Services\ActivityLogService;
use App\Services\SettingService;

class AdminSettingController extends Controller
{
    protected SettingService $settingService;
    protected ActivityLogService $activityLog;

    public function __construct()
    {
        $this->settingService = new SettingService();
        $this->activityLog = new ActivityLogService();
    }

    public function index(Request $request): string
    {
        return $this->render('admin.settings.index', [
            'pageTitle' => 'System Settings',
            'settings' => $this->settingService->all(),
        ], 'admin');
    }

    public function update(Request $request): never
    {
        $current = $this->settingService->all();
        $data = [
            'terminal_name' => trim((string) $request->post('terminal_name')),
            'support_email' => trim((string) $request->post('support_email')),
            'smtp_enabled' => $request->post('smtp_enabled') ? '1' : '0',
            'smtp_host' => trim((string) $request->post('smtp_host')),
            'smtp_port' => trim((string) $request->post('smtp_port')),
            'smtp_encryption' => trim((string) $request->post('smtp_encryption')),
            'smtp_username' => trim((string) $request->post('smtp_username')),
            'smtp_password' => trim((string) $request->post('smtp_password')),
            'smtp_from_email' => trim((string) $request->post('smtp_from_email')),
            'smtp_from_name' => trim((string) $request->post('smtp_from_name')),
            'sms_enabled' => $request->post('sms_enabled') ? '1' : '0',
            'sms_gateway_url' => trim((string) $request->post('sms_gateway_url')),
            'sms_http_method' => trim((string) $request->post('sms_http_method')),
            'sms_token' => trim((string) $request->post('sms_token')),
            'sms_token_param' => trim((string) $request->post('sms_token_param')),
            'sms_recipient_param' => trim((string) $request->post('sms_recipient_param')),
            'sms_message_param' => trim((string) $request->post('sms_message_param')),
            'sms_auth_header' => trim((string) $request->post('sms_auth_header')),
        ];

        $errors = Validator::validate($data, [
            'terminal_name' => 'required|min:3|max:150',
            'support_email' => 'nullable|email|max:150',
            'smtp_enabled' => 'required|in:0,1',
            'smtp_host' => 'nullable|max:150',
            'smtp_port' => 'nullable|numeric',
            'smtp_encryption' => 'required|in:tls,ssl,none',
            'smtp_username' => 'nullable|max:150',
            'smtp_password' => 'nullable|max:255',
            'smtp_from_email' => 'nullable|email|max:150',
            'smtp_from_name' => 'nullable|max:150',
            'sms_enabled' => 'required|in:0,1',
            'sms_gateway_url' => 'nullable|max:255',
            'sms_http_method' => 'required|in:POST,GET',
            'sms_token' => 'nullable|max:255',
            'sms_token_param' => 'nullable|max:100',
            'sms_recipient_param' => 'nullable|max:100',
            'sms_message_param' => 'nullable|max:100',
            'sms_auth_header' => 'nullable|max:255',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/admin/settings');
        }

        if ($data['smtp_password'] === '') {
            $data['smtp_password'] = (string) ($current['smtp_password'] ?? '');
        }

        if ($data['sms_token'] === '') {
            $data['sms_token'] = (string) ($current['sms_token'] ?? '');
        }

        $this->settingService->setMany($data);
        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.settings.update', 'Admin updated system settings.', $request->ip());
        Session::flash('success', 'System settings saved successfully.');
        Response::redirect('/admin/settings');
    }
}

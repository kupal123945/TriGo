<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Services\OperationsMaintenanceService;

class AdminReportController extends Controller
{
    public function __construct()
    {
        (new OperationsMaintenanceService())->run();
    }

    public function index(Request $request): string
    {
        $dateFrom = trim((string) $request->query('date_from', date('Y-m-01')));
        $dateTo = trim((string) $request->query('date_to', date('Y-m-d')));
        $fromDateTime = $dateFrom . ' 00:00:00';
        $toDateTime = $dateTo . ' 23:59:59';
        $where = ' WHERE b.created_at >= ? AND b.created_at <= ?';
        $params = [$fromDateTime, $toDateTime];

        $pdo = Database::getConnection();
        $summaryStmt = $pdo->prepare(
            'SELECT COUNT(*) AS total_bookings, '
            . "SUM(CASE WHEN b.status = 'Assigned' THEN 1 ELSE 0 END) AS assigned_count, "
            . "SUM(CASE WHEN b.status = 'Accepted' THEN 1 ELSE 0 END) AS accepted_count, "
            . "SUM(CASE WHEN b.status = 'Ongoing' THEN 1 ELSE 0 END) AS ongoing_count, "
            . "SUM(CASE WHEN b.status = 'Completed' THEN 1 ELSE 0 END) AS completed_count, "
            . "SUM(CASE WHEN b.status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_count, "
            . "SUM(CASE WHEN b.status = 'Failed / No Rider Available' THEN 1 ELSE 0 END) AS failed_count "
            . 'FROM bookings b' . $where
        );
        $summaryStmt->execute($params);
        $summary = $summaryStmt->fetch() ?: [];

        $riderStmt = $pdo->prepare(
            'SELECT r.full_name, r.tricycle_number, '
            . 'COUNT(b.id) AS total_assigned, '
            . "SUM(CASE WHEN b.status = 'Completed' THEN 1 ELSE 0 END) AS completed_count, "
            . "SUM(CASE WHEN b.status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_count "
            . 'FROM riders r '
            . 'LEFT JOIN bookings b ON b.rider_id = r.id AND b.created_at >= ? AND b.created_at <= ? '
            . 'GROUP BY r.id, r.full_name, r.tricycle_number '
            . 'ORDER BY total_assigned DESC, r.queue_position ASC'
        );
        $riderStmt->execute($params);
        $riderPerformance = $riderStmt->fetchAll() ?: [];

        $bookingStmt = $pdo->prepare(
            'SELECT b.booking_reference, b.pickup_location, b.dropoff_location, b.status, b.fare_estimate, b.created_at, '
            . 'u.full_name AS user_name, r.full_name AS rider_name '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'LEFT JOIN riders r ON r.id = b.rider_id '
            . $where
            . ' ORDER BY b.created_at DESC LIMIT 20'
        );
        $bookingStmt->execute($params);
        $bookings = $bookingStmt->fetchAll() ?: [];

        return $this->render('admin.reports.index', [
            'pageTitle' => 'Reports',
            'summary' => $summary,
            'riderPerformance' => $riderPerformance,
            'bookings' => $bookings,
            'filters' => ['date_from' => $dateFrom, 'date_to' => $dateTo],
        ], 'admin');
    }

    public function exportCsv(Request $request): never
    {
        $dateFrom = trim((string) $request->query('date_from', date('Y-m-01')));
        $dateTo = trim((string) $request->query('date_to', date('Y-m-d')));
        $fromDateTime = $dateFrom . ' 00:00:00';
        $toDateTime = $dateTo . ' 23:59:59';

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare(
            'SELECT b.booking_reference, u.full_name AS user_name, r.full_name AS rider_name, r.tricycle_number, '
            . 'b.pickup_location, b.dropoff_location, b.contact_number, b.fare_estimate, b.status, b.created_at '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'LEFT JOIN riders r ON r.id = b.rider_id '
            . 'WHERE b.created_at >= ? AND b.created_at <= ? '
            . 'ORDER BY b.created_at DESC'
        );
        $stmt->execute([$fromDateTime, $toDateTime]);
        $rows = $stmt->fetchAll() ?: [];

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=tricycle-report-' . $dateFrom . '-to-' . $dateTo . '.csv');
        $output = fopen('php://output', 'wb');
        fputcsv($output, ['Booking Reference', 'User', 'Rider', 'Tricycle Number', 'Pickup', 'Drop-off', 'Contact Number', 'Fare Estimate', 'Status', 'Created At']);
        foreach ($rows as $row) {
            fputcsv($output, [$row['booking_reference'], $row['user_name'], $row['rider_name'], $row['tricycle_number'], $row['pickup_location'], $row['dropoff_location'], $row['contact_number'], $row['fare_estimate'], $row['status'], $row['created_at']]);
        }
        fclose($output);
        exit;
    }
}

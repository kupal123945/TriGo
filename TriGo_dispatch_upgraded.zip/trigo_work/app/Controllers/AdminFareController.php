<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Services\ActivityLogService;
use App\Services\FareService;

class AdminFareController extends Controller
{
    protected FareService $fareService;
    protected ActivityLogService $activityLog;

    public function __construct()
    {
        $this->fareService = new FareService();
        $this->activityLog = new ActivityLogService();
    }

    public function index(Request $request): string
    {
        return $this->render('admin.fares.index', [
            'pageTitle' => 'Fare Settings',
            'settings' => $this->fareService->getSettings(),
        ], 'admin');
    }

    public function update(Request $request): never
    {
        $data = [
            'base_fare' => trim((string) $request->post('base_fare')),
            'booking_fee' => trim((string) $request->post('booking_fee')),
            'night_surcharge' => trim((string) $request->post('night_surcharge')),
            'notes' => trim((string) $request->post('notes')),
            'cancellation_window_minutes' => trim((string) $request->post('cancellation_window_minutes')),
        ];

        $errors = Validator::validate($data, [
            'base_fare' => 'required|numeric',
            'booking_fee' => 'required|numeric',
            'night_surcharge' => 'required|numeric',
            'notes' => 'nullable|max:1000',
            'cancellation_window_minutes' => 'required|numeric',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/admin/fares');
        }

        $this->fareService->update($data);
        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.fares.update', 'Admin updated fare settings.', $request->ip());
        Session::flash('success', 'Fare settings updated successfully.');
        Response::redirect('/admin/fares');
    }
}

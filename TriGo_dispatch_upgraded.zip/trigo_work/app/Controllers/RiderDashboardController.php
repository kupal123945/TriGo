<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Models\Rider;
use App\Services\BookingService;
use App\Services\OperationsMaintenanceService;
use Throwable;

class RiderDashboardController extends Controller
{
    protected BookingService $bookingService;
    protected Rider $riderModel;

    public function __construct()
    {
        $this->bookingService = new BookingService();
        $this->riderModel = new Rider();
        (new OperationsMaintenanceService())->run();
    }

    public function index(Request $request): string
    {
        $rider = current_rider();
        if ($rider) {
            $this->riderModel->updateById((int) $rider['id'], ['last_seen_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]);
            $rider = $this->riderModel->find((int) $rider['id']) ?: $rider;
        }
        $bookings = $this->bookingService->getActiveBookingsForRider((int) ($rider['id'] ?? 0));

        return $this->render('rider.dashboard', [
            'pageTitle' => 'Rider Dashboard',
            'rider' => $rider,
            'bookings' => $bookings,
        ]);
    }

    public function show(Request $request): string
    {
        $riderId = (int) (current_rider()['id'] ?? 0);
        $booking = $this->bookingService->getBookingDetailsForRider((int) $request->route('id'), $riderId);
        if (!$booking) {
            http_response_code(404);
            return $this->render('errors.404', [
                'pageTitle' => 'Booking Not Found',
                'message' => 'The selected booking does not belong to this rider or no longer exists.',
            ]);
        }

        return $this->render('rider.bookings.show', [
            'pageTitle' => 'Assigned Booking',
            'booking' => $booking,
        ]);
    }

    public function updateStatus(Request $request): never
    {
        $bookingId = (int) $request->route('id');
        $status = trim((string) $request->post('status'));
        $declineReason = trim((string) $request->post('decline_reason'));
        $riderId = (int) (current_rider()['id'] ?? 0);

        try {
            $this->bookingService->updateStatusByRider($bookingId, $riderId, $status, $request->ip(), $declineReason);
            Session::flash('success', 'Trip status updated successfully.');
        } catch (Throwable $exception) {
            Session::flash('error', $exception->getMessage());
        }

        Response::redirect('/rider/bookings/' . $bookingId);
    }
}

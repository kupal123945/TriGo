<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Rider;
use App\Services\ActivityLogService;
use App\Services\BookingService;
use App\Services\QueueService;
use Throwable;

class AdminRiderController extends Controller
{
    protected Rider $riderModel;
    protected QueueService $queueService;
    protected ActivityLogService $activityLog;
    protected BookingService $bookingService;

    public function __construct()
    {
        $this->riderModel = new Rider();
        $this->queueService = new QueueService();
        $this->activityLog = new ActivityLogService();
        $this->bookingService = new BookingService();
    }

    public function index(Request $request): string
    {
        $query = trim((string) $request->query('q', ''));
        $sql = 'SELECT * FROM riders';
        $params = [];

        if ($query !== '') {
            $sql .= ' WHERE full_name LIKE ? OR phone LIKE ? OR email LIKE ? OR tricycle_number LIKE ?';
            $like = '%' . $query . '%';
            $params = [$like, $like, $like, $like];
        }

        $sql .= ' ORDER BY queue_position ASC, id ASC';

        return $this->render('admin.riders.index', [
            'pageTitle' => 'Manage Riders',
            'riders' => $this->riderModel->all($sql, $params),
            'query' => $query,
        ], 'admin');
    }

    public function create(Request $request): string
    {
        return $this->render('admin.riders.form', [
            'pageTitle' => 'Add Rider',
            'rider' => null,
        ], 'admin');
    }

    public function store(Request $request): never
    {
        $data = [
            'full_name' => trim((string) $request->post('full_name')),
            'phone' => trim((string) $request->post('phone')),
            'email' => trim((string) $request->post('email')),
            'tricycle_number' => trim((string) $request->post('tricycle_number')),
            'status' => trim((string) $request->post('status')),
            'active' => $request->post('active') ? '1' : '0',
            'password' => (string) $request->post('password'),
            'password_confirmation' => (string) $request->post('password_confirmation'),
        ];

        $errors = Validator::validate($data, [
            'full_name' => 'required|min:3|max:150',
            'phone' => 'required|phone|max:30',
            'email' => 'required|email|unique:riders,email',
            'tricycle_number' => 'required|min:2|max:50|unique:riders,tricycle_number',
            'status' => 'required|in:Available,Busy,Paused,Offline',
            'active' => 'required|in:0,1',
            'password' => 'required|min:8|confirmed',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/admin/riders/create');
        }

        $pdo = Database::getConnection();
        $pdo->beginTransaction();

        try {
            $riderId = $this->riderModel->insert([
                'full_name' => $data['full_name'],
                'phone' => normalize_phone($data['phone']),
                'email' => $data['email'],
                'password' => password_hash($data['password'], PASSWORD_DEFAULT),
                'tricycle_number' => $data['tricycle_number'],
                'status' => $data['status'],
                'queue_position' => 0,
                'last_assigned_at' => null,
                'active' => (int) $data['active'],
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);

            $this->queueService->createQueueEntry($pdo, $riderId);
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            Session::flash('error', 'Could not create rider: ' . $exception->getMessage());
            Session::flash('old', $data);
            Response::redirect('/admin/riders/create');
        }

        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.riders.create', 'Admin created rider ' . $data['full_name'] . '.', $request->ip());
        Session::flash('success', 'Rider created successfully. Rider can now log in with the assigned email and password.');
        Response::redirect('/admin/riders');
    }

    public function edit(Request $request): string
    {
        $rider = $this->riderModel->find((int) $request->route('id'));
        if (!$rider) {
            http_response_code(404);
            return $this->render('errors.404', [
                'pageTitle' => 'Rider Not Found',
                'message' => 'The selected rider record does not exist.',
            ], 'admin');
        }

        return $this->render('admin.riders.form', [
            'pageTitle' => 'Edit Rider',
            'rider' => $rider,
        ], 'admin');
    }

    public function update(Request $request): never
    {
        $riderId = (int) $request->route('id');
        $rider = $this->riderModel->find($riderId);
        if (!$rider) {
            Session::flash('error', 'Rider not found.');
            Response::redirect('/admin/riders');
        }

        $data = [
            'full_name' => trim((string) $request->post('full_name')),
            'phone' => trim((string) $request->post('phone')),
            'email' => trim((string) $request->post('email')),
            'tricycle_number' => trim((string) $request->post('tricycle_number')),
            'status' => trim((string) $request->post('status')),
            'active' => $request->post('active') ? '1' : '0',
            'password' => (string) $request->post('password'),
            'password_confirmation' => (string) $request->post('password_confirmation'),
        ];

        $rules = [
            'full_name' => 'required|min:3|max:150',
            'phone' => 'required|phone|max:30',
            'email' => 'required|email|unique:riders,email,' . $riderId,
            'tricycle_number' => 'required|min:2|max:50|unique:riders,tricycle_number,' . $riderId,
            'status' => 'required|in:Available,Busy,Paused,Offline',
            'active' => 'required|in:0,1',
        ];

        if ($data['password'] !== '') {
            $rules['password'] = 'required|min:8|confirmed';
        }

        $errors = Validator::validate($data, $rules);

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT COUNT(*) AS total FROM bookings WHERE rider_id = ? AND status IN (?, ?, ?)');
        $activeStatuses = $this->bookingService->activeStatuses();
        $stmt->execute([$riderId, ...$activeStatuses]);
        $activeTrips = (int) ($stmt->fetch()['total'] ?? 0);

        if ($activeTrips > 0 && $data['status'] === 'Available') {
            $errors['status'] = 'This rider still has an active booking and cannot be marked Available yet.';
        }

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/admin/riders/' . $riderId . '/edit');
        }

        $update = [
            'full_name' => $data['full_name'],
            'phone' => normalize_phone($data['phone']),
            'email' => $data['email'],
            'tricycle_number' => $data['tricycle_number'],
            'status' => $data['status'],
            'active' => (int) $data['active'],
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        if ($data['password'] !== '') {
            $update['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }

        $this->riderModel->updateById($riderId, $update);

        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.riders.update', 'Admin updated rider ' . $data['full_name'] . '.', $request->ip());
        Session::flash('success', 'Rider updated successfully.');
        Response::redirect('/admin/riders/' . $riderId . '/edit');
    }

    public function delete(Request $request): never
    {
        $riderId = (int) $request->route('id');
        $rider = $this->riderModel->find($riderId);
        if (!$rider) {
            Session::flash('error', 'Rider not found.');
            Response::redirect('/admin/riders');
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT COUNT(*) AS total FROM bookings WHERE rider_id = ?');
        $stmt->execute([$riderId]);
        $count = (int) ($stmt->fetch()['total'] ?? 0);

        if ($count > 0) {
            Session::flash('error', 'Cannot delete a rider with booking history. Deactivate the rider instead.');
            Response::redirect('/admin/riders');
        }

        $pdo->beginTransaction();
        try {
            $this->queueService->deleteQueueEntry($pdo, $riderId);
            $this->riderModel->deleteById($riderId);
            $this->queueService->normalizeQueue($pdo);
            $pdo->commit();
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            Session::flash('error', 'Could not delete rider: ' . $exception->getMessage());
            Response::redirect('/admin/riders');
        }

        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.riders.delete', 'Admin deleted rider ' . $rider['full_name'] . '.', $request->ip());
        Session::flash('success', 'Rider deleted successfully.');
        Response::redirect('/admin/riders');
    }
}

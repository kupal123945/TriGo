<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Services\OperationsMaintenanceService;

class AdminDashboardController extends Controller
{
    public function __construct()
    {
        (new OperationsMaintenanceService())->run();
    }

    public function index(Request $request): string
    {
        $pdo = Database::getConnection();

        $stats = [
            'total_bookings' => (int) ($pdo->query('SELECT COUNT(*) AS total FROM bookings')->fetch()['total'] ?? 0),
            'total_users' => (int) ($pdo->query('SELECT COUNT(*) AS total FROM users')->fetch()['total'] ?? 0),
            'available_riders' => (int) ($pdo->query("SELECT COUNT(*) AS total FROM riders WHERE active = 1 AND status = 'Available'")->fetch()['total'] ?? 0),
            'busy_riders' => (int) ($pdo->query("SELECT COUNT(*) AS total FROM riders WHERE active = 1 AND status = 'Busy'")->fetch()['total'] ?? 0),
            'completed_rides' => (int) ($pdo->query("SELECT COUNT(*) AS total FROM bookings WHERE status = 'Completed'")->fetch()['total'] ?? 0),
            'cancelled_rides' => (int) ($pdo->query("SELECT COUNT(*) AS total FROM bookings WHERE status = 'Cancelled'")->fetch()['total'] ?? 0),
            'notification_success' => (int) ($pdo->query("SELECT COUNT(*) AS total FROM notifications WHERE status = 'sent'")->fetch()['total'] ?? 0),
            'notification_failed' => (int) ($pdo->query("SELECT COUNT(*) AS total FROM notifications WHERE status = 'failed'")->fetch()['total'] ?? 0),
        ];

        $stats['active_dispatches'] = (int) ($pdo->query("SELECT COUNT(*) AS total FROM bookings WHERE status IN ('Assigned', 'Accepted', 'Ongoing')")->fetch()['total'] ?? 0);
        $stats['pending_dispatches'] = (int) ($pdo->query("SELECT COUNT(*) AS total FROM bookings WHERE status = 'Pending'")->fetch()['total'] ?? 0);
        $totalRides = max(1, $stats['total_bookings']);
        $totalRidersInRotation = max(1, $stats['available_riders'] + $stats['busy_riders']);

        $insights = [
            'completion_rate' => round(($stats['completed_rides'] / $totalRides) * 100, 1),
            'cancellation_rate' => round(($stats['cancelled_rides'] / $totalRides) * 100, 1),
            'rider_utilization' => round(($stats['busy_riders'] / $totalRidersInRotation) * 100, 1),
            'notification_reliability' => round(($stats['notification_success'] / max(1, $stats['notification_success'] + $stats['notification_failed'])) * 100, 1),
        ];

        $recentBookings = $pdo->query(
            'SELECT b.*, u.full_name AS user_name, r.full_name AS rider_name '
            . 'FROM bookings b '
            . 'JOIN users u ON u.id = b.user_id '
            . 'LEFT JOIN riders r ON r.id = b.rider_id '
            . 'ORDER BY b.created_at DESC LIMIT 10'
        )->fetchAll() ?: [];

        $latestLogs = $pdo->query('SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 10')->fetchAll() ?: [];

        return $this->render('admin.dashboard', [
            'pageTitle' => 'Admin Dashboard',
            'stats' => $stats,
            'insights' => $insights,
            'recentBookings' => $recentBookings,
            'latestLogs' => $latestLogs,
        ], 'admin');
    }
}

<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Models\User;
use App\Services\ActivityLogService;

class AdminUserController extends Controller
{
    protected User $userModel;
    protected ActivityLogService $activityLog;

    public function __construct()
    {
        $this->userModel = new User();
        $this->activityLog = new ActivityLogService();
    }

    public function index(Request $request): string
    {
        $query = trim((string) $request->query('q', ''));
        $sql = 'SELECT * FROM users';
        $params = [];

        if ($query !== '') {
            $sql .= ' WHERE full_name LIKE ? OR email LIKE ? OR phone LIKE ?';
            $like = '%' . $query . '%';
            $params = [$like, $like, $like];
        }

        $sql .= ' ORDER BY created_at DESC';

        return $this->render('admin.users.index', [
            'pageTitle' => 'Manage Users',
            'users' => $this->userModel->all($sql, $params),
            'query' => $query,
        ], 'admin');
    }

    public function edit(Request $request): string
    {
        $user = $this->userModel->find((int) $request->route('id'));
        if (!$user) {
            http_response_code(404);
            return $this->render('errors.404', [
                'pageTitle' => 'User Not Found',
                'message' => 'The selected user record does not exist.',
            ], 'admin');
        }

        return $this->render('admin.users.form', [
            'pageTitle' => 'Edit User',
            'user' => $user,
        ], 'admin');
    }

    public function update(Request $request): never
    {
        $userId = (int) $request->route('id');
        $user = $this->userModel->find($userId);
        if (!$user) {
            Session::flash('error', 'User not found.');
            Response::redirect('/admin/users');
        }

        $data = [
            'full_name' => trim((string) $request->post('full_name')),
            'email' => trim((string) $request->post('email')),
            'phone' => trim((string) $request->post('phone')),
            'address' => trim((string) $request->post('address')),
            'password' => (string) $request->post('password'),
            'password_confirmation' => (string) $request->post('password_confirmation'),
            'active' => $request->post('active') ? '1' : '0',
        ];

        $errors = Validator::validate($data, [
            'full_name' => 'required|min:3|max:150',
            'email' => 'required|email|unique:users,email,' . $userId,
            'phone' => 'required|min:7|max:30',
            'address' => 'nullable|max:255',
            'password' => 'nullable|min:8|confirmed',
            'active' => 'required|in:0,1',
        ]);

        if ($errors) {
            $this->flashValidationErrors($data, $errors);
            Response::redirect('/admin/users/' . $userId . '/edit');
        }

        $payload = [
            'full_name' => $data['full_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'address' => $data['address'],
            'active' => (int) $data['active'],
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        if ($data['password'] !== '') {
            $payload['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        }

        $this->userModel->updateById($userId, $payload);
        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.users.update', 'Admin updated user ' . $data['full_name'] . '.', $request->ip());
        Session::flash('success', 'User updated successfully.');
        Response::redirect('/admin/users/' . $userId . '/edit');
    }

    public function toggleActive(Request $request): never
    {
        $userId = (int) $request->route('id');
        $user = $this->userModel->find($userId);
        if (!$user) {
            Session::flash('error', 'User not found.');
            Response::redirect('/admin/users');
        }

        $newStatus = (int) ($user['active'] ?? 0) === 1 ? 0 : 1;
        $this->userModel->updateById($userId, [
            'active' => $newStatus,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.users.toggle_active', 'Admin set user ' . $user['full_name'] . ' active=' . $newStatus . '.', $request->ip());
        Session::flash('success', 'User status updated.');
        Response::redirect('/admin/users');
    }

    public function delete(Request $request): never
    {
        $userId = (int) $request->route('id');
        $user = $this->userModel->find($userId);
        if (!$user) {
            Session::flash('error', 'User not found.');
            Response::redirect('/admin/users');
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT COUNT(*) AS total FROM bookings WHERE user_id = ?');
        $stmt->execute([$userId]);
        $count = (int) ($stmt->fetch()['total'] ?? 0);

        if ($count > 0) {
            Session::flash('error', 'Cannot delete a user with booking history. Deactivate the account instead.');
            Response::redirect('/admin/users');
        }

        $this->userModel->deleteById($userId);
        $this->activityLog->log('admin', (int) (current_admin()['id'] ?? 0), 'admin.users.delete', 'Admin deleted user ' . $user['full_name'] . '.', $request->ip());
        Session::flash('success', 'User deleted successfully.');
        Response::redirect('/admin/users');
    }
}

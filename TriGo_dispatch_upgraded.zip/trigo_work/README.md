# TriGo Dispatch System

A ready-to-upload PHP/MySQL tricycle booking and dispatch system for local terminals and community transport setups, refreshed with modern TriGo branding, theme toggle support, smarter booking summaries, and stronger dashboard UX.

## What this project does
- Authenticated portals included: **Admin**, **User**, and **Rider**
- Users can register, log in, book a tricycle, view booking history, and cancel within allowed rules
- Users **cannot** choose a rider manually
- The system automatically assigns the next available rider fairly using round-robin queue logic
- Busy and Offline riders are skipped automatically
- Assigned rider details are shown immediately after booking
- Assigned riders can log in to their own rider dashboard and mark trips **Ongoing** or **Completed**
- Riders are notified immediately through **free SMTP email** first
- Optional local SMS gateway support is included without any paid SMS API
- Notification logs, activity logs, reports, fares, queue management, and booking management are included

## Tech stack
- Backend: plain PHP 8 MVC, Laravel-inspired structure
- Database: MySQL / MariaDB
- Frontend: Bootstrap 5
- Notifications: PHPMailer + SMTP, optional HTTP-based local SMS gateway
- Maps: manual text fields only

## Why this is not full Composer-based Laravel
Your request prioritized a practical, ready-to-upload system for InfinityFree/shared hosting. Full Laravel usually needs Composer workflow and a more server-assisted deployment process. This package keeps a Laravel-style architecture but removes the heavy framework dependency so it can be uploaded directly and run on basic PHP hosting.

## Main folders
- `app/` core application code
- `resources/views/` responsive UI templates
- `database/` schema, migrations, seeders, and helper scripts
- `docs/` architecture and deployment guides
- `tests/` lightweight logic tests

## Quick start
1. Edit `config/database.php`
2. Import `database/schema.sql`
3. Import `database/seeders/sample_data.sql`
4. Open the site in a browser
5. Log in as admin and configure SMTP in **System Settings**
6. Verify each rider has an email and password for the rider portal
7. Change all default passwords

## Default sample credentials
- Admin: `admin@terminal.local` / `Admin123!`
- User: `juan@example.com` / `User123!`
- User: `maria@example.com` / `User123!`
- Rider: `rider1@example.com` / `User123!`
- Rider: `rider2@example.com` / `User123!`

## Key documents
- `docs/PROJECT_ARCHITECTURE.md`
- `docs/INSTALLATION.md`
- `docs/LOCAL_DEPLOYMENT.md`
- `docs/INFINITYFREE_SHARED_HOSTING.md`
- `docs/TEST_CASES.md`

## Testing
Run the lightweight queue logic tests:
```bash
php tests/run.php
```

## Production checklist
- Change sample passwords
- Add real rider emails and contact numbers
- Configure SMTP
- Configure fare settings
- Review system settings
- Remove sample users if not needed

<?php

use App\Controllers\AdminActivityLogController;
use App\Controllers\AdminBookingController;
use App\Controllers\AdminDashboardController;
use App\Controllers\AdminFareController;
use App\Controllers\AdminNotificationController;
use App\Controllers\AdminQueueController;
use App\Controllers\AdminReportController;
use App\Controllers\AdminRiderController;
use App\Controllers\AdminSettingController;
use App\Controllers\AdminUserController;
use App\Controllers\AuthController;
use App\Controllers\HomeController;
use App\Controllers\ProfileController;
use App\Controllers\RiderDashboardController;
use App\Controllers\UserBookingController;
use App\Controllers\UserDashboardController;
use App\Middleware\AdminAuthMiddleware;
use App\Middleware\GuestAdminMiddleware;
use App\Middleware\GuestRiderMiddleware;
use App\Middleware\GuestUserMiddleware;
use App\Middleware\RiderAuthMiddleware;
use App\Middleware\UserAuthMiddleware;

$router->get('/', [HomeController::class, 'index']);

$router->get('/login', [AuthController::class, 'showLogin'], [GuestUserMiddleware::class]);
$router->post('/login', [AuthController::class, 'login'], [GuestUserMiddleware::class]);
$router->get('/register', [AuthController::class, 'showRegister'], [GuestUserMiddleware::class]);
$router->post('/register', [AuthController::class, 'register'], [GuestUserMiddleware::class]);
$router->post('/logout', [AuthController::class, 'logout'], [UserAuthMiddleware::class]);

$router->get('/dashboard', [UserDashboardController::class, 'index'], [UserAuthMiddleware::class]);
$router->get('/profile', [ProfileController::class, 'edit'], [UserAuthMiddleware::class]);
$router->post('/profile', [ProfileController::class, 'update'], [UserAuthMiddleware::class]);

$router->get('/bookings/create', [UserBookingController::class, 'create'], [UserAuthMiddleware::class]);
$router->post('/bookings', [UserBookingController::class, 'store'], [UserAuthMiddleware::class]);
$router->get('/bookings/current', [UserBookingController::class, 'current'], [UserAuthMiddleware::class]);
$router->get('/bookings/history', [UserBookingController::class, 'history'], [UserAuthMiddleware::class]);
$router->get('/bookings/{reference}', [UserBookingController::class, 'show'], [UserAuthMiddleware::class]);
$router->post('/bookings/{id}/cancel', [UserBookingController::class, 'cancel'], [UserAuthMiddleware::class]);

$router->get('/admin/login', [AuthController::class, 'showAdminLogin'], [GuestAdminMiddleware::class]);
$router->post('/admin/login', [AuthController::class, 'adminLogin'], [GuestAdminMiddleware::class]);
$router->post('/admin/logout', [AuthController::class, 'adminLogout'], [AdminAuthMiddleware::class]);

$router->get('/admin/dashboard', [AdminDashboardController::class, 'index'], [AdminAuthMiddleware::class]);
$router->get('/admin/users', [AdminUserController::class, 'index'], [AdminAuthMiddleware::class]);
$router->get('/admin/users/{id}/edit', [AdminUserController::class, 'edit'], [AdminAuthMiddleware::class]);
$router->post('/admin/users/{id}', [AdminUserController::class, 'update'], [AdminAuthMiddleware::class]);
$router->post('/admin/users/{id}/toggle-active', [AdminUserController::class, 'toggleActive'], [AdminAuthMiddleware::class]);
$router->post('/admin/users/{id}/delete', [AdminUserController::class, 'delete'], [AdminAuthMiddleware::class]);

$router->get('/admin/riders', [AdminRiderController::class, 'index'], [AdminAuthMiddleware::class]);
$router->get('/admin/riders/create', [AdminRiderController::class, 'create'], [AdminAuthMiddleware::class]);
$router->post('/admin/riders', [AdminRiderController::class, 'store'], [AdminAuthMiddleware::class]);
$router->get('/admin/riders/{id}/edit', [AdminRiderController::class, 'edit'], [AdminAuthMiddleware::class]);
$router->post('/admin/riders/{id}', [AdminRiderController::class, 'update'], [AdminAuthMiddleware::class]);
$router->post('/admin/riders/{id}/delete', [AdminRiderController::class, 'delete'], [AdminAuthMiddleware::class]);

$router->get('/admin/queue', [AdminQueueController::class, 'index'], [AdminAuthMiddleware::class]);
$router->post('/admin/queue', [AdminQueueController::class, 'update'], [AdminAuthMiddleware::class]);
$router->post('/admin/queue/reset', [AdminQueueController::class, 'reset'], [AdminAuthMiddleware::class]);

$router->get('/admin/bookings', [AdminBookingController::class, 'index'], [AdminAuthMiddleware::class]);
$router->get('/admin/bookings/{id}', [AdminBookingController::class, 'show'], [AdminAuthMiddleware::class]);
$router->post('/admin/bookings/{id}/status', [AdminBookingController::class, 'updateStatus'], [AdminAuthMiddleware::class]);
$router->post('/admin/bookings/{id}/reassign', [AdminBookingController::class, 'reassign'], [AdminAuthMiddleware::class]);

$router->get('/admin/notifications', [AdminNotificationController::class, 'index'], [AdminAuthMiddleware::class]);
$router->get('/admin/reports', [AdminReportController::class, 'index'], [AdminAuthMiddleware::class]);
$router->get('/admin/reports/export', [AdminReportController::class, 'exportCsv'], [AdminAuthMiddleware::class]);
$router->get('/admin/fares', [AdminFareController::class, 'index'], [AdminAuthMiddleware::class]);
$router->post('/admin/fares', [AdminFareController::class, 'update'], [AdminAuthMiddleware::class]);
$router->get('/admin/settings', [AdminSettingController::class, 'index'], [AdminAuthMiddleware::class]);
$router->post('/admin/settings', [AdminSettingController::class, 'update'], [AdminAuthMiddleware::class]);
$router->get('/admin/activity-logs', [AdminActivityLogController::class, 'index'], [AdminAuthMiddleware::class]);

$router->get('/rider/login', [AuthController::class, 'showRiderLogin'], [GuestRiderMiddleware::class]);
$router->post('/rider/login', [AuthController::class, 'riderLogin'], [GuestRiderMiddleware::class]);
$router->post('/rider/logout', [AuthController::class, 'riderLogout'], [RiderAuthMiddleware::class]);
$router->get('/rider/dashboard', [RiderDashboardController::class, 'index'], [RiderAuthMiddleware::class]);
$router->get('/rider/bookings/{id}', [RiderDashboardController::class, 'show'], [RiderAuthMiddleware::class]);
$router->post('/rider/bookings/{id}/status', [RiderDashboardController::class, 'updateStatus'], [RiderAuthMiddleware::class]);

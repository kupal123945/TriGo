<?php

declare(strict_types=1);

define('BASE_PATH', __DIR__);

require BASE_PATH . '/bootstrap/app.php';

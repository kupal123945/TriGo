<?php

require __DIR__ . '/bootstrap.php';

use App\Services\QueueService;

$service = new QueueService();

$queue = [
    ['id' => 1, 'status' => 'Available', 'queue_position' => 1],
    ['id' => 2, 'status' => 'Available', 'queue_position' => 2],
    ['id' => 3, 'status' => 'Available', 'queue_position' => 3],
];

$first = $service->findNextAvailable($queue);
assert_same(1, (int) $first['id'], 'First booking should assign rider 1.');

$queue = $service->reorderAfterAssignment($queue, (int) $first['id']);
foreach ($queue as &$rider) {
    if ((int) $rider['id'] === 1) {
        $rider['status'] = 'Busy';
    }
}
unset($rider);

foreach ($queue as &$rider) {
    if ((int) $rider['id'] === 1) {
        $rider['status'] = 'Available';
    }
}
unset($rider);

$second = $service->findNextAvailable($queue);
assert_same(2, (int) $second['id'], 'After rider 1 completes, the next booking should assign rider 2.');

echo "completed_trip_rotation_test.php passed\n";

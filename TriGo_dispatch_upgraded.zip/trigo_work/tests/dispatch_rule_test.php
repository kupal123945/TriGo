<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use App\Services\QueueService;

$service = new QueueService();

$queue = [
    ['id' => 1, 'status' => 'Available', 'queue_position' => 1],
    ['id' => 2, 'status' => 'Busy', 'queue_position' => 2],
    ['id' => 3, 'status' => 'Available', 'queue_position' => 3],
    ['id' => 4, 'status' => 'Offline', 'queue_position' => 4],
    ['id' => 5, 'status' => 'Available', 'queue_position' => 5],
];

$first = $service->findNextAvailable($queue);
assert_same(1, (int) $first['id'], 'First booking should use rider 1.');

$queue = $service->reorderAfterAssignment($queue, 1);
foreach ($queue as &$rider) {
    if ((int) $rider['id'] === 1) {
        $rider['status'] = 'Available';
    }
}
unset($rider);

$second = $service->findNextAvailable($queue);
assert_same(3, (int) $second['id'], 'Second booking should skip Busy rider 2 and assign rider 3.');

$queue = [
    ['id' => 1, 'status' => 'Busy', 'queue_position' => 1],
    ['id' => 2, 'status' => 'Offline', 'queue_position' => 2],
];
assert_true($service->findNextAvailable($queue) === null, 'If all riders are Busy or Offline, assignment should fail.');

echo "dispatch_rule_test.php passed\n";

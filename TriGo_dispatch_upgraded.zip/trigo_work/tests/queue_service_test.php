<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use App\Services\QueueService;

$service = new QueueService();

$riders = [
    ['id' => 1, 'status' => 'Available', 'queue_position' => 1],
    ['id' => 2, 'status' => 'Available', 'queue_position' => 2],
    ['id' => 3, 'status' => 'Available', 'queue_position' => 3],
    ['id' => 4, 'status' => 'Available', 'queue_position' => 4],
    ['id' => 5, 'status' => 'Available', 'queue_position' => 5],
];

$next = $service->findNextAvailable($riders);
assert_same(1, (int) $next['id'], 'First available rider should be rider 1.');

$reordered = $service->reorderAfterAssignment($riders, 1);
assert_same([2, 3, 4, 5, 1], array_map(fn ($r) => (int) $r['id'], $reordered), 'Assigned rider should move to the end of the queue.');
assert_same([1, 2, 3, 4, 5], array_map(fn ($r) => (int) $r['queue_position'], $reordered), 'Queue positions should be resequenced.');

$skipScenario = [
    ['id' => 1, 'status' => 'Busy', 'queue_position' => 1],
    ['id' => 2, 'status' => 'Offline', 'queue_position' => 2],
    ['id' => 3, 'status' => 'Available', 'queue_position' => 3],
    ['id' => 4, 'status' => 'Available', 'queue_position' => 4],
];
$next = $service->findNextAvailable($skipScenario);
assert_same(3, (int) $next['id'], 'Busy and Offline riders should be skipped.');

$sequence = [];
$currentQueue = $riders;
for ($i = 0; $i < 5; $i++) {
    $assigned = $service->findNextAvailable($currentQueue);
    $sequence[] = (int) $assigned['id'];
    $currentQueue = $service->reorderAfterAssignment($currentQueue, (int) $assigned['id']);
}
assert_same([1, 2, 3, 4, 5], $sequence, 'Five sequential assignments should rotate fairly across five riders.');

echo "queue_service_test.php passed\n";

<?php

declare(strict_types=1);

$tests = [
    __DIR__ . '/queue_service_test.php',
    __DIR__ . '/dispatch_rule_test.php',
    __DIR__ . '/completed_trip_rotation_test.php',
];

$failures = 0;
foreach ($tests as $testFile) {
    try {
        require $testFile;
    } catch (Throwable $exception) {
        $failures++;
        fwrite(STDERR, basename($testFile) . ' failed: ' . $exception->getMessage() . PHP_EOL);
    }
}

if ($failures > 0) {
    fwrite(STDERR, $failures . " test(s) failed.\n");
    exit(1);
}

echo "All tests passed.\n";

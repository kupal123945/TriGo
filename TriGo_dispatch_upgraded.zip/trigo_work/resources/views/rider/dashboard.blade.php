<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Rider workspace</span>
        <h1 class="h2 mb-1">TriGo Rider Dashboard</h1>
        <p class="text-muted mb-0">Welcome, <?= e($rider['full_name'] ?? '') ?>. Only your own assigned trips can be opened and updated from here.</p>
    </div>
    <div class="text-md-end">
        <div class="small text-muted">Tricycle Number</div>
        <div class="fw-semibold fs-5"><?= e($rider['tricycle_number'] ?? '—') ?></div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4"><div class="card kpi-card h-100"><div class="card-body p-4"><div class="kpi-label">Current status</div><div class="kpi-value fs-2"><?= e($rider['status'] ?? '—') ?></div><div class="kpi-meta">Availability for dispatch</div></div></div></div>
    <div class="col-md-4"><div class="card kpi-card h-100"><div class="card-body p-4"><div class="kpi-label">Queue position</div><div class="kpi-value fs-2"><?= e($rider['queue_position'] ?? '—') ?></div><div class="kpi-meta">Order used by the dispatcher</div></div></div></div>
    <div class="col-md-4"><div class="card kpi-card h-100"><div class="card-body p-4"><div class="kpi-label">Active trips</div><div class="kpi-value fs-2"><?= e((string) count($bookings)) ?></div><div class="kpi-meta">Assigned to this rider</div></div></div></div>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <div class="card table-card h-100">
            <div class="card-body">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
                    <div>
                        <h2 class="h5 mb-1">Assigned trips</h2>
                        <p class="small-muted mb-0">Keep your trip updates current so passenger and admin status stays accurate.</p>
                    </div>
                    <input type="search" class="form-control form-control-sm table-filter-input" placeholder="Filter assigned trips..." data-table-search="#riderTripsTable">
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0" id="riderTripsTable">
                        <thead>
                            <tr>
                                <th>Reference</th>
                                <th>Passenger</th>
                                <th>Pickup</th>
                                <th>Drop-off</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td class="fw-semibold"><?= e($booking['booking_reference']) ?></td>
                                    <td><?= e($booking['user_name']) ?></td>
                                    <td><?= e($booking['pickup_location']) ?></td>
                                    <td><?= e($booking['dropoff_location']) ?></td>
                                    <td><span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span></td>
                                    <td><a class="btn btn-sm btn-outline-primary" href="<?= e(url('/rider/bookings/' . $booking['id'])) ?>">Open</a></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (!$bookings): ?>
                                <tr><td colspan="6" class="text-center text-muted py-5">No active bookings assigned right now.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h4 mb-3">Rider focus</h2>
                <div class="status-timeline">
                    <div class="status-step"><span class="dot"></span><div><strong>Open only your assigned trip.</strong><div class="small-muted">This avoids cross-rider conflicts.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Update status on time.</strong><div class="small-muted">Passengers and admins rely on your trip state.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Stay available when ready.</strong><div class="small-muted">Queue rotation works best with accurate rider status.</div></div></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Assigned trip</span>
        <h1 class="h2 mb-1">Trip <?= e($booking['booking_reference']) ?></h1>
        <p class="text-muted mb-0">Open the passenger trip details and update status only if you are the assigned rider.</p>
    </div>
    <a href="<?= e(url('/rider/dashboard')) ?>" class="btn btn-outline-primary">Back to Dashboard</a>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-body p-4 p-lg-5">
                <div class="d-flex justify-content-between align-items-start gap-3 mb-4">
                    <h2 class="h4 mb-0">Trip summary</h2>
                    <span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span>
                </div>
                <div class="row g-3">
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Passenger</div><div class="value fs-5"><?= e($booking['user_name']) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Contact number</div><div class="value fs-5"><?= e($booking['contact_number']) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Pickup</div><div class="value fs-5"><?= e($booking['pickup_location']) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Drop-off</div><div class="value fs-5"><?= e($booking['dropoff_location']) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Fare estimate</div><div class="value fs-5"><?= e(format_currency($booking['fare_estimate'])) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Reference</div><div class="value fs-5"><?= e($booking['booking_reference']) ?></div></div></div>
                    <div class="col-12"><div class="mini-stat"><div class="label">Notes</div><div class="value fs-5"><?= e($booking['notes'] ?: 'None') ?></div></div></div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h4 mb-3">Timeline</h2>
                <div class="status-timeline">
                    <div class="status-step"><span class="dot"></span><div><strong>Assigned at</strong><div class="small-muted"><?= e(format_datetime($booking['assigned_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Accepted at</strong><div class="small-muted"><?= e(format_datetime($booking['accepted_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Started at</strong><div class="small-muted"><?= e(format_datetime($booking['started_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Completed at</strong><div class="small-muted"><?= e(format_datetime($booking['completed_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Updated at</strong><div class="small-muted"><?= e(format_datetime($booking['updated_at'])) ?></div></div></div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h4 mb-3">Update trip status</h2>
                <?php if ($booking['status'] === 'Assigned'): ?>
                    <form action="<?= e(url('/rider/bookings/' . $booking['id'] . '/status')) ?>" method="post" class="mb-3">
                        <?= csrf_field() ?>
                        <input type="hidden" name="status" value="Accepted">
                        <button class="btn btn-primary w-100" type="submit">Accept Trip</button>
                    </form>
                    <form action="<?= e(url('/rider/bookings/' . $booking['id'] . '/status')) ?>" method="post" class="mb-3">
                        <?= csrf_field() ?>
                        <input type="hidden" name="status" value="Cancelled">
                        <input class="form-control mb-2" type="text" name="decline_reason" placeholder="Reason for decline (optional)">
                        <button class="btn btn-outline-danger w-100" type="submit">Decline Trip</button>
                    </form>
                    <form action="<?= e(url('/rider/bookings/' . $booking['id'] . '/status')) ?>" method="post" class="mb-3">
                        <?= csrf_field() ?>
                        <input type="hidden" name="status" value="Ongoing">
                        <button class="btn btn-primary w-100" type="submit">Start Trip</button>
                    </form>
                <?php endif; ?>

                <?php if (in_array($booking['status'], ['Assigned', 'Accepted', 'Ongoing'], true)): ?>
                    <form action="<?= e(url('/rider/bookings/' . $booking['id'] . '/status')) ?>" method="post">
                        <?= csrf_field() ?>
                        <input type="hidden" name="status" value="Completed">
                        <button class="btn btn-success w-100" type="submit">Mark as Completed</button>
                    </form>
                <?php else: ?>
                    <div class="alert alert-success mb-0">This trip is already completed or no longer active.</div>
                <?php endif; ?>

                <div class="soft-divider"></div>
                <p class="small text-muted mb-0">Only the assigned rider can open this page and save status updates. Completing the trip returns your rider status to Available if you have no other active trips, while paused riders stay paused after finishing.</p>
            </div>
        </div>
    </div>
</div>

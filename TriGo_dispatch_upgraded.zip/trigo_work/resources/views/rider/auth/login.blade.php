<div class="row justify-content-center">
    <div class="col-xl-10">
        <div class="auth-panel">
            <div class="row g-0">
                <div class="col-lg-5 auth-side d-none d-lg-flex flex-column justify-content-between p-5">
                    <div>
                        <span class="badge badge-soft badge-soft-light mb-3">Rider access</span>
                        <h1 class="display-6 fw-bold">Open assigned trips and keep status accurate.</h1>
                        <p class="muted-light">Riders can log in here to review assigned bookings and accept, decline, start, and complete assigned trips.</p>
                    </div>
                    <div class="muted-light">Only the assigned rider can update a specific trip.</div>
                </div>
                <div class="col-lg-7">
                    <div class="p-4 p-md-5">
                        <h2 class="h2 mb-2">Rider Login</h2>
                        <p class="text-muted mb-4">Sign in to view your assigned trips and update trip progress.</p>
                        <form action="<?= e(url('/rider/login')) ?>" method="post">
                            <?= csrf_field() ?>
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control <?= form_error('email') ? 'is-invalid' : '' ?>" value="<?= e(old('email')) ?>" required>
                                <?php if (form_error('email')): ?><div class="invalid-feedback"><?= e(form_error('email')) ?></div><?php endif; ?>
                            </div>
                            <div class="mb-4">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control <?= form_error('password') ? 'is-invalid' : '' ?>" required>
                                <?php if (form_error('password')): ?><div class="invalid-feedback"><?= e(form_error('password')) ?></div><?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Login as Rider</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

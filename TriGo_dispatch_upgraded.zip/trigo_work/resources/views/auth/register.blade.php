<div class="row justify-content-center">
    <div class="col-xl-11">
        <div class="auth-panel">
            <div class="row g-0">
                <div class="col-lg-5 auth-side d-none d-lg-flex flex-column justify-content-between p-5">
                    <div>
                        <span class="badge badge-soft badge-soft-light mb-3">Create account</span>
                        <h1 class="display-6 fw-bold">Get ready for faster local transport booking.</h1>
                        <p class="muted-light">Register once, then manage bookings, view rider assignment, and track trip history from your account.</p>
                    </div>
                    <div class="muted-light">Built for responsive use on phones, tablets, laptops, and Windows browsers.</div>
                </div>
                <div class="col-lg-7">
                    <div class="p-4 p-md-5">
                        <h2 class="h2 mb-2">Create User Account</h2>
                        <p class="text-muted mb-4">Enter your details below to start booking trips.</p>
                        <form action="<?= e(url('/register')) ?>" method="post">
                            <?= csrf_field() ?>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="full_name" class="form-control <?= form_error('full_name') ? 'is-invalid' : '' ?>" value="<?= e(old('full_name')) ?>" required>
                                    <?php if (form_error('full_name')): ?><div class="invalid-feedback"><?= e(form_error('full_name')) ?></div><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control <?= form_error('email') ? 'is-invalid' : '' ?>" value="<?= e(old('email')) ?>" required>
                                    <?php if (form_error('email')): ?><div class="invalid-feedback"><?= e(form_error('email')) ?></div><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Phone</label>
                                    <input type="text" name="phone" class="form-control <?= form_error('phone') ? 'is-invalid' : '' ?>" value="<?= e(old('phone')) ?>" required>
                                    <?php if (form_error('phone')): ?><div class="invalid-feedback"><?= e(form_error('phone')) ?></div><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Address</label>
                                    <input type="text" name="address" class="form-control <?= form_error('address') ? 'is-invalid' : '' ?>" value="<?= e(old('address')) ?>">
                                    <?php if (form_error('address')): ?><div class="invalid-feedback"><?= e(form_error('address')) ?></div><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control <?= form_error('password') ? 'is-invalid' : '' ?>" required>
                                    <?php if (form_error('password')): ?><div class="invalid-feedback"><?= e(form_error('password')) ?></div><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Confirm Password</label>
                                    <input type="password" name="password_confirmation" class="form-control" required>
                                </div>
                            </div>
                            <button class="btn btn-primary mt-4" type="submit">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-xl-10">
        <div class="auth-panel">
            <div class="row g-0">
                <div class="col-lg-5 auth-side d-none d-lg-flex flex-column justify-content-between p-5">
                    <div>
                        <span class="badge badge-soft badge-soft-light mb-3">Passenger access</span>
                        <h1 class="display-6 fw-bold">Sign in and book a trip in minutes.</h1>
                        <p class="muted-light">Check your assigned rider, current booking status, and previous trips from one modern dashboard.</p>
                    </div>
                    <div class="muted-light">Automatic dispatch remains enabled and fair for every booking.</div>
                </div>
                <div class="col-lg-7">
                    <div class="p-4 p-md-5">
                        <h2 class="h2 mb-2">User Login</h2>
                        <p class="text-muted mb-4">Sign in to book a tricycle and track your assigned rider.</p>
                        <form action="<?= e(url('/login')) ?>" method="post">
                            <?= csrf_field() ?>
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control <?= form_error('email') ? 'is-invalid' : '' ?>" value="<?= e(old('email')) ?>" required>
                                <?php if (form_error('email')): ?><div class="invalid-feedback"><?= e(form_error('email')) ?></div><?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control <?= form_error('password') ? 'is-invalid' : '' ?>" required>
                                <?php if (form_error('password')): ?><div class="invalid-feedback"><?= e(form_error('password')) ?></div><?php endif; ?>
                            </div>
                            <button class="btn btn-primary w-100" type="submit">Login</button>
                        </form>
                        <div class="mt-3 small text-muted">No account yet? <a href="<?= e(url('/register')) ?>">Register here</a>.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

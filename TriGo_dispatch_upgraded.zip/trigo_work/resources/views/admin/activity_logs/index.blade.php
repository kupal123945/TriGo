<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">Activity Logs</h1>
        <p class="text-muted mb-0">Audit trail of user and admin actions.</p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="get" action="<?= e(url('/admin/activity-logs')) ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Search</label>
                <input type="text" name="q" class="form-control" value="<?= e($filters['q'] ?? '') ?>" placeholder="Action, description, IP address">
            </div>
            <div class="col-md-3">
                <label class="form-label">Actor Type</label>
                <?php $actorType = $filters['actor_type'] ?? ''; ?>
                <select name="actor_type" class="form-select">
                    <option value="">All</option>
                    <option value="admin" <?= selected($actorType, 'admin') ?>>Admin</option>
                    <option value="user" <?= selected($actorType, 'user') ?>>User</option>
                    <option value="system" <?= selected($actorType, 'system') ?>>System</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button class="btn btn-primary w-100" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Actor Type</th>
                        <th>Actor ID</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= e(format_datetime($log['created_at'])) ?></td>
                            <td><?= e($log['actor_type']) ?></td>
                            <td><?= e($log['actor_id'] ?: '—') ?></td>
                            <td><?= e($log['action']) ?></td>
                            <td><?= e($log['description']) ?></td>
                            <td><?= e($log['ip_address'] ?: '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$logs): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No activity logs found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">Rider Queue Management</h1>
        <p class="text-muted mb-0">Change queue order if needed. Dispatch still skips Busy or Offline riders automatically.</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body p-4">
                <form action="<?= e(url('/admin/queue')) ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th>Queue Position</th>
                                    <th>Rider</th>
                                    <th>Tricycle</th>
                                    <th>Status</th>
                                    <th>Active</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($queue as $item): ?>
                                    <tr>
                                        <td style="width: 160px;">
                                            <input type="number" min="1" name="positions[<?= e($item['rider_id']) ?>]" class="form-control" value="<?= e($item['queue_position']) ?>">
                                        </td>
                                        <td><?= e($item['full_name']) ?></td>
                                        <td><?= e($item['tricycle_number']) ?></td>
                                        <td><span class="badge <?= e(rider_status_badge_class($item['status'])) ?>"><?= e($item['status']) ?></span></td>
                                        <td><?= (int) $item['active'] === 1 ? 'Yes' : 'No' ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex gap-2 mt-3">
                        <button class="btn btn-primary" type="submit">Save Queue Order</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body p-4">
                <h2 class="h5">Reset queue</h2>
                <p class="text-muted">Restore queue positions to sequential order based on the current list.</p>
                <form action="<?= e(url('/admin/queue/reset')) ?>" method="post" data-confirm="Reset the rider queue to sequential positions?">
                    <?= csrf_field() ?>
                    <button class="btn btn-outline-warning" type="submit">Reset Queue</button>
                </form>
            </div>
        </div>
    </div>
</div>

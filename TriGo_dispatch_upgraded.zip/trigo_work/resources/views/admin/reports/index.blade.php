<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h1 class="h3 mb-1">Reports</h1>
        <p class="text-muted mb-0">Booking summaries, rider performance, and exportable trip reports.</p>
    </div>
    <a class="btn btn-outline-primary" href="<?= e(url('/admin/reports/export?date_from=' . urlencode($filters['date_from']) . '&date_to=' . urlencode($filters['date_to']))) ?>">Export CSV</a>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="get" action="<?= e(url('/admin/reports')) ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= e($filters['date_from']) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= e($filters['date_to']) ?>">
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button class="btn btn-primary w-100" type="submit">Generate Report</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3 mb-4">
    <?php $summaryCards = [
        'Total Bookings' => $summary['total_bookings'] ?? 0,
        'Assigned' => $summary['assigned_count'] ?? 0,
        'Ongoing' => $summary['ongoing_count'] ?? 0,
        'Completed' => $summary['completed_count'] ?? 0,
        'Cancelled' => $summary['cancelled_count'] ?? 0,
        'Failed / No Rider' => $summary['failed_count'] ?? 0,
    ]; ?>
    <?php foreach ($summaryCards as $label => $value): ?>
        <div class="col-sm-6 col-xl-2">
            <div class="card h-100">
                <div class="card-body">
                    <div class="small text-muted mb-1"><?= e($label) ?></div>
                    <div class="display-6 fw-semibold"><?= e((string) $value) ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="row g-4">
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-body">
                <h2 class="h5 mb-3">Rider performance</h2>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>Rider</th>
                                <th>Assigned</th>
                                <th>Completed</th>
                                <th>Cancelled</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($riderPerformance as $rider): ?>
                                <tr>
                                    <td><?= e($rider['full_name']) ?><div class="small text-muted"><?= e($rider['tricycle_number']) ?></div></td>
                                    <td><?= e($rider['total_assigned']) ?></td>
                                    <td><?= e($rider['completed_count']) ?></td>
                                    <td><?= e($rider['cancelled_count']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (!$riderPerformance): ?>
                                <tr><td colspan="4" class="text-center text-muted py-4">No rider data in the selected range.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-body">
                <h2 class="h5 mb-3">Recent bookings in range</h2>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>Reference</th>
                                <th>User</th>
                                <th>Rider</th>
                                <th>Status</th>
                                <th>Fare</th>
                                <th>Created</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td><?= e($booking['booking_reference']) ?></td>
                                    <td><?= e($booking['user_name']) ?></td>
                                    <td><?= e($booking['rider_name'] ?? 'Not assigned') ?></td>
                                    <td><span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span></td>
                                    <td><?= e(format_currency($booking['fare_estimate'])) ?></td>
                                    <td><?= e(format_datetime($booking['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (!$bookings): ?>
                                <tr><td colspan="6" class="text-center text-muted py-4">No bookings found in the selected date range.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

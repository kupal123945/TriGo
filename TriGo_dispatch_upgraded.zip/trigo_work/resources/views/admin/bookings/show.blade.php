<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">Booking Details</h1>
        <p class="text-muted mb-0">Reference <?= e($booking['booking_reference']) ?></p>
    </div>
    <a href="<?= e(url('/admin/bookings')) ?>" class="btn btn-outline-primary">Back to Bookings</a>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <div class="card mb-4">
            <div class="card-body p-4">
                <h2 class="h5 mb-3">Booking summary</h2>
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="small text-muted">Status</div>
                        <div><span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span></div>
                    </div>
                    <div class="col-md-4">
                        <div class="small text-muted">Fare estimate</div>
                        <div class="fw-semibold"><?= e(format_currency($booking['fare_estimate'])) ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="small text-muted">Created at</div>
                        <div class="fw-semibold"><?= e(format_datetime($booking['created_at'])) ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="small text-muted">Pickup location</div>
                        <div class="fw-semibold"><?= e($booking['pickup_location']) ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="small text-muted">Drop-off location</div>
                        <div class="fw-semibold"><?= e($booking['dropoff_location']) ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="small text-muted">Passenger</div>
                        <div class="fw-semibold"><?= e($booking['user_name']) ?></div>
                        <div class="small text-muted"><?= e($booking['user_phone'] ?? '') ?><?= !empty($booking['user_email']) ? ' • ' . e($booking['user_email']) : '' ?></div>
                    </div>
                    <div class="col-md-6">
                        <div class="small text-muted">Passenger contact for trip</div>
                        <div class="fw-semibold"><?= e($booking['contact_number']) ?></div>
                    </div>
                    <div class="col-12">
                        <div class="small text-muted">Notes</div>
                        <div class="fw-semibold"><?= e($booking['notes'] ?: 'None') ?></div>
                    </div>
                    <?php if (!empty($booking['no_rider_reason'])): ?>
                        <div class="col-12">
                            <div class="alert alert-warning mb-0"><?= e($booking['no_rider_reason']) ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body p-4">
                <h2 class="h5 mb-3">Assigned rider</h2>
                <?php if (!empty($booking['rider_id'])): ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="small text-muted">Rider name</div>
                            <div class="fw-semibold"><?= e($booking['rider_name']) ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Tricycle number</div>
                            <div class="fw-semibold"><?= e($booking['tricycle_number']) ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Contact</div>
                            <div class="fw-semibold"><?= e($booking['rider_phone']) ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-muted">Rider status</div>
                            <div><span class="badge <?= e(rider_status_badge_class($booking['rider_status'])) ?>"><?= e($booking['rider_status']) ?></span></div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-4">
                        <p class="mb-0">No rider assigned yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-body p-4">
                <h2 class="h5 mb-3">Trip history</h2>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Remarks</th>
                                <th>Changed By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($history as $item): ?>
                                <tr>
                                    <td><?= e(format_datetime($item['created_at'])) ?></td>
                                    <td><?= e($item['from_status'] ?: '—') ?></td>
                                    <td><?= e($item['to_status']) ?></td>
                                    <td><?= e($item['remarks']) ?></td>
                                    <td><?= e(($item['changed_by_type'] ?: 'system') . ($item['changed_by_id'] ? ' #' . $item['changed_by_id'] : '')) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (!$history): ?>
                                <tr><td colspan="5" class="text-center text-muted py-4">No trip history yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-4">
        <div class="card mb-4">
            <div class="card-body p-4">
                <h2 class="h5 mb-3">Update status</h2>
                <form action="<?= e(url('/admin/bookings/' . $booking['id'] . '/status')) ?>" method="post">
                    <?= csrf_field() ?>
                    <?php $selectedStatus = $booking['status']; ?>
                    <div class="mb-3">
                        <label class="form-label">Booking status</label>
                        <select name="status" class="form-select">
                            <?php foreach (['Assigned','Ongoing','Completed','Cancelled'] as $status): ?>
                                <option value="<?= e($status) ?>" <?= selected($selectedStatus, $status) ?>><?= e($status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button class="btn btn-primary" type="submit">Save Status</button>
                </form>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body p-4">
                <h2 class="h5 mb-3">Manual reassign</h2>
                <p class="text-muted">Only use when necessary. The system normally assigns riders automatically.</p>
                <form action="<?= e(url('/admin/bookings/' . $booking['id'] . '/reassign')) ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label">Available riders</label>
                        <select name="rider_id" class="form-select">
                            <option value="">Select rider</option>
                            <?php foreach ($availableRiders as $rider): ?>
                                <option value="<?= e($rider['id']) ?>"><?= e($rider['full_name']) ?> - <?= e($rider['tricycle_number']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button class="btn btn-outline-primary" type="submit">Reassign Booking</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body p-4">
                <h2 class="h5 mb-3">Timeline</h2>
                <div class="small-muted">
                    <div><strong>Assigned at:</strong> <?= e(format_datetime($booking['assigned_at'])) ?></div>
                    <div><strong>Started at:</strong> <?= e(format_datetime($booking['started_at'])) ?></div>
                    <div><strong>Completed at:</strong> <?= e(format_datetime($booking['completed_at'])) ?></div>
                    <div><strong>Cancelled at:</strong> <?= e(format_datetime($booking['cancelled_at'])) ?></div>
                    <div><strong>Updated at:</strong> <?= e(format_datetime($booking['updated_at'])) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">Booking Management</h1>
        <p class="text-muted mb-0">Search, filter, review, reassign, and update trip statuses.</p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="get" action="<?= e(url('/admin/bookings')) ?>" class="row g-3">
            <div class="col-lg-4">
                <label class="form-label">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Reference, rider, user, location" value="<?= e($filters['q'] ?? '') ?>">
            </div>
            <div class="col-lg-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <?php $selectedStatus = $filters['status'] ?? ''; ?>
                    <option value="">All statuses</option>
                    <?php foreach (['Pending','Assigned','Ongoing','Completed','Cancelled','Failed / No Rider Available'] as $status): ?>
                        <option value="<?= e($status) ?>" <?= selected($selectedStatus, $status) ?>><?= e($status) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2">
                <label class="form-label">From</label>
                <input type="date" name="date_from" class="form-control" value="<?= e($filters['date_from'] ?? '') ?>">
            </div>
            <div class="col-lg-2">
                <label class="form-label">To</label>
                <input type="date" name="date_to" class="form-control" value="<?= e($filters['date_to'] ?? '') ?>">
            </div>
            <div class="col-lg-1 d-flex align-items-end">
                <button class="btn btn-primary w-100" type="submit">Go</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>User</th>
                        <th>Trip</th>
                        <th>Rider</th>
                        <th>Status</th>
                        <th>Fare</th>
                        <th>Created</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                        <tr>
                            <td><?= e($booking['booking_reference']) ?></td>
                            <td><?= e($booking['user_name']) ?></td>
                            <td><?= e($booking['pickup_location']) ?> → <?= e($booking['dropoff_location']) ?></td>
                            <td><?= e($booking['rider_name'] ?? 'Not assigned') ?></td>
                            <td><span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span></td>
                            <td><?= e(format_currency($booking['fare_estimate'])) ?></td>
                            <td><?= e(format_datetime($booking['created_at'])) ?></td>
                            <td><a class="btn btn-sm btn-outline-primary" href="<?= e(url('/admin/bookings/' . $booking['id'])) ?>">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$bookings): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">No bookings found for the selected filters.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

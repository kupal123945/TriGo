<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">Notification Logs</h1>
        <p class="text-muted mb-0">Track email and optional SMS delivery results for assigned riders.</p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="get" action="<?= e(url('/admin/notifications')) ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Search</label>
                <input type="text" name="q" class="form-control" value="<?= e($filters['q'] ?? '') ?>" placeholder="Recipient, rider, booking reference">
            </div>
            <div class="col-md-3">
                <label class="form-label">Channel</label>
                <?php $selectedChannel = $filters['channel'] ?? ''; ?>
                <select name="channel" class="form-select">
                    <option value="">All channels</option>
                    <option value="email" <?= selected($selectedChannel, 'email') ?>>Email</option>
                    <option value="sms" <?= selected($selectedChannel, 'sms') ?>>SMS</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <?php $selectedStatus = $filters['status'] ?? ''; ?>
                <select name="status" class="form-select">
                    <option value="">All statuses</option>
                    <option value="sent" <?= selected($selectedStatus, 'sent') ?>>Sent</option>
                    <option value="pending" <?= selected($selectedStatus, 'pending') ?>>Pending</option>
                    <option value="failed" <?= selected($selectedStatus, 'failed') ?>>Failed</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button class="btn btn-primary w-100" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>Sent At</th>
                        <th>Booking</th>
                        <th>Rider</th>
                        <th>Channel</th>
                        <th>Recipient</th>
                        <th>Status</th>
                        <th>Message</th>
                        <th>Error</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($notifications as $log): ?>
                        <tr>
                            <td><?= e(format_datetime($log['sent_at'] ?: $log['created_at'])) ?></td>
                            <td><?= e($log['booking_reference'] ?? '—') ?></td>
                            <td><?= e($log['rider_name'] ?? '—') ?></td>
                            <td class="text-uppercase"><?= e($log['channel']) ?></td>
                            <td><?= e($log['recipient']) ?></td>
                            <td>
                                <?php $status = strtolower((string) $log['status']); ?>
                                <span class="badge <?= $status === 'sent' ? 'bg-success-subtle text-success' : ($status === 'failed' ? 'bg-danger-subtle text-danger' : 'bg-secondary-subtle text-secondary') ?>"><?= e($log['status']) ?></span>
                            </td>
                            <td><div style="max-width: 320px;" class="small"><?= e($log['message']) ?></div></td>
                            <td><div style="max-width: 260px;" class="small text-danger"><?= e($log['error_message'] ?: '—') ?></div></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$notifications): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">No notification logs found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

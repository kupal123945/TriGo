<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h1 class="h3 mb-1">Manage Riders</h1>
        <p class="text-muted mb-0">Create, edit, activate, deactivate, and maintain rider availability and queue order.</p>
    </div>
    <div class="d-flex gap-2">
        <form class="d-flex gap-2" method="get" action="<?= e(url('/admin/riders')) ?>">
            <input type="text" name="q" class="form-control" placeholder="Search riders" value="<?= e($query) ?>">
            <button class="btn btn-outline-primary" type="submit">Search</button>
        </form>
        <a class="btn btn-primary" href="<?= e(url('/admin/riders/create')) ?>">Add Rider</a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>Queue</th>
                        <th>Name</th>
                        <th>Tricycle Number</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Active</th>
                        <th>Last Assigned</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($riders as $rider): ?>
                        <tr>
                            <td><?= e($rider['queue_position']) ?></td>
                            <td><?= e($rider['full_name']) ?><div class="small text-muted"><?= e($rider['email'] ?: 'No email') ?></div></td>
                            <td><?= e($rider['tricycle_number']) ?></td>
                            <td><?= e($rider['phone']) ?></td>
                            <td><span class="badge <?= e(rider_status_badge_class($rider['status'])) ?>"><?= e($rider['status']) ?></span></td>
                            <td><?= (int) $rider['active'] === 1 ? 'Yes' : 'No' ?></td>
                            <td><?= e(format_datetime($rider['last_assigned_at'])) ?></td>
                            <td>
                                <div class="d-flex justify-content-end gap-2">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= e(url('/admin/riders/' . $rider['id'] . '/edit')) ?>">Edit</a>
                                    <form action="<?= e(url('/admin/riders/' . $rider['id'] . '/delete')) ?>" method="post" data-confirm="Delete this rider? Make sure there are no active bookings assigned.">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$riders): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">No riders found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

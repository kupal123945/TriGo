<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1"><?= e($pageTitle) ?></h1>
        <p class="text-muted mb-0">Rider records control dispatch availability, queue rotation, and rider portal access.</p>
    </div>
    <a href="<?= e(url('/admin/riders')) ?>" class="btn btn-outline-primary">Back</a>
</div>

<div class="card">
    <div class="card-body p-4">
        <form action="<?= e($rider ? url('/admin/riders/' . $rider['id']) : url('/admin/riders')) ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="full_name" class="form-control <?= form_error('full_name') ? 'is-invalid' : '' ?>" value="<?= e(old('full_name', $rider['full_name'] ?? '')) ?>" required>
                    <?php if (form_error('full_name')): ?><div class="invalid-feedback"><?= e(form_error('full_name')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control <?= form_error('phone') ? 'is-invalid' : '' ?>" value="<?= e(old('phone', $rider['phone'] ?? '')) ?>" required>
                    <?php if (form_error('phone')): ?><div class="invalid-feedback"><?= e(form_error('phone')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email (used for rider login and notifications)</label>
                    <input type="email" name="email" class="form-control <?= form_error('email') ? 'is-invalid' : '' ?>" value="<?= e(old('email', $rider['email'] ?? '')) ?>" required>
                    <?php if (form_error('email')): ?><div class="invalid-feedback"><?= e(form_error('email')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tricycle Number</label>
                    <input type="text" name="tricycle_number" class="form-control <?= form_error('tricycle_number') ? 'is-invalid' : '' ?>" value="<?= e(old('tricycle_number', $rider['tricycle_number'] ?? '')) ?>" required>
                    <?php if (form_error('tricycle_number')): ?><div class="invalid-feedback"><?= e(form_error('tricycle_number')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label"><?= $rider ? 'New Password (leave blank to keep current password)' : 'Password' ?></label>
                    <input type="password" name="password" class="form-control <?= form_error('password') ? 'is-invalid' : '' ?>" <?= $rider ? '' : 'required' ?>>
                    <?php if (form_error('password')): ?><div class="invalid-feedback"><?= e(form_error('password')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Status</label>
                    <?php $selectedStatus = old('status', $rider['status'] ?? 'Available'); ?>
                    <select name="status" class="form-select <?= form_error('status') ? 'is-invalid' : '' ?>">
                        <option value="Available" <?= selected($selectedStatus, 'Available') ?>>Available</option>
                        <option value="Busy" <?= selected($selectedStatus, 'Busy') ?>>Busy</option>
                        <option value="Paused" <?= selected($selectedStatus, 'Paused') ?>>Paused</option>
                        <option value="Offline" <?= selected($selectedStatus, 'Offline') ?>>Offline</option>
                    </select>
                    <?php if (form_error('status')): ?><div class="invalid-feedback"><?= e(form_error('status')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6 d-flex align-items-end">
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="activeRider" <?= checked(old('active', isset($rider['active']) ? (string) $rider['active'] : '1'), '1') ?>>
                        <label class="form-check-label" for="activeRider">Active rider</label>
                    </div>
                </div>
            </div>
            <button class="btn btn-primary mt-4" type="submit"><?= $rider ? 'Update Rider' : 'Create Rider' ?></button>
        </form>
    </div>
</div>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <h1 class="h3 mb-1">Manage Users</h1>
        <p class="text-muted mb-0">Search, update, activate, deactivate, or remove user accounts.</p>
    </div>
    <form class="d-flex gap-2" method="get" action="<?= e(url('/admin/users')) ?>">
        <input type="text" name="q" class="form-control" placeholder="Search users" value="<?= e($query) ?>">
        <button class="btn btn-outline-primary" type="submit">Search</button>
    </form>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= e($user['full_name']) ?></td>
                            <td><?= e($user['email']) ?></td>
                            <td><?= e($user['phone']) ?></td>
                            <td>
                                <?php if ((int) $user['active'] === 1): ?>
                                    <span class="badge bg-success-subtle text-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary-subtle text-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td><?= e(format_datetime($user['created_at'])) ?></td>
                            <td>
                                <div class="d-flex justify-content-end gap-2">
                                    <a href="<?= e(url('/admin/users/' . $user['id'] . '/edit')) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <form action="<?= e(url('/admin/users/' . $user['id'] . '/toggle-active')) ?>" method="post">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-sm btn-outline-warning" type="submit"><?= (int) $user['active'] === 1 ? 'Deactivate' : 'Activate' ?></button>
                                    </form>
                                    <form action="<?= e(url('/admin/users/' . $user['id'] . '/delete')) ?>" method="post" data-confirm="Delete this user? This only works if the user has no bookings.">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$users): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No users found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

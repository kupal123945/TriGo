<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1"><?= e($pageTitle) ?></h1>
        <p class="text-muted mb-0">Update the selected user account.</p>
    </div>
    <a href="<?= e(url('/admin/users')) ?>" class="btn btn-outline-primary">Back</a>
</div>

<div class="card">
    <div class="card-body p-4">
        <form action="<?= e(url('/admin/users/' . $user['id'])) ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="full_name" class="form-control <?= form_error('full_name') ? 'is-invalid' : '' ?>" value="<?= e(old('full_name', $user['full_name'])) ?>" required>
                    <?php if (form_error('full_name')): ?><div class="invalid-feedback"><?= e(form_error('full_name')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control <?= form_error('email') ? 'is-invalid' : '' ?>" value="<?= e(old('email', $user['email'])) ?>" required>
                    <?php if (form_error('email')): ?><div class="invalid-feedback"><?= e(form_error('email')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control <?= form_error('phone') ? 'is-invalid' : '' ?>" value="<?= e(old('phone', $user['phone'])) ?>" required>
                    <?php if (form_error('phone')): ?><div class="invalid-feedback"><?= e(form_error('phone')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Address</label>
                    <input type="text" name="address" class="form-control <?= form_error('address') ? 'is-invalid' : '' ?>" value="<?= e(old('address', $user['address'])) ?>">
                    <?php if (form_error('address')): ?><div class="invalid-feedback"><?= e(form_error('address')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">New Password</label>
                    <input type="password" name="password" class="form-control <?= form_error('password') ? 'is-invalid' : '' ?>">
                    <?php if (form_error('password')): ?><div class="invalid-feedback"><?= e(form_error('password')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control">
                </div>
                <div class="col-12">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="active" value="1" id="activeUser" <?= checked(old('active', (string) $user['active']), '1') ?>>
                        <label class="form-check-label" for="activeUser">Active account</label>
                    </div>
                </div>
            </div>
            <button class="btn btn-primary mt-4" type="submit">Save User</button>
        </form>
    </div>
</div>

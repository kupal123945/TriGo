<div class="row justify-content-center">
    <div class="col-xl-10">
        <div class="auth-panel">
            <div class="row g-0">
                <div class="col-lg-5 auth-side d-none d-lg-flex flex-column justify-content-between p-5">
                    <div>
                        <span class="badge badge-soft badge-soft-light mb-3">Admin access</span>
                        <h1 class="display-6 fw-bold">Run dispatch operations with better visibility.</h1>
                        <p class="muted-light">Manage riders, queue rotation, bookings, fares, reports, notifications, and system settings from one responsive admin experience.</p>
                    </div>
                    <div class="muted-light">Operational controls remain aligned with the current PHP MVC architecture.</div>
                </div>
                <div class="col-lg-7">
                    <div class="p-4 p-md-5">
                        <h2 class="h2 mb-2">Admin Login</h2>
                        <p class="text-muted mb-4">Sign in to manage the transport system securely.</p>
                        <form action="<?= e(url('/admin/login')) ?>" method="post">
                            <?= csrf_field() ?>
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control <?= form_error('email') ? 'is-invalid' : '' ?>" value="<?= e(old('email')) ?>" required>
                                <?php if (form_error('email')): ?><div class="invalid-feedback"><?= e(form_error('email')) ?></div><?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" class="form-control <?= form_error('password') ? 'is-invalid' : '' ?>" required>
                                <?php if (form_error('password')): ?><div class="invalid-feedback"><?= e(form_error('password')) ?></div><?php endif; ?>
                            </div>
                            <button class="btn btn-dark w-100" type="submit">Login as Admin</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Operations overview</span>
        <h1 class="h2 mb-1">TriGo Admin Dashboard</h1>
        <p class="text-muted mb-0">Track bookings, riders, users, notifications, and the latest operational activity from one streamlined command center.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-outline-primary" href="<?= e(url('/admin/bookings')) ?>">Manage Bookings</a>
        <a class="btn btn-primary" href="<?= e(url('/admin/riders')) ?>">Manage Riders</a>
    </div>
</div>

<?php
$cards = [
    ['label' => 'Total Bookings', 'value' => $stats['total_bookings'] ?? 0, 'meta' => 'All recorded trips'],
    ['label' => 'Total Users', 'value' => $stats['total_users'] ?? 0, 'meta' => 'Registered passengers'],
    ['label' => 'Available Riders', 'value' => $stats['available_riders'] ?? 0, 'meta' => 'Ready for dispatch'],
    ['label' => 'Busy Riders', 'value' => $stats['busy_riders'] ?? 0, 'meta' => 'Currently on trips'],
    ['label' => 'Completed Rides', 'value' => $stats['completed_rides'] ?? 0, 'meta' => 'Finished successfully'],
    ['label' => 'Cancelled Rides', 'value' => $stats['cancelled_rides'] ?? 0, 'meta' => 'User or system cancellations'],
    ['label' => 'Notifications Sent', 'value' => $stats['notification_success'] ?? 0, 'meta' => 'Delivered successfully'],
    ['label' => 'Active Dispatches', 'value' => $stats['active_dispatches'] ?? 0, 'meta' => 'Trips in motion now'],
];
?>
<div class="row g-3 mb-4">
    <?php foreach ($cards as $card): ?>
        <div class="col-sm-6 col-xl-3">
            <div class="card kpi-card h-100">
                <div class="card-body p-4">
                    <div class="kpi-label"><?= e($card['label']) ?></div>
                    <div class="kpi-value"><?= e((string) $card['value']) ?></div>
                    <div class="kpi-meta"><?= e($card['meta']) ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="row g-4 mb-4">
    <div class="col-xl-8">
        <div class="card dashboard-gradient h-100">
            <div class="card-body p-4 p-lg-5 text-white">
                <div class="d-flex flex-column flex-lg-row justify-content-between gap-4">
                    <div>
                        <span class="badge badge-soft badge-soft-light mb-3">Operational pulse</span>
                        <h2 class="h3 mb-2">Dispatch performance at a glance</h2>
                        <p class="mb-0 text-white-50">Use these live ratios to spot pressure, service quality, and rider capacity before they become bottlenecks.</p>
                    </div>
                    <div class="d-flex flex-column gap-2 text-lg-end">
                        <div class="metric-chip">Pending dispatches: <?= e((string) ($stats['pending_dispatches'] ?? 0)) ?></div>
                        <div class="metric-chip">Notification reliability: <?= e(number_format((float) ($insights['notification_reliability'] ?? 0), 1)) ?>%</div>
                    </div>
                </div>
                <div class="row g-3 mt-1">
                    <div class="col-md-3"><div class="mini-stat mini-stat-dark h-100"><div class="label">Completion rate</div><div class="value fs-4"><?= e(number_format((float) ($insights['completion_rate'] ?? 0), 1)) ?>%</div><div class="text-white-50 small">Trips successfully finished.</div></div></div>
                    <div class="col-md-3"><div class="mini-stat mini-stat-dark h-100"><div class="label">Cancellation rate</div><div class="value fs-4"><?= e(number_format((float) ($insights['cancellation_rate'] ?? 0), 1)) ?>%</div><div class="text-white-50 small">Monitor friction and no-shows.</div></div></div>
                    <div class="col-md-3"><div class="mini-stat mini-stat-dark h-100"><div class="label">Rider utilization</div><div class="value fs-4"><?= e(number_format((float) ($insights['rider_utilization'] ?? 0), 1)) ?>%</div><div class="text-white-50 small">Active riders currently busy.</div></div></div>
                    <div class="col-md-3"><div class="mini-stat mini-stat-dark h-100"><div class="label">Active load</div><div class="value fs-4"><?= e((string) ($stats['active_dispatches'] ?? 0)) ?></div><div class="text-white-50 small">Trips that need monitoring.</div></div></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h5 mb-1">Quick actions</h2>
                <p class="small-muted mb-3">Jump into the most common admin tasks.</p>
                <div class="quick-actions quick-actions-stack">
                    <a class="quick-action" href="<?= e(url('/admin/queue')) ?>"><strong>Review Queue</strong><div class="small-muted mt-1">Check rider order and availability.</div></a>
                    <a class="quick-action" href="<?= e(url('/admin/bookings')) ?>"><strong>Inspect Bookings</strong><div class="small-muted mt-1">Search, filter, and review trip records.</div></a>
                    <a class="quick-action" href="<?= e(url('/admin/notifications')) ?>"><strong>Notification Logs</strong><div class="small-muted mt-1">Spot delivery issues quickly.</div></a>
                    <a class="quick-action" href="<?= e(url('/admin/reports')) ?>"><strong>Open Reports</strong><div class="small-muted mt-1">See operational summaries and totals.</div></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <div class="card table-card h-100">
            <div class="card-body">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
                    <div>
                        <h2 class="h5 mb-1">Recent bookings</h2>
                        <p class="small-muted mb-0">Latest transactions moving through the booking lifecycle.</p>
                    </div>
                    <div class="d-flex flex-wrap gap-2 align-items-center">
                        <input type="search" class="form-control form-control-sm table-filter-input" placeholder="Filter bookings..." data-table-search="#recentBookingsTable">
                        <a class="btn btn-outline-primary btn-sm" href="<?= e(url('/admin/bookings')) ?>">View all bookings</a>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0" id="recentBookingsTable">
                        <thead>
                            <tr>
                                <th>Reference</th>
                                <th>User</th>
                                <th>Rider</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($recentBookings, 0, 10) as $booking): ?>
                                <tr>
                                    <td class="fw-semibold"><?= e($booking['booking_reference']) ?></td>
                                    <td><?= e($booking['user_name']) ?></td>
                                    <td><?= e($booking['rider_name'] ?? 'Not assigned') ?></td>
                                    <td><span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span></td>
                                    <td><?= e(format_datetime($booking['created_at'])) ?></td>
                                    <td><a class="btn btn-sm btn-outline-primary" href="<?= e(url('/admin/bookings/' . $booking['id'])) ?>">View</a></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (!$recentBookings): ?>
                                <tr><td colspan="6" class="text-center text-muted py-5">No bookings yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card h-100">
            <div class="card-body p-4">
                <h2 class="h5 mb-1">Latest activity</h2>
                <p class="small-muted mb-3">Recent audit and operational events.</p>
                <?php if (!$latestLogs): ?>
                    <div class="empty-state py-4">
                        <p class="mb-0">No activity logs yet.</p>
                    </div>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($latestLogs as $log): ?>
                            <div class="list-group-item px-0 py-3">
                                <div class="fw-semibold mb-1"><?= e($log['action']) ?></div>
                                <div class="small text-muted mb-1"><?= e($log['description']) ?></div>
                                <div class="small text-muted"><?= e(format_datetime($log['created_at'])) ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

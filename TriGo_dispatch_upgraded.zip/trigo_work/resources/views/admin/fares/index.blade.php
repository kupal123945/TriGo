<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">Fare Settings</h1>
        <p class="text-muted mb-0">Configure booking fare estimate values and user cancellation window.</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-body p-4">
                <form action="<?= e(url('/admin/fares')) ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Base Fare</label>
                            <input type="number" step="0.01" min="0" name="base_fare" class="form-control <?= form_error('base_fare') ? 'is-invalid' : '' ?>" value="<?= e(old('base_fare', $settings['base_fare'] ?? '0')) ?>" required>
                            <?php if (form_error('base_fare')): ?><div class="invalid-feedback"><?= e(form_error('base_fare')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Booking Fee</label>
                            <input type="number" step="0.01" min="0" name="booking_fee" class="form-control <?= form_error('booking_fee') ? 'is-invalid' : '' ?>" value="<?= e(old('booking_fee', $settings['booking_fee'] ?? '0')) ?>" required>
                            <?php if (form_error('booking_fee')): ?><div class="invalid-feedback"><?= e(form_error('booking_fee')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Night Surcharge</label>
                            <input type="number" step="0.01" min="0" name="night_surcharge" class="form-control <?= form_error('night_surcharge') ? 'is-invalid' : '' ?>" value="<?= e(old('night_surcharge', $settings['night_surcharge'] ?? '0')) ?>" required>
                            <?php if (form_error('night_surcharge')): ?><div class="invalid-feedback"><?= e(form_error('night_surcharge')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Cancellation Window (minutes)</label>
                            <input type="number" min="0" name="cancellation_window_minutes" class="form-control <?= form_error('cancellation_window_minutes') ? 'is-invalid' : '' ?>" value="<?= e(old('cancellation_window_minutes', $settings['cancellation_window_minutes'] ?? '10')) ?>" required>
                            <?php if (form_error('cancellation_window_minutes')): ?><div class="invalid-feedback"><?= e(form_error('cancellation_window_minutes')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Fare Notes</label>
                            <textarea name="notes" rows="4" class="form-control <?= form_error('notes') ? 'is-invalid' : '' ?>"><?= e(old('notes', $settings['notes'] ?? '')) ?></textarea>
                            <?php if (form_error('notes')): ?><div class="invalid-feedback"><?= e(form_error('notes')) ?></div><?php endif; ?>
                        </div>
                    </div>
                    <button class="btn btn-primary mt-4" type="submit">Save Fare Settings</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-body p-4">
                <h2 class="h5 mb-3">Current estimate preview</h2>
                <?php
                $preview = (float) ($settings['base_fare'] ?? 0) + (float) ($settings['booking_fee'] ?? 0);
                ?>
                <div class="display-5 fw-semibold mb-2"><?= e(format_currency($preview)) ?></div>
                <p class="text-muted mb-0">The default fare estimate shown to the passenger is based on the configured flat base fare plus booking fee. Night surcharge may be applied later by policy or custom logic.</p>
            </div>
        </div>
    </div>
</div>

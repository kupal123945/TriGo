<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">System Settings</h1>
        <p class="text-muted mb-0">Configure terminal information, free SMTP email delivery, and optional local SMS gateway integration.</p>
    </div>
</div>

<div class="card">
    <div class="card-body p-4">
        <form action="<?= e(url('/admin/settings')) ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-4">
                <div class="col-12">
                    <h2 class="h5">General</h2>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Terminal Name</label>
                    <input type="text" name="terminal_name" class="form-control <?= form_error('terminal_name') ? 'is-invalid' : '' ?>" value="<?= e(old('terminal_name', $settings['terminal_name'] ?? app_name())) ?>" required>
                    <?php if (form_error('terminal_name')): ?><div class="invalid-feedback"><?= e(form_error('terminal_name')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Support Email</label>
                    <input type="email" name="support_email" class="form-control <?= form_error('support_email') ? 'is-invalid' : '' ?>" value="<?= e(old('support_email', $settings['support_email'] ?? '')) ?>">
                    <?php if (form_error('support_email')): ?><div class="invalid-feedback"><?= e(form_error('support_email')) ?></div><?php endif; ?>
                </div>

                <div class="col-12">
                    <hr>
                    <h2 class="h5">SMTP Email Notifications</h2>
                    <p class="text-muted">Email is the default free notification channel. If password is left blank, the saved SMTP password stays unchanged.</p>
                </div>
                <div class="col-md-3">
                    <div class="form-check mt-4">
                        <input class="form-check-input" type="checkbox" id="smtpEnabled" name="smtp_enabled" value="1" <?= checked(old('smtp_enabled', $settings['smtp_enabled'] ?? '0'), '1') ?>>
                        <label class="form-check-label" for="smtpEnabled">Enable SMTP email</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">SMTP Host</label>
                    <input type="text" name="smtp_host" class="form-control <?= form_error('smtp_host') ? 'is-invalid' : '' ?>" value="<?= e(old('smtp_host', $settings['smtp_host'] ?? '')) ?>">
                    <?php if (form_error('smtp_host')): ?><div class="invalid-feedback"><?= e(form_error('smtp_host')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Port</label>
                    <input type="number" min="1" name="smtp_port" class="form-control <?= form_error('smtp_port') ? 'is-invalid' : '' ?>" value="<?= e(old('smtp_port', $settings['smtp_port'] ?? '587')) ?>">
                    <?php if (form_error('smtp_port')): ?><div class="invalid-feedback"><?= e(form_error('smtp_port')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Encryption</label>
                    <?php $enc = old('smtp_encryption', $settings['smtp_encryption'] ?? 'tls'); ?>
                    <select name="smtp_encryption" class="form-select <?= form_error('smtp_encryption') ? 'is-invalid' : '' ?>">
                        <option value="tls" <?= selected($enc, 'tls') ?>>TLS</option>
                        <option value="ssl" <?= selected($enc, 'ssl') ?>>SSL</option>
                        <option value="none" <?= selected($enc, 'none') ?>>None</option>
                    </select>
                    <?php if (form_error('smtp_encryption')): ?><div class="invalid-feedback"><?= e(form_error('smtp_encryption')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">SMTP Username</label>
                    <input type="text" name="smtp_username" class="form-control <?= form_error('smtp_username') ? 'is-invalid' : '' ?>" value="<?= e(old('smtp_username', $settings['smtp_username'] ?? '')) ?>">
                    <?php if (form_error('smtp_username')): ?><div class="invalid-feedback"><?= e(form_error('smtp_username')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">SMTP Password / App Password</label>
                    <input type="password" name="smtp_password" class="form-control <?= form_error('smtp_password') ? 'is-invalid' : '' ?>" value="">
                    <?php if (form_error('smtp_password')): ?><div class="invalid-feedback"><?= e(form_error('smtp_password')) ?></div><?php endif; ?>
                    <div class="form-text">Leave blank to keep the current saved password.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">From Email</label>
                    <input type="email" name="smtp_from_email" class="form-control <?= form_error('smtp_from_email') ? 'is-invalid' : '' ?>" value="<?= e(old('smtp_from_email', $settings['smtp_from_email'] ?? '')) ?>">
                    <?php if (form_error('smtp_from_email')): ?><div class="invalid-feedback"><?= e(form_error('smtp_from_email')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">From Name</label>
                    <input type="text" name="smtp_from_name" class="form-control <?= form_error('smtp_from_name') ? 'is-invalid' : '' ?>" value="<?= e(old('smtp_from_name', $settings['smtp_from_name'] ?? ($settings['terminal_name'] ?? app_name()))) ?>">
                    <?php if (form_error('smtp_from_name')): ?><div class="invalid-feedback"><?= e(form_error('smtp_from_name')) ?></div><?php endif; ?>
                </div>

                <div class="col-12">
                    <hr>
                    <h2 class="h5">Optional Local SMS Gateway</h2>
                    <p class="text-muted">This is optional. Use only if you have your own Android SMS bridge, GSM modem bridge, or local HTTP endpoint.</p>
                </div>
                <div class="col-md-3">
                    <div class="form-check mt-4">
                        <input class="form-check-input" type="checkbox" id="smsEnabled" name="sms_enabled" value="1" <?= checked(old('sms_enabled', $settings['sms_enabled'] ?? '0'), '1') ?>>
                        <label class="form-check-label" for="smsEnabled">Enable SMS fallback</label>
                    </div>
                </div>
                <div class="col-md-5">
                    <label class="form-label">Gateway URL</label>
                    <input type="text" name="sms_gateway_url" class="form-control <?= form_error('sms_gateway_url') ? 'is-invalid' : '' ?>" value="<?= e(old('sms_gateway_url', $settings['sms_gateway_url'] ?? '')) ?>">
                    <?php if (form_error('sms_gateway_url')): ?><div class="invalid-feedback"><?= e(form_error('sms_gateway_url')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label class="form-label">HTTP Method</label>
                    <?php $smsMethod = old('sms_http_method', $settings['sms_http_method'] ?? 'POST'); ?>
                    <select name="sms_http_method" class="form-select <?= form_error('sms_http_method') ? 'is-invalid' : '' ?>">
                        <option value="POST" <?= selected($smsMethod, 'POST') ?>>POST</option>
                        <option value="GET" <?= selected($smsMethod, 'GET') ?>>GET</option>
                    </select>
                    <?php if (form_error('sms_http_method')): ?><div class="invalid-feedback"><?= e(form_error('sms_http_method')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Token</label>
                    <input type="password" name="sms_token" class="form-control <?= form_error('sms_token') ? 'is-invalid' : '' ?>" value="">
                    <?php if (form_error('sms_token')): ?><div class="invalid-feedback"><?= e(form_error('sms_token')) ?></div><?php endif; ?>
                    <div class="form-text">Leave blank to keep current token.</div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Token Parameter</label>
                    <input type="text" name="sms_token_param" class="form-control <?= form_error('sms_token_param') ? 'is-invalid' : '' ?>" value="<?= e(old('sms_token_param', $settings['sms_token_param'] ?? 'token')) ?>">
                    <?php if (form_error('sms_token_param')): ?><div class="invalid-feedback"><?= e(form_error('sms_token_param')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Recipient Parameter</label>
                    <input type="text" name="sms_recipient_param" class="form-control <?= form_error('sms_recipient_param') ? 'is-invalid' : '' ?>" value="<?= e(old('sms_recipient_param', $settings['sms_recipient_param'] ?? 'phone')) ?>">
                    <?php if (form_error('sms_recipient_param')): ?><div class="invalid-feedback"><?= e(form_error('sms_recipient_param')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Message Parameter</label>
                    <input type="text" name="sms_message_param" class="form-control <?= form_error('sms_message_param') ? 'is-invalid' : '' ?>" value="<?= e(old('sms_message_param', $settings['sms_message_param'] ?? 'message')) ?>">
                    <?php if (form_error('sms_message_param')): ?><div class="invalid-feedback"><?= e(form_error('sms_message_param')) ?></div><?php endif; ?>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Authorization Header</label>
                    <input type="text" name="sms_auth_header" class="form-control <?= form_error('sms_auth_header') ? 'is-invalid' : '' ?>" value="<?= e(old('sms_auth_header', $settings['sms_auth_header'] ?? 'Authorization')) ?>">
                    <?php if (form_error('sms_auth_header')): ?><div class="invalid-feedback"><?= e(form_error('sms_auth_header')) ?></div><?php endif; ?>
                </div>
            </div>
            <button class="btn btn-primary mt-4" type="submit">Save Settings</button>
        </form>
    </div>
</div>

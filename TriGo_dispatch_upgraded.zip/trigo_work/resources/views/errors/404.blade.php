<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-body p-5 text-center">
                <div class="display-5 fw-bold mb-3">404</div>
                <h1 class="h3 mb-3"><?= e($pageTitle ?? 'Page Not Found') ?></h1>
                <p class="text-muted mb-4"><?= e($message ?? 'The page you requested could not be found.') ?></p>
                <a class="btn btn-primary" href="<?= e(url('/')) ?>">Go Home</a>
            </div>
        </div>
    </div>
</div>

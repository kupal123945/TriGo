<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-body p-5 text-center">
                <div class="display-5 fw-bold mb-3">500</div>
                <h1 class="h3 mb-3"><?= e($pageTitle ?? 'Application Error') ?></h1>
                <p class="text-muted mb-4"><?= e($message ?? 'Something went wrong while processing your request.') ?></p>
                <a class="btn btn-primary" href="<?= e(url('/')) ?>">Return to Home</a>
            </div>
        </div>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-body p-5 text-center">
                <div class="display-5 fw-bold mb-3">419</div>
                <h1 class="h3 mb-3"><?= e($pageTitle ?? 'Session Expired') ?></h1>
                <p class="text-muted mb-4"><?= e($message ?? 'Please refresh the page and try again.') ?></p>
                <a class="btn btn-primary" href="<?= e(url('/')) ?>">Refresh Flow</a>
            </div>
        </div>
    </div>
</div>

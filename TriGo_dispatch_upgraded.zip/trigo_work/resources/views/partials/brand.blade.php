<?php $compact = $compact ?? false; ?>
<span class="brand-mark <?= $compact ? 'brand-mark-sm' : '' ?>" aria-hidden="true">
    <svg viewBox="0 0 64 64" role="img" focusable="false">
        <defs>
            <linearGradient id="trigoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#22c55e"></stop>
                <stop offset="55%" stop-color="#2563eb"></stop>
                <stop offset="100%" stop-color="#7c3aed"></stop>
            </linearGradient>
        </defs>
        <rect x="6" y="6" width="52" height="52" rx="18" fill="url(#trigoGradient)"></rect>
        <path d="M20 21h24v6H35v17h-6V27h-9z" fill="#fff"></path>
        <circle cx="45" cy="45" r="6" fill="rgba(255,255,255,0.92)"></circle>
    </svg>
</span>
<span class="brand-wordmark">
    <span class="brand-title">TriGo</span>
    <?php if (!$compact): ?><span class="brand-subtitle">Dispatch</span><?php endif; ?>
</span>

<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Current trip</span>
        <h1 class="h2 mb-1">Current Booking</h1>
        <p class="text-muted mb-0">See your latest active trip and assigned rider information.</p>
    </div>
    <a href="<?= e(url('/bookings/history')) ?>" class="btn btn-outline-primary">View History</a>
</div>

<?php if (!$booking): ?>
    <div class="empty-state">
        <h2 class="h4 mb-2">No active booking</h2>
        <p class="mb-3 text-muted">You do not have an active Pending, Assigned, or Ongoing booking right now.</p>
        <a href="<?= e(url('/bookings/create')) ?>" class="btn btn-primary">Book a Tricycle</a>
    </div>
<?php else: ?>
    <div class="row g-4">
        <div class="col-lg-7">
            <div class="card h-100">
                <div class="card-body p-4 p-lg-5">
                    <div class="d-flex justify-content-between align-items-start gap-3 mb-4">
                        <div>
                            <h2 class="h4 mb-1">Booking summary</h2>
                            <p class="small-muted mb-0">Reference <?= e($booking['booking_reference']) ?></p>
                        </div>
                        <span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span>
                    </div>
                    <div class="row g-3">
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Pickup</div><div class="value fs-5"><?= e($booking['pickup_location']) ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Drop-off</div><div class="value fs-5"><?= e($booking['dropoff_location']) ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Assigned rider</div><div class="value fs-5"><?= e($booking['rider_name'] ?? 'Not assigned') ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Fare estimate</div><div class="value fs-5"><?= e(format_currency($booking['fare_estimate'])) ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Tricycle number</div><div class="value fs-5"><?= e($booking['tricycle_number'] ?? 'N/A') ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Rider contact</div><div class="value fs-5"><?= e($booking['rider_phone'] ?? 'N/A') ?></div></div></div>
                    </div>
                    <div class="d-flex flex-wrap gap-2 mt-4">
                        <a href="<?= e(url('/bookings/' . $booking['booking_reference'])) ?>" class="btn btn-primary">View full details</a>
                        <?php if ($canCancel): ?>
                            <form action="<?= e(url('/bookings/' . $booking['id'] . '/cancel')) ?>" method="post" data-confirm="Cancel this booking?">
                                <?= csrf_field() ?>
                                <button class="btn btn-outline-danger" type="submit">Cancel Booking</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card h-100">
                <div class="card-body p-4 p-lg-5">
                    <h2 class="h4 mb-3">Status guidance</h2>
                    <div class="status-timeline">
                        <div class="status-step"><span class="dot"></span><div><strong>Pending</strong><div class="small-muted">Your request is being prepared for assignment.</div></div></div>
                        <div class="status-step"><span class="dot"></span><div><strong>Assigned</strong><div class="small-muted">A rider has been selected by the system.</div></div></div>
                        <div class="status-step"><span class="dot"></span><div><strong>Ongoing</strong><div class="small-muted">The rider has started the trip.</div></div></div>
                        <div class="status-step"><span class="dot"></span><div><strong>Completed</strong><div class="small-muted">The trip has been closed successfully.</div></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">New booking</span>
        <h1 class="h2 mb-1">Book a Tricycle</h1>
        <p class="text-muted mb-0">Enter the trip details below. TriGo will assign the next available rider automatically and show a smarter live summary before you submit.</p>
    </div>
    <a href="<?= e(url('/dashboard')) ?>" class="btn btn-outline-primary">Back to Dashboard</a>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <form action="<?= e(url('/bookings')) ?>" method="post" class="row g-3" data-booking-form data-base-fare="<?= e((string) ($fareEstimate ?? 0)) ?>" data-night-surcharge="15">
                    <?= csrf_field() ?>
                    <div class="col-12">
                        <label class="form-label">Pickup location</label>
                        <input type="text" name="pickup_location" class="form-control <?= form_error('pickup_location') ? 'is-invalid' : '' ?>" value="<?= e(old('pickup_location')) ?>" placeholder="Enter the pickup point" required>
                        <?php if (form_error('pickup_location')): ?><div class="invalid-feedback"><?= e(form_error('pickup_location')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Drop-off location</label>
                        <input type="text" name="dropoff_location" class="form-control <?= form_error('dropoff_location') ? 'is-invalid' : '' ?>" value="<?= e(old('dropoff_location')) ?>" placeholder="Enter the destination" required>
                        <?php if (form_error('dropoff_location')): ?><div class="invalid-feedback"><?= e(form_error('dropoff_location')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Contact number</label>
                        <input type="text" name="contact_number" class="form-control <?= form_error('contact_number') ? 'is-invalid' : '' ?>" value="<?= e(old('contact_number', current_user()['phone'] ?? '')) ?>" placeholder="09XXXXXXXXX" required>
                        <?php if (form_error('contact_number')): ?><div class="invalid-feedback"><?= e(form_error('contact_number')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Live fare guide</label>
                        <div class="trip-estimate-card">
                            <div class="trip-estimate-price" data-fare-output><?= e(format_currency((float) ($fareEstimate ?? 0))) ?></div>
                            <div class="small text-muted">Starts from your configured base fare and updates for nighttime submissions.</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Additional notes <span class="text-muted fw-normal">optional</span></label>
                        <textarea name="notes" rows="4" class="form-control <?= form_error('notes') ? 'is-invalid' : '' ?>" placeholder="Landmarks, pickup guidance, or other useful details" data-notes-input><?= e(old('notes')) ?></textarea>
                        <div class="form-text"><span data-notes-count>0</span>/500 characters</div>
                        <?php if (form_error('notes')): ?><div class="invalid-feedback"><?= e(form_error('notes')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-12 pt-2 d-flex flex-wrap gap-2">
                        <button class="btn btn-primary px-4" type="submit">Submit Booking</button>
                        <a href="<?= e(url('/bookings/current')) ?>" class="btn btn-outline-primary">View Current Booking</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h4 mb-3">Trip summary</h2>
                <div class="trip-summary-card mb-4">
                    <div class="trip-summary-row"><span>Pickup</span><strong data-summary-pickup>Not set</strong></div>
                    <div class="trip-summary-row"><span>Drop-off</span><strong data-summary-dropoff>Not set</strong></div>
                    <div class="trip-summary-row"><span>Contact</span><strong data-summary-contact><?= e(old('contact_number', current_user()['phone'] ?? 'Not set')) ?></strong></div>
                    <div class="trip-summary-row"><span>Dispatch</span><strong>Auto queue-based</strong></div>
                </div>
                <div class="status-timeline mb-4">
                    <div class="status-step"><span class="dot"></span><div><strong>Check the pickup and drop-off.</strong><div class="small-muted">Exact locations help reduce delay.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Use a valid contact number.</strong><div class="small-muted">This helps coordination for pickup.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Rider assignment is automatic.</strong><div class="small-muted">Users cannot choose riders manually.</div></div></div>
                </div>
                <div class="mini-stat mb-3">
                    <div class="label">Dispatch mode</div>
                    <div class="value fs-5">Queue-based fairness</div>
                    <div class="text-muted small">The system picks the next active and available rider.</div>
                </div>
                <div class="mini-stat">
                    <div class="label">After submission</div>
                    <div class="value fs-5">Immediate booking details</div>
                    <div class="text-muted small">You will see the assigned rider and booking reference as soon as the dispatch succeeds.</div>
                </div>
            </div>
        </div>
    </div>
</div>

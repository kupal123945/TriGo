<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Booking details</span>
        <h1 class="h2 mb-1">Reference <?= e($booking['booking_reference']) ?></h1>
        <p class="text-muted mb-0">Full trip record, rider details, and lifecycle timestamps.</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <button class="btn btn-outline-primary" type="button" data-copy-text="<?= e($booking['booking_reference']) ?>">Copy Reference</button>
        <a href="<?= e(url('/bookings/history')) ?>" class="btn btn-outline-primary">Back to History</a>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card mb-4">
            <div class="card-body p-4 p-lg-5">
                <div class="d-flex justify-content-between align-items-start gap-3 mb-4">
                    <h2 class="h4 mb-0">Booking summary</h2>
                    <span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span>
                </div>
                <div class="row g-3">
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Pickup location</div><div class="value fs-5"><?= e($booking['pickup_location']) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Drop-off location</div><div class="value fs-5"><?= e($booking['dropoff_location']) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Passenger contact</div><div class="value fs-5"><?= e($booking['contact_number']) ?></div></div></div>
                    <div class="col-md-6"><div class="mini-stat h-100"><div class="label">Estimated fare</div><div class="value fs-5"><?= e(format_currency($booking['fare_estimate'])) ?></div></div></div>
                    <div class="col-12"><div class="mini-stat"><div class="label">Notes</div><div class="value fs-5"><?= e($booking['notes'] ?: 'None') ?></div></div></div>
                    <?php if (!empty($booking['no_rider_reason'])): ?>
                        <div class="col-12"><div class="alert alert-warning mb-0"><?= e($booking['no_rider_reason']) ?></div></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h4 mb-3">Timeline</h2>
                <div class="status-timeline">
                    <div class="status-step"><span class="dot"></span><div><strong>Booked at</strong><div class="small-muted"><?= e(format_datetime($booking['created_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Assigned at</strong><div class="small-muted"><?= e(format_datetime($booking['assigned_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Started at</strong><div class="small-muted"><?= e(format_datetime($booking['started_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Completed at</strong><div class="small-muted"><?= e(format_datetime($booking['completed_at'])) ?></div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Cancelled at</strong><div class="small-muted"><?= e(format_datetime($booking['cancelled_at'])) ?></div></div></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h4 mb-3">Assigned rider</h2>
                <?php if (!empty($booking['rider_id'])): ?>
                    <div class="row g-3">
                        <div class="col-12"><div class="mini-stat"><div class="label">Rider name</div><div class="value fs-5"><?= e($booking['rider_name']) ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Tricycle number</div><div class="value fs-5"><?= e($booking['tricycle_number']) ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Contact number</div><div class="value fs-5"><?= e($booking['rider_phone']) ?></div></div></div>
                        <div class="col-12"><div class="mini-stat"><div class="label">Rider status</div><div class="value fs-5"><span class="badge <?= e(rider_status_badge_class($booking['rider_status'])) ?>"><?= e($booking['rider_status']) ?></span></div></div></div>
                    </div>
                <?php else: ?>
                    <div class="empty-state py-4"><p class="mb-0">No rider assigned for this booking.</p></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($canCancel): ?>
            <div class="card mt-4">
                <div class="card-body p-4 p-lg-5">
                    <h2 class="h5">Need to cancel?</h2>
                    <p class="text-muted">User cancellation is only allowed within the configured cancellation window.</p>
                    <form action="<?= e(url('/bookings/' . $booking['id'] . '/cancel')) ?>" method="post" data-confirm="Are you sure you want to cancel this booking?">
                        <?= csrf_field() ?>
                        <button class="btn btn-outline-danger" type="submit">Cancel Booking</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Trip archive</span>
        <h1 class="h2 mb-1">Booking History</h1>
        <p class="text-muted mb-0">Review your previous tricycle bookings and open any trip for full details.</p>
    </div>
    <a href="<?= e(url('/bookings/create')) ?>" class="btn btn-primary">New Booking</a>
</div>

<div class="card table-card">
    <div class="card-body">
        <?php if (!$bookings): ?>
            <div class="empty-state py-5">
                <h3 class="h5 mb-2">No bookings yet</h3>
                <p class="mb-3 text-muted">Your completed and cancelled trips will appear here after you start booking.</p>
                <a href="<?= e(url('/bookings/create')) ?>" class="btn btn-primary">Create your first booking</a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Pickup</th>
                            <th>Drop-off</th>
                            <th>Status</th>
                            <th>Assigned Rider</th>
                            <th>Created At</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td class="fw-semibold"><?= e($booking['booking_reference']) ?></td>
                                <td><?= e($booking['pickup_location']) ?></td>
                                <td><?= e($booking['dropoff_location']) ?></td>
                                <td><span class="badge <?= e(status_badge_class($booking['status'])) ?>"><?= e($booking['status']) ?></span></td>
                                <td><?= e($booking['rider_name'] ?? 'Not assigned') ?></td>
                                <td><?= e(format_datetime($booking['created_at'])) ?></td>
                                <td><a href="<?= e(url('/bookings/' . $booking['booking_reference'])) ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

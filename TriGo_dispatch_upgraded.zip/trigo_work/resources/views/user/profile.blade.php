<div class="row justify-content-center">
    <div class="col-lg-10 col-xl-9">
        <div class="page-header">
            <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Account settings</span>
            <h1 class="h2 mb-1">Profile</h1>
            <p class="text-muted mb-0">Update your account information and optional password details.</p>
        </div>
        <div class="card">
            <div class="card-body p-4 p-lg-5">
                <form action="<?= e(url('/profile')) ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control <?= form_error('full_name') ? 'is-invalid' : '' ?>" value="<?= e(old('full_name', $user['full_name'] ?? '')) ?>" required>
                            <?php if (form_error('full_name')): ?><div class="invalid-feedback"><?= e(form_error('full_name')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control <?= form_error('email') ? 'is-invalid' : '' ?>" value="<?= e(old('email', $user['email'] ?? '')) ?>" required>
                            <?php if (form_error('email')): ?><div class="invalid-feedback"><?= e(form_error('email')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Phone</label>
                            <input type="text" name="phone" class="form-control <?= form_error('phone') ? 'is-invalid' : '' ?>" value="<?= e(old('phone', $user['phone'] ?? '')) ?>" required>
                            <?php if (form_error('phone')): ?><div class="invalid-feedback"><?= e(form_error('phone')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Address</label>
                            <input type="text" name="address" class="form-control <?= form_error('address') ? 'is-invalid' : '' ?>" value="<?= e(old('address', $user['address'] ?? '')) ?>">
                            <?php if (form_error('address')): ?><div class="invalid-feedback"><?= e(form_error('address')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">New Password</label>
                            <input type="password" name="password" class="form-control <?= form_error('password') ? 'is-invalid' : '' ?>">
                            <?php if (form_error('password')): ?><div class="invalid-feedback"><?= e(form_error('password')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="password_confirmation" class="form-control">
                        </div>
                    </div>
                    <button class="btn btn-primary mt-4" type="submit">Save Profile</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
    <div>
        <span class="badge bg-primary-subtle text-primary badge-soft mb-2">Passenger workspace</span>
        <h1 class="h2 mb-1">Welcome to TriGo</h1>
        <p class="text-muted mb-0">Book quickly, see the assigned rider immediately, and keep track of your active and past trips with a cleaner trip workspace.</p>
    </div>
    <a href="<?= e(url('/bookings/create')) ?>" class="btn btn-primary">Book a Tricycle</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card kpi-card h-100"><div class="card-body p-4"><div class="kpi-label">Active booking</div><div class="kpi-value"><?= $activeBooking ? '1' : '0' ?></div><div class="kpi-meta">Visible in real time</div></div></div>
    </div>
    <div class="col-md-4">
        <div class="card kpi-card h-100"><div class="card-body p-4"><div class="kpi-label">Dispatch type</div><div class="kpi-value">Auto</div><div class="kpi-meta">Fair queue-based assignment</div></div></div>
    </div>
    <div class="col-md-4">
        <div class="card kpi-card h-100"><div class="card-body p-4"><div class="kpi-label">Recent trips</div><div class="kpi-value"><?= e((string) count($bookings)) ?></div><div class="kpi-meta">Latest history snapshot</div></div></div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
                    <div>
                        <h2 class="h4 mb-1">Current booking</h2>
                        <p class="small-muted mb-0">Your latest active trip appears here.</p>
                    </div>
                    <?php if ($activeBooking): ?>
                        <span class="badge <?= e(status_badge_class($activeBooking['status'])) ?>"><?= e($activeBooking['status']) ?></span>
                    <?php endif; ?>
                </div>
                <?php if ($activeBooking): ?>
                    <div class="row g-3">
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Reference</div><div class="value fs-5"><?= e($activeBooking['booking_reference']) ?></div></div></div>
                        <div class="col-sm-6"><div class="mini-stat h-100"><div class="label">Assigned rider</div><div class="value fs-5"><?= e($activeBooking['rider_name'] ?? 'Not assigned') ?></div></div></div>
                        <div class="col-12"><div class="mini-stat"><div class="label">Trip route</div><div class="value fs-5"><?= e($activeBooking['pickup_location']) ?> → <?= e($activeBooking['dropoff_location']) ?></div></div></div>
                    </div>
                    <div class="d-flex flex-wrap gap-2 mt-4">
                        <a href="<?= e(url('/bookings/' . $activeBooking['booking_reference'])) ?>" class="btn btn-primary">View details</a>
                        <button type="button" class="btn btn-outline-primary" data-copy-text="<?= e($activeBooking['booking_reference']) ?>">Copy reference</button>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <h3 class="h5 mb-2">No active booking</h3>
                        <p class="mb-3 text-muted">You do not have a Pending, Assigned, or Ongoing booking right now.</p>
                        <a href="<?= e(url('/bookings/create')) ?>" class="btn btn-primary">Create a booking</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <h2 class="h4 mb-3">Quick guide</h2>
                <div class="status-timeline">
                    <div class="status-step"><span class="dot"></span><div><strong>Submit your route clearly.</strong><div class="small-muted">Add landmarks for faster pickup.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>The next eligible rider is assigned.</strong><div class="small-muted">Busy and offline riders are skipped automatically.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Track and reuse your trip info.</strong><div class="small-muted">Copy references and review recent rides anytime.</div></div></div>
                </div>
                <div class="soft-divider"></div>
                <a href="<?= e(url('/bookings/history')) ?>" class="btn btn-outline-primary w-100">View booking history</a>
            </div>
        </div>
    </div>
</div>

<div class="hero mb-4 mb-lg-5">
    <div class="row align-items-center g-4 position-relative">
        <div class="col-lg-7">
            <span class="badge badge-soft badge-soft-light mb-3">Smart tricycle dispatch for modern local transport</span>
            <h1 class="display-5 fw-bold mb-3">Move passengers faster with <span class="text-gradient-light">TriGo</span>.</h1>
            <p class="lead mb-4">TriGo modernizes terminal dispatch with cleaner booking flows, fair rider assignment, responsive dashboards, and better visibility for passengers, riders, and admins.</p>
            <div class="d-flex flex-wrap gap-2 mb-4">
                <?php if (is_user_logged_in()): ?>
                    <a href="<?= e(url('/bookings/create')) ?>" class="btn btn-light btn-lg px-4">Book a Ride</a>
                    <a href="<?= e(url('/dashboard')) ?>" class="btn btn-outline-light btn-lg px-4">Open Dashboard</a>
                <?php else: ?>
                    <a href="<?= e(url('/register')) ?>" class="btn btn-light btn-lg px-4">Create Account</a>
                    <a href="<?= e(url('/login')) ?>" class="btn btn-outline-light btn-lg px-4">User Login</a>
                <?php endif; ?>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <span class="metric-chip">Auto rider dispatch</span>
                <span class="metric-chip">Live trip visibility</span>
                <span class="metric-chip">Theme toggle + mobile-first UI</span>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="glass-card rounded-4 p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <div class="text-uppercase small fw-bold opacity-75">Why TriGo feels better</div>
                        <h2 class="h4 mb-0">Smarter booking experience</h2>
                    </div>
                    <span class="badge badge-soft badge-soft-light">New</span>
                </div>
                <div class="status-timeline">
                    <div class="status-step"><span class="dot"></span><div><strong>Guided booking form.</strong><div class="eyebrow">Live route summary, improved estimate display, and smarter notes.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Clearer dispatch status.</strong><div class="eyebrow">Passengers and riders see cleaner cards and action flows.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Admin command center.</strong><div class="eyebrow">Operational pulse, utilization, and filtered booking table.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Modern brand identity.</strong><div class="eyebrow">TriGo logo, stronger layout rhythm, and better visual hierarchy.</div></div></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 g-lg-4 mb-4 mb-lg-5">
    <div class="col-md-4">
        <div class="card feature-card h-100">
            <div class="card-body p-4">
                <div class="feature-icon">01</div>
                <h2 class="h5">Passenger-first flow</h2>
                <p class="mb-0 text-muted">A more polished homepage and dashboard make ride requests easier to understand, trust, and complete on any screen size.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card feature-card h-100">
            <div class="card-body p-4">
                <div class="feature-icon">02</div>
                <h2 class="h5">Fair dispatch rules</h2>
                <p class="mb-0 text-muted">Passengers still cannot choose riders manually. The server assigns the next active and available rider while skipping busy or offline riders.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card feature-card h-100">
            <div class="card-body p-4">
                <div class="feature-icon">03</div>
                <h2 class="h5">Operational visibility</h2>
                <p class="mb-0 text-muted">Admins now get a stronger overview of dispatch health, while riders and users see cleaner trip context and faster actions.</p>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 align-items-stretch">
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <span class="badge bg-primary-subtle text-primary badge-soft mb-3">Modernized platform highlights</span>
                <h2 class="section-title">Better layout, stronger trust, smoother daily use</h2>
                <p class="text-muted">This upgrade keeps your existing dispatch logic intact while making the product look more premium and work more smoothly for real-world terminal operations.</p>
                <div class="row g-3 mt-1">
                    <div class="col-sm-6">
                        <div class="mini-stat h-100"><div class="label">Branding</div><div class="value">TriGo</div><div class="text-muted small">New logo and cleaner identity across pages.</div></div>
                    </div>
                    <div class="col-sm-6">
                        <div class="mini-stat h-100"><div class="label">Customization</div><div class="value">Theme-ready</div><div class="text-muted small">Light and dark view toggle with saved preference.</div></div>
                    </div>
                    <div class="col-sm-6">
                        <div class="mini-stat h-100"><div class="label">Booking tools</div><div class="value">Smarter</div><div class="text-muted small">Live trip summary and guided fare preview.</div></div>
                    </div>
                    <div class="col-sm-6">
                        <div class="mini-stat h-100"><div class="label">Admin controls</div><div class="value">Sharper</div><div class="text-muted small">Operational insight cards and quick filtering.</div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-body p-4 p-lg-5">
                <h2 class="section-title">Core operating rules</h2>
                <div class="status-timeline">
                    <div class="status-step"><span class="dot"></span><div><strong>No manual rider selection.</strong><div class="small-muted">Automatic dispatch is preserved.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Fair queue handling.</strong><div class="small-muted">Assignment respects active rider order.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Availability-aware.</strong><div class="small-muted">Busy and offline riders are skipped.</div></div></div>
                    <div class="status-step"><span class="dot"></span><div><strong>Shared-hosting compatible.</strong><div class="small-muted">Still ready for practical PHP hosting.</div></div></div>
                </div>
            </div>
        </div>
    </div>
</div>

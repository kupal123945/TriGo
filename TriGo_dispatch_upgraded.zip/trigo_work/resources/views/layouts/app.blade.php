<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(($pageTitle ?? 'App') . ' - ' . app_name()) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg topbar-blur sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?= e(url('/')) ?>">
            <?php view_partial('partials.brand', ['compact' => true]); ?>
        </a>
        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                <li class="nav-item"><a class="nav-link <?= route_is('/') ? 'active fw-semibold' : '' ?>" href="<?= e(url('/')) ?>">Home</a></li>
                <?php if (is_user_logged_in()): ?>
                    <li class="nav-item"><a class="nav-link <?= route_is('/dashboard') ? 'active fw-semibold' : '' ?>" href="<?= e(url('/dashboard')) ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link <?= route_is('/bookings/create') ? 'active fw-semibold' : '' ?>" href="<?= e(url('/bookings/create')) ?>">Book Ride</a></li>
                    <li class="nav-item"><a class="nav-link <?= route_is('/bookings/current') ? 'active fw-semibold' : '' ?>" href="<?= e(url('/bookings/current')) ?>">Current Booking</a></li>
                    <li class="nav-item"><a class="nav-link <?= route_is('/bookings/history') ? 'active fw-semibold' : '' ?>" href="<?= e(url('/bookings/history')) ?>">History</a></li>
                <?php elseif (is_rider_logged_in()): ?>
                    <li class="nav-item"><a class="nav-link <?= route_is('/rider/dashboard') ? 'active fw-semibold' : '' ?>" href="<?= e(url('/rider/dashboard')) ?>">Rider Dashboard</a></li>
                <?php endif; ?>
            </ul>
            <div class="d-flex flex-column flex-lg-row align-items-stretch align-items-lg-center gap-2">
                <button class="btn btn-glass btn-sm" type="button" data-theme-toggle aria-label="Toggle theme">🌗 Theme</button>
                <div class="live-chip d-none d-lg-inline-flex" data-live-clock></div>
                <?php if (is_user_logged_in()): ?>
                    <span class="small text-muted d-none d-lg-inline">Hello, <?= e(current_user()['full_name'] ?? '') ?></span>
                    <a class="btn btn-outline-primary btn-sm" href="<?= e(url('/profile')) ?>">Profile</a>
                    <form action="<?= e(url('/logout')) ?>" method="post" class="d-inline">
                        <?= csrf_field() ?>
                        <button class="btn btn-primary btn-sm w-100" type="submit">Logout</button>
                    </form>
                <?php elseif (is_rider_logged_in()): ?>
                    <span class="small text-muted d-none d-lg-inline">Rider: <?= e(current_rider()['full_name'] ?? '') ?></span>
                    <form action="<?= e(url('/rider/logout')) ?>" method="post" class="d-inline">
                        <?= csrf_field() ?>
                        <button class="btn btn-primary btn-sm w-100" type="submit">Logout</button>
                    </form>
                <?php else: ?>
                    <a class="btn btn-outline-primary btn-sm" href="<?= e(url('/login')) ?>">User Login</a>
                    <a class="btn btn-outline-success btn-sm" href="<?= e(url('/rider/login')) ?>">Rider Login</a>
                    <a class="btn btn-primary btn-sm" href="<?= e(url('/register')) ?>">Register</a>
                    <a class="btn btn-dark btn-sm" href="<?= e(url('/admin/login')) ?>">Admin Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<main class="app-shell">
    <div class="container">
        <div class="flash-stack mb-3"><?php view_partial('partials.flash'); ?></div>
        <?= $content ?>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>

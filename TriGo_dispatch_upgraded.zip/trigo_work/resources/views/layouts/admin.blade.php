<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(($pageTitle ?? 'Admin') . ' - ' . app_name()) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
</head>
<body>
<div class="container-fluid py-3 py-lg-4">
    <div class="row g-3 g-lg-4">
        <div class="col-lg-3 col-xl-2">
            <aside class="sidebar sticky-top top-0">
                <div class="sidebar-header">
                    <div class="d-flex align-items-center gap-2 mb-2"><?php view_partial('partials.brand', ['compact' => true]); ?></div>
                    <div class="sidebar-brand fs-5">Admin Control</div>
                    <div class="small mt-2">Logged in as <?= e(current_admin()['full_name'] ?? 'Administrator') ?></div>
                </div>
                <nav class="nav flex-column mb-3">
                    <a class="nav-link <?= route_is('/admin/dashboard') ? 'active' : '' ?>" href="<?= e(url('/admin/dashboard')) ?>">Dashboard <span class="nav-hint">01</span></a>
                    <a class="nav-link <?= route_is('/admin/users*') ? 'active' : '' ?>" href="<?= e(url('/admin/users')) ?>">Users <span class="nav-hint">02</span></a>
                    <a class="nav-link <?= route_is('/admin/riders*') ? 'active' : '' ?>" href="<?= e(url('/admin/riders')) ?>">Riders <span class="nav-hint">03</span></a>
                    <a class="nav-link <?= route_is('/admin/queue*') ? 'active' : '' ?>" href="<?= e(url('/admin/queue')) ?>">Rider Queue <span class="nav-hint">04</span></a>
                    <a class="nav-link <?= route_is('/admin/bookings*') ? 'active' : '' ?>" href="<?= e(url('/admin/bookings')) ?>">Bookings <span class="nav-hint">05</span></a>
                    <a class="nav-link <?= route_is('/admin/notifications*') ? 'active' : '' ?>" href="<?= e(url('/admin/notifications')) ?>">Notifications <span class="nav-hint">06</span></a>
                    <a class="nav-link <?= route_is('/admin/reports*') ? 'active' : '' ?>" href="<?= e(url('/admin/reports')) ?>">Reports <span class="nav-hint">07</span></a>
                    <a class="nav-link <?= route_is('/admin/fares*') ? 'active' : '' ?>" href="<?= e(url('/admin/fares')) ?>">Fare Settings <span class="nav-hint">08</span></a>
                    <a class="nav-link <?= route_is('/admin/settings*') ? 'active' : '' ?>" href="<?= e(url('/admin/settings')) ?>">System Settings <span class="nav-hint">09</span></a>
                    <a class="nav-link <?= route_is('/admin/activity-logs*') ? 'active' : '' ?>" href="<?= e(url('/admin/activity-logs')) ?>">Activity Logs <span class="nav-hint">10</span></a>
                </nav>
                <div class="soft-divider"></div>
                <div class="d-grid gap-2">
                    <button class="btn btn-glass btn-sm" type="button" data-theme-toggle>🌗 Theme</button>
                    <div class="live-chip justify-content-center" data-live-clock></div>
                    <a class="btn btn-outline-light btn-sm" href="<?= e(url('/')) ?>">View Public Site</a>
                    <form action="<?= e(url('/admin/logout')) ?>" method="post">
                        <?= csrf_field() ?>
                        <button class="btn btn-danger btn-sm w-100" type="submit">Logout</button>
                    </form>
                </div>
            </aside>
        </div>
        <div class="col-lg-9 col-xl-10">
            <div class="flash-stack mb-3"><?php view_partial('partials.flash'); ?></div>
            <?= $content ?>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>

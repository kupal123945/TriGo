<?php

declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
require BASE_PATH . '/bootstrap/autoload.php';

use App\Core\Database;

try {
    $pdo = Database::getConnection();
    $files = glob(__DIR__ . '/migrations/*.sql') ?: [];
    sort($files, SORT_STRING);

    foreach ($files as $file) {
        $sql = trim((string) file_get_contents($file));
        if ($sql === '') {
            continue;
        }
        echo 'Running migration: ' . basename($file) . PHP_EOL;
        $pdo->exec($sql);
    }

    echo 'All migrations completed successfully.' . PHP_EOL;
} catch (Throwable $exception) {
    fwrite(STDERR, 'Migration failed: ' . $exception->getMessage() . PHP_EOL);
    exit(1);
}

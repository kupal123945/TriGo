<?php

declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__));
require BASE_PATH . '/bootstrap/autoload.php';

use App\Core\Database;

try {
    $pdo = Database::getConnection();
    $sql = trim((string) file_get_contents(__DIR__ . '/seeders/sample_data.sql'));
    if ($sql !== '') {
        $pdo->exec($sql);
    }
    echo 'Sample data imported successfully.' . PHP_EOL;
} catch (Throwable $exception) {
    fwrite(STDERR, 'Seed failed: ' . $exception->getMessage() . PHP_EOL);
    exit(1);
}

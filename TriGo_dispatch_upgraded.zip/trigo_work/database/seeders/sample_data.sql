-- Sample seed data for Terminal Tricycle Dispatch
SET NAMES utf8mb4;

INSERT INTO admins (id, full_name, email, password, active, created_at, updated_at) VALUES
(1, 'System Administrator', 'admin@terminal.local', '$2y$12$h7aq7UxQKO5fzht2ueSSKOHd6QgzPWKyaZ7U3pwdYWDrWXonETkTe', 1, NOW(), NOW())
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), email = VALUES(email), password = VALUES(password), active = VALUES(active), updated_at = VALUES(updated_at);

INSERT INTO users (id, full_name, email, password, phone, address, active, created_at, updated_at) VALUES
(1, 'Juan Dela Cruz', 'juan@example.com', '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC', '09171234567', 'Poblacion Barangay Hall', 1, NOW(), NOW()),
(2, 'Maria Santos', 'maria@example.com', '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC', '09179876543', 'Public Market Area', 1, NOW(), NOW())
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), email = VALUES(email), password = VALUES(password), phone = VALUES(phone), address = VALUES(address), active = VALUES(active), updated_at = VALUES(updated_at);

INSERT INTO riders (id, full_name, phone, email, password, tricycle_number, status, queue_position, last_assigned_at, active, created_at, updated_at) VALUES
(1, 'Rider One', '09170000001', 'rider1@example.com', '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC', 'TRI-001', 'Available', 1, NULL, 1, NOW(), NOW()),
(2, 'Rider Two', '09170000002', 'rider2@example.com', '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC', 'TRI-002', 'Available', 2, NULL, 1, NOW(), NOW()),
(3, 'Rider Three', '09170000003', 'rider3@example.com', '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC', 'TRI-003', 'Available', 3, NULL, 1, NOW(), NOW()),
(4, 'Rider Four', '09170000004', 'rider4@example.com', '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC', 'TRI-004', 'Available', 4, NULL, 1, NOW(), NOW()),
(5, 'Rider Five', '09170000005', 'rider5@example.com', '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC', 'TRI-005', 'Available', 5, NULL, 1, NOW(), NOW())
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name), phone = VALUES(phone), email = VALUES(email), password = VALUES(password), tricycle_number = VALUES(tricycle_number), status = VALUES(status), queue_position = VALUES(queue_position), active = VALUES(active), updated_at = VALUES(updated_at);

INSERT INTO rider_queue (rider_id, queue_position, created_at, updated_at) VALUES
(1, 1, NOW(), NOW()),
(2, 2, NOW(), NOW()),
(3, 3, NOW(), NOW()),
(4, 4, NOW(), NOW()),
(5, 5, NOW(), NOW())
ON DUPLICATE KEY UPDATE queue_position = VALUES(queue_position), updated_at = VALUES(updated_at);

INSERT INTO fare_settings (id, base_fare, booking_fee, night_surcharge, notes, cancellation_window_minutes, created_at, updated_at) VALUES
(1, 25.00, 0.00, 0.00, 'Default flat fare estimate for terminal/community dispatch.', 5, NOW(), NOW())
ON DUPLICATE KEY UPDATE base_fare = VALUES(base_fare), booking_fee = VALUES(booking_fee), night_surcharge = VALUES(night_surcharge), notes = VALUES(notes), cancellation_window_minutes = VALUES(cancellation_window_minutes), updated_at = VALUES(updated_at);

INSERT INTO system_settings (setting_key, setting_value, created_at, updated_at) VALUES
('terminal_name', 'Community Tricycle Terminal', NOW(), NOW()),
('support_email', 'support@example.com', NOW(), NOW()),
('smtp_enabled', '0', NOW(), NOW()),
('smtp_host', '', NOW(), NOW()),
('smtp_port', '587', NOW(), NOW()),
('smtp_encryption', 'tls', NOW(), NOW()),
('smtp_username', '', NOW(), NOW()),
('smtp_password', '', NOW(), NOW()),
('smtp_from_email', '', NOW(), NOW()),
('smtp_from_name', 'Community Tricycle Terminal', NOW(), NOW()),
('sms_enabled', '0', NOW(), NOW()),
('sms_gateway_url', '', NOW(), NOW()),
('sms_http_method', 'POST', NOW(), NOW()),
('sms_token', '', NOW(), NOW()),
('sms_token_param', 'token', NOW(), NOW()),
('sms_recipient_param', 'to', NOW(), NOW()),
('sms_message_param', 'message', NOW(), NOW()),
('sms_auth_header', 'Authorization', NOW(), NOW())
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at);

ALTER TABLE notifications
    ADD COLUMN IF NOT EXISTS subject VARCHAR(255) DEFAULT NULL AFTER recipient,
    ADD COLUMN IF NOT EXISTS attempts INT UNSIGNED NOT NULL DEFAULT 0 AFTER status,
    ADD COLUMN IF NOT EXISTS available_at DATETIME DEFAULT NULL AFTER attempts,
    ADD INDEX IF NOT EXISTS idx_notifications_status_available (status, available_at);

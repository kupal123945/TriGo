CREATE TABLE IF NOT EXISTS trip_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    booking_id INT UNSIGNED NOT NULL,
    from_status VARCHAR(40) DEFAULT NULL,
    to_status VARCHAR(40) NOT NULL,
    remarks TEXT NOT NULL,
    changed_by_type VARCHAR(20) DEFAULT NULL,
    changed_by_id INT UNSIGNED DEFAULT NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_trip_history_booking (booking_id),
    INDEX idx_trip_history_created_at (created_at),
    CONSTRAINT fk_trip_history_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

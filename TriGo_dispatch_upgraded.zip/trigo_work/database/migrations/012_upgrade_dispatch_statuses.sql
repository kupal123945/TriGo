ALTER TABLE riders
    MODIFY status VARCHAR(20) NOT NULL DEFAULT 'Available';

ALTER TABLE riders
    ADD COLUMN IF NOT EXISTS last_seen_at DATETIME DEFAULT NULL AFTER last_assigned_at;

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS accepted_at DATETIME DEFAULT NULL AFTER assigned_at,
    ADD COLUMN IF NOT EXISTS declined_at DATETIME DEFAULT NULL AFTER accepted_at,
    ADD COLUMN IF NOT EXISTS decline_reason VARCHAR(255) DEFAULT NULL AFTER no_rider_reason,
    ADD INDEX IF NOT EXISTS idx_bookings_status_assigned_accepted (status, assigned_at, accepted_at);

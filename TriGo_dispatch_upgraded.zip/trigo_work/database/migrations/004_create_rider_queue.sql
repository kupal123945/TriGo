CREATE TABLE IF NOT EXISTS rider_queue (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    rider_id INT UNSIGNED NOT NULL,
    queue_position INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    UNIQUE KEY uq_rider_queue_rider (rider_id),
    UNIQUE KEY uq_rider_queue_position (queue_position),
    CONSTRAINT fk_rider_queue_rider FOREIGN KEY (rider_id) REFERENCES riders(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

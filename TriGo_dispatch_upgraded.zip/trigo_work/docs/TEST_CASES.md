# Manual Test Cases

## 1. User cannot choose a rider
- Open booking page as user
- Confirm there is no rider dropdown
- Submit a malicious request with `rider_id` in payload
- Expected: backend ignores user-supplied `rider_id` and still auto-assigns based on queue

## 2. Fair round-robin assignment
- Seed 5 available riders
- Book 5 rides one at a time and mark each prior trip completed before the next booking
- Expected assignment order: Rider 1, Rider 2, Rider 3, Rider 4, Rider 5

## 3. Skip Busy and Offline riders
- Mark Rider 1 Busy and Rider 2 Offline
- Create a new booking
- Expected: Rider 3 is assigned

## 4. No available rider
- Mark all riders Busy or Offline
- Create a booking
- Expected: booking is saved with status `Failed / No Rider Available` and no rider is assigned

## 5. Rider becomes Busy after assignment
- Make sure Rider 1 is available
- Create a booking
- Expected: assigned rider status becomes `Busy`

## 6. Rider becomes Available after completion
- Complete a booking in admin panel
- Expected: assigned rider becomes `Available` if no other active trip is linked to that rider

## 7. User cancellation window
- Configure cancellation window to 5 minutes
- Create a booking
- Cancel within 5 minutes
- Expected: booking becomes `Cancelled`, rider becomes `Available` if idle

## 8. Admin manual reassign
- Open booking details
- Reassign to another available rider
- Expected: booking keeps `Assigned` status, old rider becomes available if idle, new rider becomes busy, queue updates

## 9. Email notification logging
- Configure valid SMTP
- Create a booking with a rider email available
- Expected: notification is sent and logged in `notifications` with channel `email` and status `sent`

## 10. Activity logs
- Perform admin login, create rider, update fare settings, cancel booking
- Expected: actions appear in `activity_logs`

## 11. Report export
- Open Reports and export CSV
- Expected: CSV downloads with filtered bookings

## 12. Concurrency check
- Simulate two users submitting bookings at nearly the same time
- Expected: both bookings get different riders when available, with no duplicate assignment of the same rider

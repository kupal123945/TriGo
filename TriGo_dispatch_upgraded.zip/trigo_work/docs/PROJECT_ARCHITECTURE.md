# Project Architecture

## Overview
This package is a lightweight Laravel-style MVC application built specifically for easy upload to shared hosting such as InfinityFree. It keeps the same practical separation of concerns you would expect from Laravel:

- `app/Controllers` for request handling
- `app/Models` for table access
- `app/Services` for business logic such as dispatch and notifications
- `app/Middleware` for auth and CSRF enforcement
- `resources/views` for Bootstrap-based UI templates
- `routes/web.php` for route definitions

## Core business rule
The user never selects a rider. Rider assignment happens only in `DispatchService` using a fair round-robin queue:

1. Validate request
2. Insert booking as `Pending`
3. Lock active riders with `FOR UPDATE`
4. Pick the first `Available` rider in queue order
5. Mark that rider `Busy`
6. Update booking to `Assigned`
7. Move assigned rider to end of queue
8. Commit transaction
9. Send rider email notification and optional SMS fallback
10. Show rider details immediately to the user

## Request lifecycle
1. `index.php` boots the application.
2. `App::run()` creates the request and loads `routes/web.php`.
3. Router matches the path and executes middleware.
4. Controller validates request data and delegates to services.
5. Services perform transactional business logic.
6. Views render Bootstrap pages.

## Folder structure
```text
tricycle-dispatch-system/
├── .htaccess
├── index.php
├── app/
│   ├── Controllers/
│   ├── Core/
│   ├── Helpers/
│   ├── Middleware/
│   ├── Models/
│   └── Services/
├── assets/
│   ├── css/app.css
│   └── js/app.js
├── bootstrap/
├── config/
├── database/
│   ├── migrations/
│   ├── seeders/
│   ├── migrate.php
│   ├── seed.php
│   └── schema.sql
├── docs/
├── resources/
│   └── views/
├── routes/
├── tests/
└── vendor/
    └── PHPMailer/
```

## Key services
### `DispatchService`
- Creates bookings atomically
- Prevents duplicate rider assignment under concurrent requests
- Moves assigned rider to the end of the queue
- Sends notifications after commit

### `QueueService`
- Reads active riders in queue order
- Skips `Busy` and `Offline` riders
- Persists queue changes to both `riders.queue_position` and `rider_queue`
- Supports admin reorder and queue reset

### `BookingService`
- Handles booking history and active booking retrieval
- Releases riders when trips are completed or cancelled
- Applies cancellation rules
- Records trip status history

### `NotificationService`
- Sends free SMTP email first
- Optionally calls a local SMS HTTP bridge
- Stores all notification attempts in `notifications`

## Security design
- Passwords are hashed with PHP `password_hash`
- Admin and user sessions are separated
- Admin routes require admin auth middleware
- User routes require user auth middleware
- CSRF token validation is applied to POST requests
- Validation is applied in controllers before writes
- Audit logging is stored in `activity_logs`

## UI design
- Bootstrap 5 responsive layout
- Separate admin and public layouts
- Mobile-friendly booking flow
- No rider selection UI on the booking page

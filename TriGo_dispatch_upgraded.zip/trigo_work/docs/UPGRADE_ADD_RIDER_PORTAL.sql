ALTER TABLE riders
    MODIFY email VARCHAR(150) NOT NULL,
    ADD COLUMN password VARCHAR(255) NOT NULL AFTER email,
    ADD UNIQUE KEY uq_riders_email (email);

UPDATE riders
SET password = '$2y$12$gJKM685z.Yz4cejG5ygZB.AfOVdb/mXV5w8o/IJ4pnnELYO8NLqgC'
WHERE password = '' OR password IS NULL;

# Installation Guide

## Requirements
- PHP 8.1+ with PDO MySQL
- MySQL / MariaDB
- Web server with `.htaccess` support
- Optional SMTP account for email notifications

## Quick setup
1. Copy the project into your web root.
2. Edit `config/database.php` with your database credentials.
3. Option A: import `database/schema.sql` and then `database/seeders/sample_data.sql` using phpMyAdmin.
4. Option B: from CLI run:
   ```bash
   php database/migrate.php
   php database/seed.php
   ```
5. Edit `config/app.php` if you want to change the app name or base URL.
6. Visit the site in your browser.
7. Log in as admin and immediately change SMTP settings and default credentials.

## Default credentials from sample data
- Admin: `admin@terminal.local` / `Admin123!`
- User: `juan@example.com` / `User123!`
- User: `maria@example.com` / `User123!`

Change these passwords after first login.

## Database import notes
Import order if using phpMyAdmin:
1. `database/schema.sql`
2. `database/seeders/sample_data.sql`

## SMTP setup after login
1. Sign in as admin.
2. Open **System Settings**.
3. Enable SMTP.
4. Enter host, port, encryption, username, password, and sender details.
5. Save settings.
6. Book a test ride to confirm rider emails are logged in **Notification Logs**.

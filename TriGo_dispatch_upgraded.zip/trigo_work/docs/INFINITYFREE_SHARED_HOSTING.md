# InfinityFree Shared Hosting Guide

## Upload strategy
This package is designed so you can upload it directly without Composer on the server.

1. Create your MySQL database from the InfinityFree control panel.
2. Edit `config/database.php` with the MySQL host, database name, username, and password from your hosting panel.
3. Upload the project files to your site root using File Manager or FTP.
4. Import `database/schema.sql` and `database/seeders/sample_data.sql` using phpMyAdmin.
5. Visit the website and log in as admin.
6. Configure SMTP in **System Settings**.
7. Change the default passwords immediately.

## Important InfinityFree notes
- Keep `.htaccess` uploaded because routing depends on it.
- The app already blocks direct access to `app`, `bootstrap`, `config`, `database`, `docs`, `routes`, `tests`, and `vendor` using `.htaccess`.
- Leave `config/app.php` `base_url` empty if you want automatic URL detection. If your site is in a subfolder, you may set it manually.

## SMTP recommendation for InfinityFree
Do not rely on PHP `mail()` on free hosting. Use external SMTP in **System Settings**.
Suggested fields:
- SMTP host: your provider host
- SMTP port: usually `587`
- SMTP encryption: `tls`
- SMTP username: full email address
- SMTP password: app password or SMTP password
- From email: same sender email or approved sender

## Gmail app password example
If you use Gmail SMTP:
1. Enable 2-Step Verification on the Google account.
2. Create a 16-character app password.
3. Use that app password in the SMTP password field.
4. Use `smtp.gmail.com`, port `587`, encryption `tls`.

## Recommended first production actions
- Change seeded admin and user passwords
- Add real rider emails and phone numbers
- Configure fare settings
- Configure terminal name and support email
- Disable or remove sample users if not needed

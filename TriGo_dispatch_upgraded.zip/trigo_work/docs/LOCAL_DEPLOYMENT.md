# Local Deployment Guide

## XAMPP / Laragon / WAMP setup
1. Put the project folder inside your web root:
   - XAMPP: `htdocs/tricycle-dispatch-system`
   - Laragon: `www/tricycle-dispatch-system`
2. Create a MySQL database, for example `tricycle_dispatch`.
3. Edit `config/database.php`:
   - host: `127.0.0.1`
   - port: `3306`
   - database: your database name
   - username/password: your local DB credentials
4. Import `database/schema.sql` then `database/seeders/sample_data.sql`.
5. Start Apache and MySQL.
6. Open:
   - `http://localhost/tricycle-dispatch-system/`
7. Log in with the default sample credentials.

## Local email testing
You can use any free SMTP provider or a local mail catcher.
Examples:
- Gmail SMTP with an app password
- Mailpit / MailHog via local SMTP bridge
- A self-hosted SMTP relay

## Local SMS bridge testing
If you have an Android phone or local gateway app that exposes an HTTP endpoint:
1. Enable SMS in **System Settings**.
2. Enter the gateway URL.
3. Map the recipient and message parameter names.
4. Save settings.
5. Trigger a booking assignment and confirm delivery.

## Common local troubleshooting
- `Could not connect to database`: recheck `config/database.php`
- 404 on routes: make sure Apache `mod_rewrite` is enabled
- CSRF token error: clear browser session or refresh the page before resubmitting
- Email failed: verify SMTP port, encryption, username, and password

<?php

declare(strict_types=1);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $file = BASE_PATH . '/app/' . str_replace('\\', '/', $relative) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

$phpMailerFiles = [
    BASE_PATH . '/vendor/PHPMailer/Exception.php',
    BASE_PATH . '/vendor/PHPMailer/SMTP.php',
    BASE_PATH . '/vendor/PHPMailer/PHPMailer.php',
];

foreach ($phpMailerFiles as $file) {
    if (file_exists($file)) {
        require_once $file;
    }
}

require_once BASE_PATH . '/app/Helpers/functions.php';

<?php

declare(strict_types=1);

require_once BASE_PATH . '/bootstrap/autoload.php';

use App\Core\App;

App::run();
